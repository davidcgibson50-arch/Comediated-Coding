"""Per-entry reporting depth for AIM-AI: word count and LDA topic breadth.
Method follows the Oct 28 cluster report: narrative body only (references, author
lines, repeated biographies and site boilerplate removed); 20-topic LDA on 120-word
chunks of all 105 corpus texts; topic breadth = effective number of topics
(exp of Shannon entropy of the entry's mean chunk-topic distribution), averaged over
three seeds. Robustness: same score at 15 and 30 topics."""
import re, sys, collections
import numpy as np, pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation

PB = sys.argv[1]           # extracted playbook text
SRC = sys.argv[2]          # dir with 08 Stanford and 09 Toronto corpora
OUT = sys.argv[3]
log = []

# ---------- Georgia Tech: split at the 67 "Title:" lines ----------
lines = open(PB, encoding="utf-8").read().split("\n")
end_marker = next(i for i, l in enumerate(lines) if l.startswith("The articles collected in this playbook were written independently"))
starts = [i for i, l in enumerate(lines) if l.startswith("Title:")]
assert len(starts) == 67
texts = {}
for k, s in enumerate(starts):
    e = starts[k + 1] if k + 1 < 67 else end_marker
    block = lines[s:e]
    # drop header (Title .. Sub-Categorization)
    h = next(j for j, l in enumerate(block) if l.startswith("Sub-Categorization:"))
    body = block[h + 1:]
    # drop references to end of article
    r = [j for j, l in enumerate(body) if l.strip() in ("References", "REFERENCES", "Works Cited", "Bibliography")]
    if r:
        body = body[:r[0]]
    body = [l for l in body if not re.fullmatch(r"\s*\d+\s*", l)]   # page numbers
    texts[f"GT-{k+1:02d}"] = ("Georgia Tech", "\n".join(body))

# ---------- Stanford and Toronto ----------
def split_corpus(path):
    raw = open(path, encoding="utf-8").read()
    parts = re.split(r"^### ", raw, flags=re.M)[1:]
    out = {}
    for p in parts:
        head, _, body = p.partition("\n")
        out[head.split(" | ")[0].strip()] = (head.split(" | ")[1].strip(), body)
    return out

st = split_corpus(f"{SRC}/08_AIM-AI_corpus_Stanford.txt")
to = split_corpus(f"{SRC}/09_AIM-AI_corpus_Toronto.txt")

def paras(t):
    return [p.strip() for p in re.split(r"\n\s*\n", t) if p.strip()]

for eid, (title, body) in st.items():
    ps = paras(body)
    # boilerplate tail: the AIMES taxonomy block
    cut = next((j for j, p in enumerate(ps) if p in ("AI Teaching Strategies", "AIMES Library of Examples")), len(ps))
    ps = [p for p in ps[:cut] if p not in ("Main content start", "Back to Top", title)]
    texts[eid] = ("Stanford", "\n\n".join(ps))

# Toronto: remove duplicated title lines, back-to-top, and any paragraph repeated
# across pages (instructor biographies and name lines)
to_paras = {eid: paras(b) for eid, (t, b) in to.items()}
cnt = collections.Counter(p for ps in to_paras.values() for p in set(ps))
rep = {p for p, c in cnt.items() if c > 1}
for eid, ps in to_paras.items():
    title = to[eid][0]
    kept = [p for p in ps if p not in rep and p != title and p != "^ back to top"]
    texts[eid] = ("Toronto", "\n\n".join(kept))
log.append(f"Toronto paragraphs removed as repeated across pages: {len(rep)}")
assert len(texts) == 105, len(texts)

ids = list(texts)
words = {e: re.findall(r"[A-Za-z][A-Za-z'\-]+|\d+", texts[e][1]) for e in ids}
wc = {e: len(w) for e, w in words.items()}

# ---------- chunks ----------
chunk_ids, chunks = [], []
for e in ids:
    w = words[e]
    n = max(1, round(len(w) / 120))
    for c in np.array_split(np.arange(len(w)), n):
        chunk_ids.append(e); chunks.append(" ".join(w[i] for i in c))
vec = CountVectorizer(stop_words="english", lowercase=True, min_df=3, max_df=0.5,
                      token_pattern=r"(?u)\b[a-zA-Z][a-zA-Z\-]{2,}\b")
X = vec.fit_transform(chunks)
log.append(f"Chunks: {X.shape[0]}; vocabulary: {X.shape[1]}")

def breadth(k, seed):
    lda = LatentDirichletAllocation(n_components=k, random_state=seed, learning_method="batch",
                                    max_iter=50, doc_topic_prior=None, topic_word_prior=None)
    th = lda.fit_transform(X)
    df = pd.DataFrame(th); df["e"] = chunk_ids
    m = df.groupby("e").mean()
    m = m.div(m.sum(axis=1), axis=0)
    H = -(m * np.log(m.clip(lower=1e-12))).sum(axis=1)
    return np.exp(H)

seeds = [1, 2, 3]
tb = {k: pd.concat([breadth(k, s) for s in seeds], axis=1) for k in (15, 20, 30)}
res = pd.DataFrame({"EntryID": ids,
                    "Institution": [texts[e][0] for e in ids],
                    "WordCount": [wc[e] for e in ids],
                    "Chunks": [chunk_ids.count(e) for e in ids]})
res["TopicBreadth20"] = res.EntryID.map(tb[20].mean(axis=1)).round(3)
for s_i, s in enumerate(seeds):
    res[f"TB20_seed{s}"] = res.EntryID.map(tb[20].iloc[:, s_i]).round(3)
res["TopicBreadth15"] = res.EntryID.map(tb[15].mean(axis=1)).round(3)
res["TopicBreadth30"] = res.EntryID.map(tb[30].mean(axis=1)).round(3)
res["TopicDensity_per1000w"] = (res.TopicBreadth20 / res.WordCount * 1000).round(3)
res.to_csv(OUT, index=False)

r = res[["TopicBreadth20", "TopicBreadth15", "TopicBreadth30"]].corr()
seed_r = tb[20].corr().values[np.triu_indices(3, 1)]
log.append(f"r(TB20, TB15) = {r.iloc[0,1]:.2f}; r(TB20, TB30) = {r.iloc[0,2]:.2f}; between-seed r at 20 topics: {', '.join(f'{x:.2f}' for x in seed_r)}")
print("\n".join(log))
print(res.describe().round(2).to_string())
