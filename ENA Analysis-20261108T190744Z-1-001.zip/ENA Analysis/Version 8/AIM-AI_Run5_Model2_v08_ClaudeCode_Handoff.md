# AIM-AI Run 5: v0.8 resolution of EO and ML, and Model 2 (dimensions plus epistemic work) (handoff brief for Claude Code)

Prepared October 30, 2026, for David Gibson (Curtin University). This brief extends Run 4. It has two stages with a review gate between them. Stage A resolves the intended epistemic-opportunity (EO) and mediational-literacy (ML) codes for the 65 calibration-exposed episodes under Codebook v0.8.3. Stage B fits a second ENA model that adds EO and ML to the Run 4 dimensional codes, and summarizes the remaining extension codes descriptively. **Stop after Stage A and wait for David's review of the adjudication log before running Stage B.**

Work only from v0.8 materials. The v0.7.1 files (`AIM-AI_v071_*`, `AIM-AI_Run3_*`, `run3_*`) are reference only and must not supply codes for the 65 recoded episodes.

## 1. Files (Google Drive folder "Version 8")

| File | Role |
|---|---|
| `AIM-AI_v08_ENA_ready_intended.csv` | Run 4 model input (162 episodes, 40 columns). Its `EO_designed` and `ML_designed` columns are **carried over from v0.7.1** and are replaced in Stage A for the 65 recoded episodes. |
| `episodes_GPTv8.csv`, `episodes_CCODEv8.csv`, `claude-incognito-codesv8.xlsx` | The three blind v0.8 coders' episode-level codes, including `EO intended`, `ML intended`, `Epistemic Object (EB)`, `Uptake intended`, `Dialogue Type (DT)`, `Stated Purpose (DP)`, `Learner Variability Noted (LV)`, `Sociotechnical Frame`, `Laurillard Activity Type (context)`, Start and End configuration, and holistic codes. |
| `entries_GPTv8.csv`, `entries_CCODEv8.csv` | Entry-level stance codes from the v0.8 coders (descriptive use only). |
| `v8_IRR_by_field.csv` | Per-field agreement (Krippendorff's alpha and others). Basis for the usability rule in section 3. |
| `AIM-AI_v08_Adjudication_Log.csv`, `AIM-AI_v08_C12_Sweep_Log.csv`, `AIM-AI_v08_Resolution_README.md` | Format and procedure precedent for Stage A. |
| Codebook v0.8.3 (`01_AIM-AI_Codebook_v0_8_3.xlsx`, `02_AIM-AI_Codebook_v0_8_3.md`) | Code definitions: R16 (EO), R17 (ML), R23 (intended and reported versions). |
| Corpus texts: `gt-academic-ai-playbook-2026-edition.pdf`, `AIM-AI_corpus_Stanford.txt`, `AIM-AI_corpus_Toronto.txt` (project docs) | Source text for adjudication. |
| Run 4 folder: `run4.R`, `plots4.R`, `passplot4.R`, `cluster4.py`, `AIM-AI_ENA_Run4_results.md`, `run4_points.csv`, `run4_node_positions.csv` | Settings to reuse and Model 1 results to compare against. |

## 2. Stage A: resolve EO intended and ML intended for the 65 episodes

1. Identify the 65 episodes (`CodingPass == "v8 Blind"` in the ENA file).
2. For each episode, collect the three coders' `EO intended` and `ML intended` values.
3. **Unanimous** values stand as the v0.8 code.
4. **Non-unanimous** values: adjudicate every cell against the source text under R16 and R17 (Codebook v0.8.3), as was done for the dimension codes. A majority is a starting point, not a decision. Apply R17's exclusion strictly: knowledge of AI capabilities, limitations or prompting alone is not ML. For EO, code the most extensive designed move (EO-IN, EO-RE, EO-EV, EO-CH, EO-RD) or NE.
5. Record each ruling in `AIM-AI_v08_EO_ML_Adjudication_Log.csv` with these columns: `EpisodeID`, `Field`, `GPTv8`, `CCODEv8`, `ClaudeIncog`, `v071_value` (for reference only), `Resolved`, `Route` (Unanimous, Majority upheld, Majority overturned, Three-way split), `Rationale` (one or two sentences, paraphrase; quotation marks only for direct quotes under 15 words), and `ReviewFlag` (Yes when the ruling overturns a majority, resolves a three-way split, or turns on a close reading of R17's exclusion).
6. Derive `EO_designed` (1 if the resolved EO intended is not NE) and `ML_designed` (1 if the resolved ML intended is not ML-NA). Write `AIM-AI_v08_ENA_ready_intended_EOML.csv`: the Run 4 input with the two columns replaced for the 65 episodes and a new column `EOML_Source` (`v8 resolved` or `v0.7.1 carried`). Also keep the resolved categorical values as `EO_intended_v08` and `ML_intended_v08`.
7. Report the following in a short Stage A note:
   - counts of each resolution route;
   - before and after totals for `EO_designed` and `ML_designed` (all 162 episodes and learner episodes only);
   - the number of episodes whose presence code changed from v0.7.1.

**Stop here.** Send the log and the Stage A note to David. Do not proceed until he approves or amends the flagged rulings.

## 3. Usability rule for Model 2 (decided October 30, 2026)

A code enters Model 2 only if it meets all three criteria:

1. It is resolved under v0.8.
2. It has Krippendorff's alpha of at least .667 on `v8_IRR_by_field.csv`. Borderline values are allowed with a stated caveat.
3. It is present in at least 3 learner episodes, the same frequency rule as Run 4.

Applied to the v0.8 agreement table, the result is:

- **Enter Model 2:**
  - EO intended (alpha .70), entered as the presence node `EO_designed`;
  - ML intended (alpha .66), entered as `ML_designed` and reported with a borderline-reliability caveat.
- **Descriptive only, reported as insufficient evidence in this corpus:**
  - all reported-profile fields (mostly NE);
  - EO and ML reported;
  - Uptake intended (.40) and reported (.40);
  - Epistemic Object (.55);
  - Dialogue Type (.31);
  - Stated Purpose (.53);
  - Sociotechnical Frame (.49);
  - Learner Variability (.48);
  - the move codes (LM, AM), which have no T1 traces anywhere in the corpus.
- **Descriptive context:** Holistic intended (.70), Start and End configuration (.69, .66), Laurillard activity type (.70) and trajectory use case. These are summaries or classifiers of the dimension codes rather than additional evidence, so they stay out of the network.

## 4. Stage B: Model 2 (after approval)

Decision (October 30, 2026): EO and ML enter as two presence nodes (option a), not as their specific values.

- Input: `AIM-AI_v08_ENA_ready_intended_EOML.csv`.
- Settings identical to Run 4 Model 1A:
  - rENA 0.3.1 on R 4.3.3;
  - learner episodes only (`Learner == 1`), 139 episodes in 81 units;
  - units `Institution` + `EntryID`, conversation `Institution` + `ActivityID`;
  - window 1, with window 2 as a sensitivity check;
  - SVD rotation;
  - `OriginalPass` in place of `CodingPass`.
- Codes: the 17 Run 4 dimension codes plus `EO_designed` and `ML_designed` (19 nodes). Confirm that the frequency threshold still holds for each code.
- Model 2B: drop `NonGenerativeTool == 1`.
- Model 2 has its own projected space. Do not project it into the Model 1 space.

Report the following:

1. variance explained and goodness of fit for SV1 and SV2, and the window 2 correlations;
2. node positions, with a reading of both poles, and where EO and ML sit relative to the HD triad (Eng.HD, Prov.HD, Interp.HD) and the AS positioning node;
3. the strongest EO-linked and ML-linked connections, overall and by institution;
4. mean networks by institution, the Kruskal-Wallis tests across institutions on SV1 and SV2, and the Mann-Whitney test by `OriginalPass`;
5. **comparison with Model 1 (Run 4):**
   - correlation of unit positions on SV1 and SV2 (allow for a sign flip);
   - the units that moved most, with each move explained by its EO and ML codes;
   - a single table comparing the two models;
6. code-level tests of EO_designed and ML_designed by institution and by episode-count cluster (1, 2, 3+), each reported as a Fisher test (episodes independent) and a GEE clustered by entry, as in the Run 4 cluster report;
7. a sensitivity model with the 97 non-recoded episodes only, to show whether the v0.7.1-carried codes behave differently from the v0.8-resolved ones.

Save all outputs as `run5_*` (points, mean line weights, node positions, model object, figures).

## 5. Descriptive summary of the extension codes

Produce one table per code family across learner episodes, by institution, with these columns: n, percentage, alpha, and usability status. Cover:

- EO intended values;
- ML intended values;
- Epistemic Object;
- Uptake;
- Dialogue Type;
- Stated Purpose;
- Learner Variability;
- Sociotechnical Frame;
- Laurillard activity type;
- holistic, Start and End configuration;
- the reported-profile coverage (share NE, tier distribution).

Add a parallel instructor-only panel. For codes that were not resolved under v0.8, use the v0.7.1 value for the 97 non-recoded episodes and the v0.8 three-coder majority for the 65 recoded episodes. Mark those values as provisional, and list the episodes with no majority. In a short narrative paragraph, describe what instructor narratives in this corpus do not supply: no T1 traces, few reported uptake moves, and rare EO-IN and EO-RD. Present this as evidence about reporting practice, not as a codebook failure.

## 6. Deliverables

Create a folder "Run 5 (Model 2, EO and ML)" inside Version 8 containing:

- Stage A: the adjudication log, the new ENA input file, and the Stage A note;
- Stage B:
  - a results document in the format of `AIM-AI_ENA_Run4_results.md`, with sections for Model 2, the comparison with Model 1, and the extension-code summary;
  - all `run5_*` files;
  - the scripts used.

Write in first-person plural, with APA 7 references and DOIs, and no em dashes.

## 7. Known open items (do not resolve; note where they could matter)

- The C12 sweep did not touch EO or ML, so `EO_designed` and `ML_designed` for the 97 non-recoded episodes are v0.7.1 codes and were never re-tested under v0.8.
- Existing CM codes resting on C1's interlocutor clause (ST-28-A2, TO-BelloConv-A1, ST-10-A2) have not been re-tested against mutual adaptation.
- Eight episodes have a trajectory inconsistent with C10 (listed in the Run 4 brief).
- The coders were sessions of AI models. Agreement therefore reflects consistency under shared rules, not independent human reliability.
