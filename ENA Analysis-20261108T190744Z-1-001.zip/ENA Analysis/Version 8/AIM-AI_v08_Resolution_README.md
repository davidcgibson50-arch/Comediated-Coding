# AIM-AI v0.8 blind recode: reliability, resolution, C12 sweep, and ENA file

Prepared October 29, 2026, for David Gibson (Curtin University). Scope: the 65 calibration-exposed episodes (31 entries) recoded blind under Codebook v0.8 by three coders (GPTv8, CCODEv8, Claude incognito), then a sweep of Calibration Rule C12 across all 162 episodes.

## 1. Files in this folder

| File | Contents |
|---|---|
| `v8_IRR_by_field.csv` | Per-field agreement across the three coders: three-way exact agreement, majority existence, Krippendorff's alpha (nominal), Fleiss' kappa, pairwise Cohen's kappa |
| `AIM-AI_v08_Adjudication_Log.csv` | Resolution of every non-unanimous intended cell in the 65 recoded episodes (181 cells, plus one unanimous cell reviewed under C12) |
| `AIM-AI_v08_C12_Sweep_Log.csv` | Every change made by the C12 sweep across all 162 episodes (100 cells in 32 episodes), with before and after values and the reason |
| `AIM-AI_v08_resolved_intended.csv` | Final intended codes for the 65 recoded episodes, after the sweep |
| `AIM-AI_v08_all162_intended.csv` | Final intended configuration codes for all 162 episodes in one table |
| `AIM-AI_v08_ENA_ready_intended.csv` | The rENA input: 162 episodes, one-hot dimension columns, same structure as the v0.7.1 ENA file plus `OriginalPass` |
| `01_AIM-AI_Codebook_v0_8_2.xlsx`, `02_AIM-AI_Codebook_v0_8_2.md` | Codebook v0.8 plus revised C12 (invented examples only; no corpus content) |
| `SUPERSEDED_*` | Earlier passes, kept for the record |

## 2. Reliability summary

Agreement on the intended profile was moderate to good: Krippendorff's alpha .68 (D1), .84 (D2), .78 (D3), .71 (D4), .84 (D5); EO intended .70; ML intended .66; holistic intended .70. The two Claude-family coders agreed far more closely with each other (pairwise kappa .78 to .96) than either did with GPTv8 (.58 to .83), so every non-unanimous intended cell was adjudicated against the source text rather than settled by majority vote alone. Reported-profile and extension fields were not resolved in this pass.

## 3. Calibration Rule C12 (adopted and revised October 29, 2026, David Gibson)

**Majority initiator.** For every AS versus HD call on D1, D2, D3, holistic, Start and End where AI-produced material figures in the work, ask who is the majority initiator of the movement. AS: the AI's production draws the human toward it (the human selects, accepts, submits, or adjusts within the AI's form and substance). HD: the human draws the AI's production toward the human's own aims (specifies it, edits, corrects, rewrites or rebuilds it, or changes it against a standard the AI did not supply); repeated re-prompting toward the human's own target stays HD while the AI only executes. CM: both parties adapt themselves and to each other across repeated rounds, each re-editing and re-setting the context in response to the other; coded only where the design provides for this. C12 takes precedence over the prompt-and-revise cue in C9, the draft-revision clause in C2, and the "revised or not" clause in C7. D4 stays under C4 and D5 under C6.

## 4. Decisions recorded on October 29, 2026

1. **CM candidates.** GT-30-A2, GT-63-A1, GT-66-A1 and TO-Sanders-A2 were re-read for mutual adaptation. In each, the human re-sets the context and the AI executes or fails to improve; no design statement has the AI re-setting the context or changing the human's direction. All remain HD.
2. **D5 for ST-28-A2 and TO-BelloConv-A1.** Re-read for evidence that both parties adjust their positions. ST-28-A2 has the AI keep memory in one thread and the student update its customization; TO-BelloConv-A1 has the student set topic and level and the AI answer in role. Neither shows designed mutual repositioning, so both remain AS-5.
3. **C12 sweep.** Applied to all 162 episodes (79 candidates reviewed: 30 from the v0.8 recode, 49 from v0.7.1). 32 episodes changed (26 v0.8 cells and 74 v0.7.1 cells); 17 holistic codes moved from AS to HD. Selection-only and work-within-the-AI's-frame designs stayed AS (for example GT-01-A1, GT-19-A2, GT-34-A1, ST-24-A2, ST-34-A1, TO-KhazraRQ-A1, TO-MacKay-A1, TO-SmithMon-A1, TO-Yaari-A1).

## 5. ENA file notes

- After the sweep, intended totals across 162 episodes are: Engagement AD 9, AS 40, CM 11, HD 98; Steering AD 1, AS 14, CM 6, HD 130; Provenance AD 14, AS 34, CM 4, HD 108; Interpretation AD 1, AS 20, CM 3, HD 100; Positioning AD 2, AS 84, CM 7, HD 21. Holistic: HD 105, AS 41, AD 8, CM 6, Mixed 2.
- `CodingPass` reads `v8 Blind` for the 65 recoded episodes; `OriginalPass` keeps Pilot or Full. `EO_designed`, `ML_designed` and `NonGenerativeTool` are unchanged by the sweep.
- Instructor and staff episodes (Learner = 0, 23 rows) remain in the file and should be excluded or analyzed separately, as in Run 3.

## 6. Open items

- Existing CM codes elsewhere in the sample (for example D1 and D2 CM in ST-28-A2 and TO-BelloConv-A1, which rest on C1's interlocutor clause, and D1 and D5 CM in ST-10-A2) have not been re-tested against the mutual-adaptation criterion.
- Eight v0.7.1 episodes have Start different from End but a trajectory other than Within-episode (GT-32-A2, GT-44-A2, GT-67-A1, ST-02-A2, ST-10-A2, ST-21-A1, ST-38-A1, TO-SmithMyth-A1), which C10 does not allow. They were not touched by the sweep.
- Reported profile, tiers and extension codes for the 65 episodes, and the entry-level stance fields, remain unresolved.
