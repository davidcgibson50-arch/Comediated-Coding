# AIM-AI Run 4: ENA and cluster analyses on the v0.8 coding (handoff brief for Claude Code)

Prepared October 29, 2026, for David Gibson (Curtin University). This brief asks Claude Code to repeat the primary analyses we ran on the Run 3 coding (October 26 to 28, 2026) on the v0.8 coding, and to report how the results change. Use the files listed below exactly as named; do not recode anything.

## 1. Files (Google Drive folder "Version 8")

| File | Role |
|---|---|
| `AIM-AI_v08_ENA_ready_intended.csv` | **Model input.** 162 episodes, 40 columns: the 34 columns of the Run 3 file layout plus `OriginalPass`, and the six sequence-direction columns `HS`, `StepChange`, `SS`, `EntrySequenceChange`, `SD`, `SequenceOscillation`. Includes the Run 3.1 ruling GT-41-A1 Pos.AS = 1. |
| `AIM-AI_v08_depth_by_entry.csv` | Reporting depth for all 105 corpus texts: `WordCount`, `TopicBreadth20` (mean of three seeds), each seed, `TopicBreadth15`, `TopicBreadth30`, `TopicDensity_per1000w`. Join on `EntryID`. |
| `AIM-AI_v08_C12_Sweep_Log.csv`, `AIM-AI_v08_Adjudication_Log.csv` | Which codes changed from Run 3 and why. Use them to explain movement, not as model input. |
| `AIM-AI_v08_Resolution_README.md` | How the v0.8 codes were produced (reliability, adjudication, Calibration Rule C12). |
| `depth.py`, `r30.py` | Scripts that produced the depth table and the sequence-direction columns. |
| Codebook v0.8.3 (`01_AIM-AI_Codebook_v0_8_3.xlsx`, `02_AIM-AI_Codebook_v0_8_3.md`) | Codebook v0.8.2 plus R30 (sequence direction), restored from v0.7.2. |

**Reference files from Run 3** (Drive "Run 3 (moderated, Codebook v0.7.1)" and "Run 3 scripts"; project docs):

- `run3.R`, `plots3.R`, `passplot3.R`: the Run 3 model and figure scripts. Reuse them with the changes in section 3.
- `AIM-AI_ENA_Run3_results.md`: Run 3 settings and results.
- `AIM-AI_v072_moderated_ENA_ready_intended.csv`: the Run 3 input with the sequence-direction columns, for the comparison in section 4.
- Google Doc "AIM-AI Run 3 episode clusters summary report" (October 28, 2026): the specification for section 5. Reproduce each of its five findings in the new space.
- `run3_points.csv`: Run 3 unit positions, for the comparison of the two spaces.

## 2. What changed since Run 3

1. **Coding.** The 65 episodes (31 entries) exposed to calibration were recoded blind under Codebook v0.8 by three coders and every disagreement was adjudicated. Calibration Rule C12 (majority initiator: AS when the AI's production draws the learner toward it, HD when the learner draws the AI toward the learner's aims, CM only when both adapt to each other) was then applied to all 162 episodes. In total 32 episodes changed, and 17 holistic codes moved from AS to HD. Intended totals across 162 episodes: Engagement AD 9, AS 40, CM 11, HD 98; Steering AD 1, AS 14, CM 6, HD 130; Provenance AD 14, AS 34, CM 4, HD 108; Interpretation AD 1, AS 20, CM 3, HD 100; Positioning AD 2, AS 85, CM 7, HD 21.
2. **GT-41-A1 positioning.** The Run 3.1 ruling (intended D5 = AS) is now in the file. It was missing from both the Run 3 input and the v0.7.2 file, so the Run 3 model, yesterday's cluster analysis and the original sequence index all treated GT-41-A1 positioning as uncoded.
3. **Pass columns.** `CodingPass` now reads `v8 Blind` for the 65 recoded episodes. **Use `OriginalPass` (Pilot or Full) wherever the Run 3 scripts use `CodingPass`.**
4. **Code set.** At the frequency threshold of 3 learner episodes, 17 codes are retained (Run 3 had 16): Interp.CM now has 3 and enters; Steer.AD (1), Interp.AD (1) and Pos.AD (2) stay out. Report the comparison model with Run 3's fixed 16 codes as well.
5. **Depth table.** The October 28 depth values were not saved, so they were recomputed. The method is the same, but the Stanford and Toronto texts are the October 27 re-retrievals of the live pages, and the LDA is stochastic. Expect small differences: for example, median word count is 1,485 for the 3+ cluster against 785 for single-episode entries (October 28: 1,520 and 718), and median topic breadth is 6.5 against 5.4 (October 28: 7.8 and 5.5). Topic breadth correlates .82 with the 15-topic score and .85 with the 30-topic score (October 28: .86).

## 3. Primary ENA (Run 4, Models 1A and 1B)

Use the Run 3 settings unchanged:

- rENA 0.3.1 on R 4.3.3.
- Learner episodes only (`Learner == 1`): 139 episodes in 81 units (Georgia Tech 45, Stanford 18, Toronto 18).
- Units: `Institution` + `EntryID`. Conversation: `Institution` + `ActivityID`.
- Window 1, with window 2 as a sensitivity check. SVD rotation.
- Codes: frequency threshold 3, recomputed on the v0.8 data (17 codes); comparison model with the Run 3 fixed 16-code list.
- Model 1B: drop `NonGenerativeTool == 1` (TO-BelloWrite-A2).
- Tests: Kruskal-Wallis across institutions on SV1 and SV2; Mann-Whitney by `OriginalPass`.

Report: variance explained and goodness of fit for SV1 and SV2; the window 2 correlations; node positions and a reading of both poles; mean networks by institution with the strongest connections; the institution and pass tests; and code-level Fisher tests of pilot against full entries for Steer.HD, Interp.HD and holistic CM (the three Run 3 differences). Save points, mean line weights, node positions, the model object and the figures as `run4_*`, mirroring the Run 3 outputs.

## 4. Comparison with Run 3

1. Correlate Run 4 unit positions with `run3_points.csv` on SV1 and SV2 (allow for an arbitrary sign flip in SVD).
2. List the units that moved most, and link each to its changes in the sweep and adjudication logs.
3. Compare variance explained, node positions, institution results and pass results in a single table.

## 5. Cluster, sequence and dependence analyses (repeat of October 28, in the Run 4 space)

Follow the October 28 report section by section, with the same definitions and tests:

1. **Clusters.** Group entries by number of learner episodes (1, 2, 3+; currently 41, 27 and 13 entries), keeping the trajectory use case at episode level. Compare positions with Kruskal-Wallis, then with OLS with robust errors controlling for institution, `WordCount` and `TopicBreadth20`. Repeat within Georgia Tech alone.
2. **Human-constructive triad.** Sum the Eng.HD–Prov.HD, Eng.HD–Interp.HD and Prov.HD–Interp.HD line weights per entry; compare the 3+ cluster with single-episode entries, without controls, with institution, and with institution and depth controls. Do the same for the steering connections.
3. **Code-level differences** for the 3+ cluster (positioning left NE, holistic CM, Eng.AS, Pos.HD, and any new difference above p < .05). Report each four ways: Fisher (episodes treated as independent), GEE with exchangeable correlation clustered by entry, GEE with depth and institution controls, and permutation of whole entries within institution or word-count strata (5,000 permutations).
4. **Sequence direction (R30).** Use the HS, SS and SD columns already in the file. Report:
   - the step table by use-case pair;
   - the sign test for the entries with two or more sequential learner episodes (15 under v0.8; 16 in Run 3);
   - the within-entry order permutation (5,000) for sequential episodes and for all multi-episode entries;
   - first and last episodes against single-episode designs.
   
   Report SD counts at thresholds 0.34, 0.5, 0.75 and 1.0. From `r30.py` the v0.8 counts for the 40 multi-episode entries at 0.5 are 11 toward human direction, 9 toward AI direction and 20 stable, with 3 oscillating (Run 3: 14, 8, 18 and 3). Confirm or correct these.
5. **Instructor-only episodes** (`Learner == 0`, 23 episodes in 20 entries), as a separate descriptive panel outside the ENA model.
6. **Dependence.** Report the intraclass correlation of HS within multi-episode entries, the design effect and effective sample size, and carryover of the holistic configuration and of each dimension between consecutive episodes (permutation against random pairs from different entries).
7. **Figures.** Cluster positions with labels for 4-, 5- and 6-episode entries; mean networks by cluster; a heat map by position in sequence; and dimension-by-configuration heat maps by cluster.

For each of the five October 28 findings, state whether it holds, weakens or reverses, and give the evidence. Keep the October 28 confidence scale (High, Moderate, Low, Very low).

## 6. Deliverables

Create a folder "Run 4 (v0.8 coding)" inside Version 8 containing:

- a results document in the format of `AIM-AI_ENA_Run3_results.md` (sections 3 and 4 above);
- a cluster report in the format of the October 28 report (section 5);
- all `run4_*` CSV, RDS and PNG files;
- the R and Python scripts used.

Write in first-person plural, APA 7 references with DOIs, no em dashes.

## 7. Known open items (do not resolve; note where they could matter)

- Existing CM codes that rest on C1's interlocutor clause (D1 and D2 in ST-28-A2 and TO-BelloConv-A1; D1 and D5 in ST-10-A2) have not been re-tested against the mutual-adaptation criterion.
- Eight episodes have Start different from End but a trajectory other than Within-episode, which C10 does not allow: GT-32-A2, GT-44-A2, GT-67-A1, ST-02-A2, ST-10-A2, ST-21-A1, ST-38-A1 and TO-SmithMyth-A1. Their use case enters the step table in section 5.4.
- Episode segmentation remains frozen as in Run 3 (see its limitation 3).
- Coders were sessions of AI models, so agreement reflects consistency under shared rules rather than independent human reliability.
