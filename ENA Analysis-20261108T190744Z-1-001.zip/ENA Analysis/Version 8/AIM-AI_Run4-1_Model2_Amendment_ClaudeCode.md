# AIM-AI amendment to the Run 5 brief: apply patch v0.8.1, re-run Model 1 (Run 4.1), and rebuild Model 2

Prepared October 30, 2026, for David Gibson (Curtin University). This amendment supersedes section 4 of `AIM-AI_Run5_Model2_v08_ClaudeCode_Handoff.md` wherever the two conflict. Earlier today, David resolved three open items from the Run 4 brief:

- the CM codes resting on C1's interlocutor clause, extended to every CM-coded episode;
- the eight episodes inconsistent with C10;
- the status of the carried-over EO and ML codes.

The resulting changes to the intended codes are listed in `AIM-AI_v081_Patch_Log.csv` (Drive folder "Version 8"). Any Stage B output already produced on the unpatched file is superseded. Keep it only as `SUPERSEDED_*`.

## 1. Apply the patch

1. Apply every row of `AIM-AI_v081_Patch_Log.csv` whose `New` value differs from `Old` to:
   - `AIM-AI_v08_ENA_ready_intended_EOML.csv` (your Stage A output);
   - `AIM-AI_v08_all162_intended.csv`.

   Rows marked "(unchanged)" are a record only. Before writing anything, confirm that each `Old` value matches the file; stop and report any mismatch.
2. Rebuild the one-hot columns for every changed dimension. Update `HolisticIntended` and `TrajectoryUseCase`. Re-run `r30.py` to recompute `HS`, `StepChange`, `SS`, `EntrySequenceChange`, `SD` and `SequenceOscillation`.
3. Save the results as:
   - `AIM-AI_v081_ENA_ready_intended_EOML.csv`;
   - `AIM-AI_v081_all162_intended.csv`.
4. Add a column `PatchRow` (1 if any field in the episode changed) so changed episodes can be traced.

Expected learner-episode counts after the patch are listed below. Report any difference from these counts.

| Code | Before | After |
|---|---|---|
| Eng.CM | 11 | 6 |
| Steer.CM | 6 | 3 |
| Prov.CM | 4 | 2 |
| Interp.CM | 3 | 2 |
| Pos.CM | 7 | 5 |

Other expected changes:

- Holistic CM falls from 6 to 3 episodes (GT-09-A3, GT-09-A4, GT-15-A1).
- Within-episode use cases rise from 10 to 13.
- EO and ML codes are unaffected (R5).

## 2. Model 1 re-run (Run 4.1)

1. Use the same settings as Run 4 Model 1A and 1B, on `AIM-AI_v081_ENA_ready_intended_EOML.csv`.
2. Recompute the frequency threshold of 3 learner episodes. We expect 15 codes:
   - Prov.CM and Interp.CM drop out;
   - Steer.CM sits exactly at 3.
3. Report a comparison model with the Run 4 17-code list, so readers can see the effect of the node change apart from the coding change.
4. Report the same statistics as Run 4. Then compare Run 4.1 with Run 4:
   - unit-position correlations, allowing for a sign flip;
   - the units that moved most, each linked to its patch rows;
   - node positions;
   - institution and pass tests;
   - variance explained.
5. Re-run the cluster, sequence and dependence analyses of Run 4 section 5 wherever `TrajectoryUseCase`, `HS`, `SS` or `SD` changed.
   - Say which of the October 28 findings change.
   - Use the October 28 confidence scale.

## 3. Model 2 (dimensions plus epistemic work)

1. Follow section 4 of the Run 5 brief, using the patched file and the Run 4.1 code set plus `EO_designed` and `ML_designed`. We expect 17 nodes.
2. Compare Model 2 with Run 4.1, not with Run 4.

## 4. Decisions to carry into the write-up

1. **EO and ML for the 97 non-recoded episodes** are treated as valid v0.8 codes. The reasons:
   - v0.8 changed no EO or ML definition, boundary or value;
   - C12 does not reach EO or ML;
   - these episodes were never exposed to calibration.

   No drift test is run. Remove the sensitivity model in section 4, item 7, of the Run 5 brief.
2. **Reliability limitation.** All coding was done by sessions of AI models under shared rules. Our agreement statistics are therefore consistency tests, not inter-rater reliability between independent human coders. State this as a limitation wherever agreement is reported.
3. **Interpretive note for the results.** Under the mutual-adaptation criterion (C12, with C1 and C4 read alongside it), designed co-mediation is rare in this corpus. Only three learner episodes remain holistically CM, all from Georgia Tech, and all with an AI configured to initiate, challenge or role-play in response to the learner. Report this as a finding about the instructor designs, and note that it partly reflects the criterion we adopted.

## 5. Deliverables

Add to the folder "Run 5 (Model 2, EO and ML)":

- the two v0.8.1 data files;
- a patch verification note (old-value check and the before and after counts);
- the Run 4.1 results document and `run41_*` outputs;
- the Model 2 results built on Run 4.1 (`run5_*`);
- the scripts.

Write in first-person plural, with APA 7 references and DOIs, and no em dashes.
