# AIM-AI blind recoding under Codebook v0.8: instructions for coders

Prepared October 29, 2026, for David Gibson (Curtin University). This package lets an independent coder (a human, a fresh Claude session, or another model such as ChatGPT) code 65 mediation episodes from 31 entries without seeing any earlier coding.

## 1. What you are doing

You are an independent coder applying the AIM-AI codebook (Interactional Model of AI-Mediated Learning) to instructors' published accounts of AI use in teaching. For each listed episode you code an **intended profile** (what the design asks for) and a **reported profile** (what the account shows happened, with an evidence tier), plus the extension codes. You also code four reporting-stance fields for each entry.

The episodes are already defined. Segmentation is frozen: do not add, split, merge, or drop episodes, and do not edit the identification columns. If an episode looks uncodable, code what the source supports, use NE elsewhere, and explain in the memo.

## 2. Blinding conditions (read before starting)

Code only from the files in this package. In particular:

- Do not use web search, other documents, prior chats, or saved memory.
- **Claude:** start a new chat *outside* the "AIM-AI theory and application" project (that project contains earlier codes and analyses), and use an incognito chat or turn off memory and past-chat search for the session.
- **ChatGPT:** use a Temporary Chat, or turn off memory and custom instructions, and do not use a custom GPT or project that has seen AIM-AI material.
- **Human coders:** do not consult the Run 3 coding forms, adjudication log, ENA outputs, or the AIM-AI episode encyclopedia.
- If you have seen earlier AIM-AI codes for any of these entries, say so before starting; you should not code them.

## 3. Files

| File | Use |
|---|---|
| `01_AIM-AI_Codebook_v0_8.xlsx` | The codebook (authoritative). Coder-facing sheets: Calibration Rules, Framework, Codebook, Extension Codes, Decision Rules, Lists. |
| `02_AIM-AI_Codebook_v0_8.md` | The same coder-facing content as text, for coders who work better from text. If the two ever differ, the .xlsx governs. |
| `03_episode_coding_template.csv` | One row per episode, in the coding order. Fill the blank columns. |
| `04_entry_coding_template.csv` | One row per entry. Fill the four stance fields. |
| `05_validate.py` | Checks your completed files (standard-library Python). |
| `06_SOURCE_MANIFEST.md` | Which entries to read and where each one is. |
| `07_GT_sources_for_recode.txt` | Full text of the 15 Georgia Tech entries. |
| `08_AIM-AI_corpus_Stanford.txt`, `09_AIM-AI_corpus_Toronto.txt` | Added by David before distribution, in this same folder. Code only the entries named in the manifest. |

## 4. Procedure

1. Read the whole codebook once: Framework, Codebook, Extension Codes, Decision Rules, then **Calibration Rules**. Where a Calibration Rule applies, it takes precedence over the boundary notes in the Codebook sheet.
2. Work entry by entry in the order of `03_episode_coding_template.csv`. For each entry, read the full source text once without coding (README procedure step 1).
3. Code the entry's episodes. For each episode:
   - Fill **Human Participant** and **Learner** (1 if the participant is a learner; students always count as learners, P1; staff teams do not).
   - Fill the context fields (Context, Sociotechnical Frame, Laurillard Activity Type).
   - In **Excerpt or Paraphrase**, give the design statement(s) and any enactment evidence you coded from, as short quotations or close paraphrase from the source.
   - Code the **intended profile** I-D1 to I-D5 from design statements only (R3, R23, C8). Use NE where no design statement bears on a dimension.
   - Code the **reported profile** R-D1 to R-D5 from enactment evidence only, and give each coded dimension its tier (T1 trace, T2 participant account, T3 instructor or developer observation; R22). Leave the tier blank when the dimension is NE. Outcome claims are not evidence of a configuration (R23).
   - Code DT, EB, EO (intended, reported, tier), ML (intended, reported, tier), and Uptake (intended, reported, tier). EB is coded only when an EO code is assigned.
   - Code Start Config, End Config, and Trajectory Basis (R6). Code Trajectory Use Case by C10: if Start differs from End it is Within-episode.
   - Code Stated Purpose (DP) from stated intent only, and Learner Variability (LV) only from what the author reports.
   - Assign the two holistic configurations by judgment (R12, R28). The reported holistic is NE unless at least two reported dimensions are coded.
   - Set **Confidence**. For a near-boundary call between configurations (C5): set Confidence to Low, enter `R10` in **R10 Flag**, and write a memo naming the R10 question that decided it and quoting or citing the deciding design statement.
4. Code the entry row in `04_entry_coding_template.csv` (Claim Stance, AI-use Stance, Limitations Acknowledged, Traces Collected; R26). Screening is fixed at Include.
5. Use exactly the values in the codebook's Lists sheet, spelled as listed. Code each dimension on its own evidence (R5); do not infer one dimension from another, from the tool type, or from the author's enthusiasm or concern (R9).

## 5. Output

- Save the two completed files as `episodes_<coder>.csv` and `entries_<coder>.csv` (for example `episodes_chatgpt.csv`), UTF-8, with the template's columns in the template's order.
- Run `python 05_validate.py episodes_<coder>.csv entries_<coder>.csv` and fix every ERROR. WARNINGs are prompts to re-check a rule; leave the code if you still judge it correct and say why in the memo.
- If you cannot run Python, check the rules in section 4 by hand and say so when you return the files.
- When you return the files, report: episodes coded, number of Low-confidence and R10-flagged items, and any episode you found uncodable or wrongly segmented (as a note; do not change the segmentation).

## 6. Working in batches

The task is long. A model coder should work in batches of about five entries, validating as it goes, and should not summarize or shorten source text before coding from it. A human coder can work in any order but should keep entry order for the record.

## 7. Paste-in prompt for a model coder

> You are an independent coder for the AIM-AI study. Follow `00_README_CODER_INSTRUCTIONS.md` exactly. Use only the files in this package; do not use web search, memory, or any other source. Read the codebook in full first (Calibration Rules take precedence). Then code every row of `03_episode_coding_template.csv` and `04_entry_coding_template.csv` in batches of about five entries, reading each entry's full source text before coding it. Do not change the identification columns or the episode list. Validate with `05_validate.py`, fix all errors, and return `episodes_<coder>.csv` and `entries_<coder>.csv` with a short report of counts, Low-confidence and R10-flagged items, and any segmentation concerns.
