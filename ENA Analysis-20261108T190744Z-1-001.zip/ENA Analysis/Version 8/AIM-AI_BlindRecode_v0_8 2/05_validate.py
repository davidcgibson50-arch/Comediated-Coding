"""Validate a completed AIM-AI v0.8 blind-recode file.

Usage:
    python 05_validate.py <completed_episode_file.csv> [<completed_entry_file.csv>]

Checks structure against the templates in this folder, controlled vocabularies
(Codebook v0.8, Lists sheet), and the mechanical rules R22, R28, C5 and C10.
Errors must be fixed; warnings are prompts to re-read the rule, not errors.
Standard library only.
"""
import csv, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
EP_TEMPLATE = os.path.join(HERE, '03_episode_coding_template.csv')
EN_TEMPLATE = os.path.join(HERE, '04_entry_coding_template.csv')

CODES = ['AD', 'AS', 'CM', 'HD', 'NE']
TIERS = ['T1', 'T2', 'T3']
V = {
    'Human Participant': ['Student', 'Instructor', 'TA', 'Intern/Trainee', 'Research team', 'Group', 'Other'],
    'Learner': ['0', '1'],
    'Context': ['Teaching', 'Internship/Experiential', 'Research training', 'Course preparation', 'Other'],
    'Sociotechnical Frame': ['High-stakes assessment', 'Low-stakes or formative', 'Self-directed or optional',
                             'Professional or workplace', 'Instructor preparation', 'Unclear'],
    'Laurillard Activity Type (context)': ['Acquisition', 'Practice', 'Inquiry, discussion, collaboration',
                                           'Inquiry, production', 'Reflection', 'Multiple', 'NE'],
    'Dialogue Type (DT)': ['Instructional', 'Feedback-oriented', 'Collaborative', 'Reflective', 'Mixed', 'NE'],
    'Epistemic Object (EB)': ['Evidence and relevance', 'Explanation and causality', 'Authority and credibility',
                              'Reasoning norms', 'Perspective and bias', 'Multiple', 'NE'],
    'EO intended': ['EO-IN', 'EO-RE', 'EO-EV', 'EO-CH', 'EO-RD', 'NE'],
    'EO reported': ['EO-IN', 'EO-RE', 'EO-EV', 'EO-CH', 'EO-RD', 'NE'],
    'ML intended': ['ML-FR', 'ML-EP', 'ML-CW', 'ML-DD', 'ML-RA', 'ML-MX', 'ML-NA', 'NE'],
    'ML reported': ['ML-FR', 'ML-EP', 'ML-CW', 'ML-DD', 'ML-RA', 'ML-MX', 'ML-NA', 'NE'],
    'Uptake intended': ['UP-AD', 'UP-AP', 'UP-CT', 'UP-RJ', 'UP-IG', 'UP-MX', 'NE'],
    'Uptake reported': ['UP-AD', 'UP-AP', 'UP-CT', 'UP-RJ', 'UP-IG', 'UP-MX', 'NE'],
    'Start Config': CODES, 'End Config': CODES,
    'Trajectory Basis': ['Intended', 'Reported'],
    'Stated Purpose (DP)': ['Introduce or model (AD)', 'Guided practice (AS)', 'Inquiry and refinement (CM)',
                            'Independent production (HD)', 'Critical evaluation of AI (HD)', 'Multiple', 'Not stated'],
    'Learner Variability Noted (LV)': ['Prior knowledge', 'Motivation', 'Self-regulation', 'Cultural context',
                                       'AI literacy', 'Orientation toward AI', 'Multiple', 'None noted'],
    'Holistic: intended (judgment)': ['AD', 'AS', 'CM', 'HD', 'Mixed', 'NE'],
    'Holistic: reported (judgment)': ['AD', 'AS', 'CM', 'HD', 'Mixed', 'NE'],
    'Trajectory Use Case': ['Single use', 'Sequential', 'Within-episode', 'Recurrent'],
    'Confidence': ['High', 'Medium', 'Low'],
    'R10 Flag': ['', 'R10'],
}
I_DIMS = ['I-D1 Engagement Type', 'I-D2 Interaction Structure (steering)', 'I-D3 Provenance of Production',
          'I-D4 Interpretive Influence', 'I-D5 Positioning (design framing)']
R_DIMS = ['R-D1 Engagement Type', 'R-D2 Interaction Structure (steering)', 'R-D3 Provenance of Production',
          'R-D4 Interpretive Influence', 'R-D5 Positioning (learner orientation)']
for d in I_DIMS + R_DIMS:
    V[d] = CODES
TIER_PAIRS = [(d, f'R-D{i} Tier') for i, d in enumerate(R_DIMS, 1)] + [
    ('EO reported', 'EO reported tier'), ('ML reported', 'ML reported tier'), ('Uptake reported', 'Uptake reported tier')]
UNIT = ['Episode ID', 'Institution', 'Entry ID', 'Author(s)', 'Short Title', 'Source Category', 'ActivityID',
        'Learning Activity (label)', 'Episode label', 'Episode #', 'Episode Objective', 'AI System / Tool']
EN_V = {
    'Screening': ['Include', 'Exclude: AI removed', 'Exclude: non-interactional commentary',
                  'Exclude: static AI artifact only', 'Exclude: other'],
    'Claim Stance (CS)': ['Descriptive', 'Benefit claimed', 'Mixed results', 'Critical'],
    'AI-use Stance (US)': ['Assigned', 'Optional', 'Limited', 'Prohibited', 'Mixed', 'Instructor use'],
    'Limitations Acknowledged (LA)': ['None stated', 'Design limits', 'Evidence limits', 'Both'],
    'Traces Collected (TC)': ['Not described', 'Collected, not reproduced', 'Partly reproduced', 'Reproduced'],
}


def read(path):
    with open(path, newline='', encoding='utf-8-sig') as f:
        rd = csv.DictReader(f)
        return rd.fieldnames, list(rd)


def check_episodes(path):
    errs, warns = [], []
    t_head, t_rows = read(EP_TEMPLATE)
    head, rows = read(path)
    if head != t_head:
        errs.append(f'Column headers differ from the template. Missing: {sorted(set(t_head) - set(head or []))}; '
                    f'unexpected: {sorted(set(head or []) - set(t_head))}; order must match exactly.')
        return errs, warns
    tmap = {r['Episode ID']: r for r in t_rows}
    ids = [r['Episode ID'] for r in rows]
    if sorted(ids) != sorted(tmap):
        errs.append(f'Episode IDs differ from the template. Missing: {sorted(set(tmap) - set(ids))}; '
                    f'extra: {sorted(set(ids) - set(tmap))}; duplicates: {sorted({i for i in ids if ids.count(i) > 1})}. '
                    'Segmentation is frozen: do not add, split, merge or delete episodes.')
    for r in rows:
        e = r['Episode ID']
        t = tmap.get(e)
        if t:
            for k in UNIT:
                if r[k] != t[k]:
                    errs.append(f'{e}: unit field "{k}" was changed; restore the template value.')
        for k, allowed in V.items():
            if r[k] not in allowed:
                errs.append(f'{e}: "{k}" = "{r[k]}" is not an allowed value ({"; ".join(a or "(blank)" for a in allowed)}).')
        for code_f, tier_f in TIER_PAIRS:
            coded = r[code_f] not in ('NE', 'ML-NA', '')
            if coded and r[tier_f] not in TIERS:
                errs.append(f'{e}: "{code_f}" is coded, so "{tier_f}" needs T1, T2 or T3 (R22).')
            if not coded and r[tier_f]:
                errs.append(f'{e}: "{code_f}" is {r[code_f] or "blank"}, so "{tier_f}" must be blank.')
        if not r['Excerpt or Paraphrase'].strip():
            errs.append(f'{e}: "Excerpt or Paraphrase" is empty.')
        n_rep = sum(r[d] in ('AD', 'AS', 'CM', 'HD') for d in R_DIMS)
        if n_rep < 2 and r['Holistic: reported (judgment)'] != 'NE':
            errs.append(f'{e}: fewer than two reported dimensions are coded, so the reported holistic configuration must be NE (R28).')
        if (r['Confidence'] == 'Low' or r['R10 Flag'] == 'R10') and not r['Memo'].strip():
            errs.append(f'{e}: Low confidence or an R10 flag needs a memo naming the deciding R10 question and design statement (C5).')
        if r['R10 Flag'] == 'R10' and r['Confidence'] != 'Low':
            errs.append(f'{e}: an R10 flag requires Confidence = Low (C5).')
        n_int = sum(r[d] in ('AD', 'AS', 'CM', 'HD') for d in I_DIMS)
        if n_int < 3:
            warns.append(f'{e}: fewer than three intended dimensions coded; this triggers the review flag (R12). Memo why.')
        if r['Start Config'] and r['End Config']:
            if r['Start Config'] != r['End Config'] and r['Trajectory Use Case'] != 'Within-episode':
                warns.append(f'{e}: Start differs from End, so C10 says Trajectory Use Case should be Within-episode.')
            if r['Start Config'] == r['End Config'] and r['Trajectory Use Case'] == 'Within-episode':
                warns.append(f'{e}: Within-episode is coded but Start equals End (C10).')
        if r['EO intended'] == 'NE' and r['EO reported'] == 'NE' and r['Epistemic Object (EB)'] not in ('NE', ''):
            warns.append(f'{e}: EB is coded but no EO code is assigned; EB is coded only with an EO code.')
        if r['Learner'] == '0' and r['Human Participant'] == 'Student':
            warns.append(f'{e}: Student coded as non-learner; students count as learners (P1).')
    return errs, warns


def check_entries(path):
    errs = []
    t_head, t_rows = read(EN_TEMPLATE)
    head, rows = read(path)
    if head != t_head:
        return [f'Entry file headers differ from the template: expected {t_head}.']
    if sorted(r['Entry ID'] for r in rows) != sorted(r['Entry ID'] for r in t_rows):
        errs.append('Entry IDs differ from the template.')
    for r in rows:
        for k, allowed in EN_V.items():
            if r[k] not in allowed:
                errs.append(f'{r["Entry ID"]}: "{k}" = "{r[k]}" is not an allowed value ({"; ".join(allowed)}).')
    return errs


if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    errs, warns = check_episodes(sys.argv[1])
    if len(sys.argv) > 2:
        errs += check_entries(sys.argv[2])
    for w in warns:
        print('WARNING', w)
    for e in errs:
        print('ERROR', e)
    print(f'\n{len(errs)} errors, {len(warns)} warnings.')
    sys.exit(1 if errs else 0)
