# Source manifest

Code only the entries listed here, and only the episodes listed in `03_episode_coding_template.csv`.

| Institution | Entries | Source file | Where to find each entry |
|---|---|---|---|
| Georgia Tech | GT-05, GT-06, GT-09, GT-12, GT-19, GT-22, GT-23, GT-24, GT-28, GT-30, GT-31, GT-58, GT-61, GT-63, GT-66 | `07_GT_sources_for_recode.txt` | Section headed `### <Entry ID>` |
| Stanford | ST-09, ST-28, ST-29, ST-32 | `08_AIM-AI_corpus_Stanford.txt` (add to this folder) | Section headed `### <Entry ID> |` |
| Toronto | TO-BelloConv, TO-BelloWrite, TO-Bentley, TO-Goldfarb, TO-KhazraLR, TO-KhazraRQ, TO-MacKay, TO-Sanders, TO-Seward, TO-SmithMon, TO-Wood, TO-Yaari | `09_AIM-AI_corpus_Toronto.txt` (add to this folder) | Section headed `### <Entry ID> |` |

The Stanford and Toronto files contain other entries as well; ignore every section not listed above.
