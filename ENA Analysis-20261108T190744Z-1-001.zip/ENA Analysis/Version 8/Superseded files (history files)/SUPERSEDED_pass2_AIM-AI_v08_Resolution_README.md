# AIM-AI v0.8 blind recode: reliability, resolution, and ENA file

Prepared October 29, 2026, for David Gibson (Curtin University). Scope: the 65 calibration-exposed episodes (31 entries) recoded blind under Codebook v0.8 by three coders: GPTv8 (ChatGPT), CCODEv8 (Claude Code), and Claude (incognito chat).

## 1. Files in this folder

| File | Contents |
|---|---|
| `v8_IRR_by_field.csv` | Per-field agreement: three-way exact agreement, majority existence, Krippendorff's alpha (nominal), Fleiss' kappa, and pairwise Cohen's kappa |
| `AIM-AI_v08_Adjudication_Log.csv` | Every non-unanimous intended cell (181 cells, plus one unanimous cell reviewed under C12): each coder's value, the majority, the final value, the basis, and a note where the call needed reasoning |
| `AIM-AI_v08_resolved_intended.csv` | Final intended codes for the 65 episodes (I-D1 to I-D5, EO, ML, holistic, Start, End, trajectory, participant, learner) |
| `AIM-AI_v08_ENA_ready_intended.csv` | The rENA input: 162 episodes (97 unchanged v0.7.1 moderated episodes plus the 65 resolved v0.8 episodes) |
| `01_AIM-AI_Codebook_v0_8_1.xlsx`, `02_AIM-AI_Codebook_v0_8_1.md` | Codebook v0.8 plus Calibration Rule C12 (invented examples only; no corpus content) |
| `SUPERSEDED_*` | First-pass files built under the original wording of C12; kept for the record |

## 2. Reliability summary

Agreement on the intended profile, which feeds the ENA, was moderate to good: Krippendorff's alpha .68 (D1), .84 (D2), .78 (D3), .71 (D4), .84 (D5); EO intended .70; ML intended .66; holistic intended .70. A two-of-three majority existed for 97% to 100% of intended cells. The two Claude-family coders agreed far more closely with each other (pairwise kappa .78 to .96) than either did with GPTv8 (.58 to .83), so majority agreement was not treated as independent confirmation; every non-unanimous intended cell was adjudicated against the source text and the calibration rules. Reported-profile and extension fields (Dialogue Type alpha .31; Uptake intended .40) were not resolved in this pass.

## 3. New calibration rule C12 (adopted October 29, 2026, David Gibson; revised the same day)

**C12: AI-first sequences (extends C5).** On a near-boundary call where the AI supplies a draft, answer, set of options, or artifact first and the human then acts on it: (a) selection only, with no editing and no outside standard, is AS; (b) editing, correcting, transforming, or judging against a standard the AI did not supply, in one round, is HD; (c) the same over several designed rounds in which the AI's production changes in response is a CM candidate, coded CM only where the rounds are stated in the design. C12 governs D1, D2, D3, D5, holistic, Start and End, and takes precedence over the prompt-and-revise cue in C9, the draft-revision clause in C2, and the "revised or not" clause in C7 for these calls; D4 stays under C4. The rule text, with invented worked examples only, is in Codebook v0.8.1 (`01_AIM-AI_Codebook_v0_8_1.xlsx`, `02_AIM-AI_Codebook_v0_8_1.md`).

Scope in this pass: cross-coder AS/HD splits, R10-flagged AS/HD calls, and 2 AS / 2 HD holistic ties in the 65 v0.8 episodes. Sixteen episodes were reviewed under C12. Most moved toward HD (for example GT-30-A2, GT-63-A1, GT-66-A1, ST-29-A1, TO-Bentley-A1, TO-Seward-A1), which is the direction GPTv8 had coded; selection-only cases stayed AS (TO-KhazraLR-A1, TO-SmithMon-A1, TO-Yaari-A1); TO-KhazraRQ-A1 keeps its unanimous HD-2 because students refine the chosen question.

## 4. Resolution counts

Of 181 non-unanimous intended cells, 130 were resolved by upholding the majority after review, 37 were changed or settled under C12, and 14 were three-way splits or other overrides resolved by adjudication (see the log; one further unanimous cell is logged as reviewed under C12). Calls awaiting David's ruling: five C12 (c) CM candidates, coded HD provisionally (GT-30-A2 D1 and holistic, GT-63-A1 D1 and holistic, GT-66-A1 holistic, TO-Sanders-A2 holistic), and I-D5 for ST-28-A2 and TO-BelloConv-A1 (a conversation-partner role with no contestation), coded AS-5 as the nearest point under C6.

## 5. ENA file notes

- Same structure as the v0.7.1 ENA file, plus one added column, `OriginalPass` (Pilot or Full), so the Run 3 pass comparison remains possible. `CodingPass` reads `v8 Blind` for the 65 recoded episodes.
- One-hot dimension columns, `EO_designed` (EO intended other than NE) and `ML_designed` (ML intended other than ML-NA) follow the v0.7.1 derivation rules, verified to reproduce the v0.7.1 file exactly.
- 38 of the 65 recoded episodes differ from their v0.7.1 codes on at least one ENA field.
- Instructor and staff episodes (Learner = 0, 23 rows) remain in the file and should be excluded or analyzed separately, as in Run 3.
- `NonGenerativeTool` = 1 for TO-BelloWrite-A2 (Bon Patron), unchanged.

## 6. Not yet done

Reported profile, evidence tiers, dialogue type, epistemic object, uptake, and context fields remain unresolved for the 65 episodes. The entry-level stance fields (claim stance, AI-use stance, limitations, traces) have not yet been compared across coders. C12 has not been swept across clear (non-boundary) AS codes in the 65 episodes, such as AI first drafts that are revised (TO-MacKay-A1, TO-BelloWrite-A1, GT-19-A2, TO-KhazraLR-A2), nor across the 97 v0.7.1 episodes.
