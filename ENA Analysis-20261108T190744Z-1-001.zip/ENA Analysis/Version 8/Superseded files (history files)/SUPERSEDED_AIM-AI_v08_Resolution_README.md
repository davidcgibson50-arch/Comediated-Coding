# AIM-AI v0.8 blind recode: reliability, resolution, and ENA file

Prepared October 29, 2026, for David Gibson (Curtin University). Scope: the 65 calibration-exposed episodes (31 entries) recoded blind under Codebook v0.8 by three coders: GPTv8 (ChatGPT), CCODEv8 (Claude Code), and Claude (incognito chat).

## 1. Files in this folder

| File | Contents |
|---|---|
| `v8_IRR_by_field.csv` | Per-field agreement: three-way exact agreement, majority existence, Krippendorff's alpha (nominal), Fleiss' kappa, and pairwise Cohen's kappa |
| `AIM-AI_v08_Adjudication_Log.csv` | Every non-unanimous intended cell (178 cells): each coder's value, the majority, the final value, the basis, and a note where the call needed reasoning |
| `AIM-AI_v08_resolved_intended.csv` | Final intended codes for the 65 episodes (I-D1 to I-D5, EO, ML, holistic, Start, End, trajectory, participant, learner) |
| `AIM-AI_v08_ENA_ready_intended.csv` | The rENA input: 162 episodes (97 unchanged v0.7.1 moderated episodes plus the 65 resolved v0.8 episodes) |

## 2. Reliability summary

Agreement on the intended profile, which feeds the ENA, was moderate to good: Krippendorff's alpha .68 (D1), .84 (D2), .78 (D3), .71 (D4), .84 (D5); EO intended .70; ML intended .66; holistic intended .70. A two-of-three majority existed for 97% to 100% of intended cells. The two Claude-family coders agreed far more closely with each other (pairwise kappa .78 to .96) than either did with GPTv8 (.58 to .83), so majority agreement was not treated as independent confirmation; every non-unanimous intended cell was adjudicated against the source text and the calibration rules. Reported-profile and extension fields (Dialogue Type alpha .31; Uptake intended .40) were not resolved in this pass.

## 3. New calibration rule C12 (adopted October 29, 2026, David Gibson)

**C12: AI-first sequences (extends C5).** When a near-boundary call between AS and HD arises because the design has the AI supply a draft, answer, menu of options, or artifact first, and the learner then makes a decision on that material (selects, accepts, corrects, or revises it), code AS: the episode is driven first by what the AI does, and the learner's decision may be passive. C12 applies to D1, D2, D3, D5, the holistic configuration, and Start and End; such an episode is not Within-episode on the basis of that sequence. C12 does not apply to D4: an external verification or correction step remains HD-4 under C4. C12 is not triggered when the learner's own work comes first and the AI is consulted afterward (for example, Excel analysis then AI explanation, or a learner draft then AI critique), and it does not override a code that is unambiguous under C2 or C7.

Operationally, C12 was applied to cross-coder AS/HD splits and to R10-flagged AS/HD calls. It changed one unanimous code (TO-KhazraRQ-A1, D2 HD to AS, where the AI supplies an option menu that C2 already names as AS-2) and resolved three 2 AS / 2 HD holistic ties to AS (GT-24-D1, TO-Bentley-A1, TO-Sanders-A2).

## 4. Resolution counts

Of 178 non-unanimous intended cells, 149 were resolved by upholding the majority after review, 16 were changed or settled under C12, and 13 were three-way splits or majority overrides resolved by adjudication (see the log). Two calls are provisional pending David's ruling: I-D5 for ST-28-A2 and TO-BelloConv-A1 (a conversation-partner role with no contestation), coded AS-5 as the nearest point under C6.

## 5. ENA file notes

- Same structure as the v0.7.1 ENA file, plus one added column, `OriginalPass` (Pilot or Full), so the Run 3 pass comparison remains possible. `CodingPass` reads `v8 Blind` for the 65 recoded episodes.
- One-hot dimension columns, `EO_designed` (EO intended other than NE) and `ML_designed` (ML intended other than ML-NA) follow the v0.7.1 derivation rules, verified to reproduce the v0.7.1 file exactly.
- 37 of the 65 recoded episodes differ from their v0.7.1 codes on at least one ENA field (holistic 11, EO 6, ML 5, trajectory 14).
- Instructor and staff episodes (Learner = 0, 23 rows) remain in the file and should be excluded or analyzed separately, as in Run 3.
- `NonGenerativeTool` = 1 for TO-BelloWrite-A2 (Bon Patron), unchanged.

## 6. Not yet done

Reported profile, evidence tiers, dialogue type, epistemic object, uptake, and context fields remain unresolved for the 65 episodes. The entry-level stance fields (claim stance, AI-use stance, limitations, traces) have not yet been compared across coders. The 97 v0.7.1 episodes were not re-screened for C12.
