# AIM-AI ENA Run 5: Model 2 (dimensions plus EO and ML) on the v0.8.1 coding, results and comparison with Run 4.1

Date: October 30, 2026. Codebook: AIM-AI v0.8.3. Coding: v0.8 plus patch v0.8.1. Profile modelled: **intended (T4)**. Model 2 adds the designed epistemic-opportunity (EO) and mediational-literacy (ML) codes to the Run 4.1 dimensional model as two presence nodes (decision of October 30, 2026, option a). It follows section 4 of the Run 5 brief as amended on October 30, 2026, and supersedes the earlier Model 2 built on the unpatched file (kept only as `SUPERSEDED_*`). Run 4.1 remains the primary dimensional model; Model 2 has its own projected space and is compared with Run 4.1.

## Files in this set

- **Stage A (approved):** `AIM-AI_v08_EO_ML_Adjudication_Log.csv`, `AIM-AI_Run5_StageA_note.md`. The Stage A ENA file is superseded as model input by `AIM-AI_v081_ENA_ready_intended_EOML.csv`, which carries the same EO and ML codes.
- **ENA output (Model 2A):** `run5_points.csv`, `run5_mean_line_weights.csv` (all units and by institution), `run5_node_positions.csv`, `run5_unit_line_weights.csv`, `run5_set.rds`, `run5_model_output.txt`; Model 2B with the prefix `run5_2B_`.
- **Figures:** `run5_points_by_institution.png`, `run5_points_by_original_pass.png`, `run5_mean_network_{Georgia_Tech,Stanford,Toronto}.png` (EO and ML in green).
- **Comparison with Run 4.1:** `run5_vs_run41_units.csv`, `run5_vs_run41_nodes.csv`, `run5_vs_run41.json`.
- **Code-level tests:** `run5_code_level_tests.csv`.
- **Extension codes:** `run5_extension_values.csv`, `run5_extension_tables.csv`, `run5_extension_tables.md`, `run5_extension_no_majority.csv`, `run5_extension_summary.json`.
- **Scripts:** `run5_v081.R` (models and code-level tests), `plots5_v081.R`, `passplot5_v081.R`, `compare5_v081.py`, `extension5_v081.py`, `ext_tables_md.py`, and `stageA.py` (Stage A).

## 1. What Model 2 adds

- **Usability rule (brief, section 3).** EO intended (alpha .70) enters as `EO_designed`. ML intended (alpha .66) enters as `ML_designed` with a borderline-reliability caveat. All other extension codes are reported descriptively in section 5.
- **Validity of the carried codes (amendment, decision 1).** The EO and ML codes for the 97 non-recoded episodes are treated as valid v0.8 codes: v0.8 changed no EO or ML definition, boundary or value; C12 does not reach EO or ML; and these episodes were never exposed to calibration. No drift test is run, and the sensitivity model of brief item 7 is removed.
- **Frequencies (learner episodes).** `EO_designed` 66 of 139, `ML_designed` 56 of 139. With the 15 Run 4.1 codes, Model 2 has **17 nodes**, as the amendment expected.

## 2. ENA settings

Identical to Run 4.1 Model 1A: rENA 0.3.1 on R 4.3.3; learner episodes only (139 episodes, 81 units); units Institution + EntryID; conversation Institution + ActivityID; window 1 with window 2 as a sensitivity check; SVD rotation; `OriginalPass` for pass tests. Model 2B drops TO-BelloWrite-A2.

## 3. Results (Model 2A)

**Model quality.**
- Variance explained: SV1 27.0%, SV2 10.7% (Run 4.1: 33.9% and 12.8%). Two nodes that co-occur with many codes spread the variance.
- Goodness of fit (Pearson): SV1 .99, SV2 .97.
- Window 2 sensitivity: |r| = .994 for SV1 but **.866 for SV2**, and .781 in Model 2B. SV2 is less stable to the window choice than in Run 4.1 (.942), so we read SV2 with caution.
- Model 2B: SV1 27.0%, SV2 10.6%, goodness of fit .99 and .97.

**Axes, read from node positions.** SV1 has the same sign as Run 4.1; SV2 is reversed, which is arbitrary in SVD.
- **SV1 runs from human-led work to AI-assisted production, as in Run 4.1.**
  - Negative pole: Eng.HD (-1.26), Interp.HD (-0.97), **EO_designed (-0.46)**, Steer.HD (-0.27).
  - Positive pole: Prov.AS (2.38), Eng.AD (1.81), Eng.AS (1.44), Steer.CM (1.25), Pos.AS (0.94).
- **SV2 separates assistant positioning and human steering, with ML and EO, from provenance and AI-structured scaffolds.**
  - Positive pole: Pos.AS (1.61), **ML_designed (1.08)**, Steer.HD (0.75), Steer.CM (0.36), **EO_designed (0.32)**.
  - Negative pole: Prov.AD (-2.42), Steer.AS (-1.84), Prov.HD (-1.64), Interp.AS (-1.64), Pos.HD (-0.81).
- **Where EO and ML sit.**
  - EO sits on the human-led side of SV1. Its nearest nodes are Steer.HD (distance 0.47) and Interp.HD (0.57). It is 0.87 from the centroid of the HD triad (Eng.HD, Prov.HD, Interp.HD) and 1.90 from Pos.AS.
  - ML sits close to Steer.HD (0.34) but well up the SV2 axis, between Steer.HD and Pos.AS (1.23 from Pos.AS). It is 1.66 from the triad centroid.
  - EO therefore belongs with human interpretation and steering. ML belongs with human steering in designs that position the AI as an assistant, which is the profile of the course policies that ask students to decide and disclose how they use AI.

**EO- and ML-linked connections (mean line weights).**

| Connection | All units | Georgia Tech | Stanford | Toronto |
|---|---|---|---|---|
| Interp.HD & EO | .136 | .134 | .098 | .181 |
| Steer.HD & EO | .135 | .136 | .112 | .155 |
| Prov.HD & EO | .111 | .112 | .058 | .162 |
| Eng.HD & EO | .103 | .109 | .040 | .152 |
| Steer.HD & ML | .106 | .074 | .194 | .100 |
| Prov.HD & ML | .104 | .066 | .172 | .128 |
| Eng.HD & ML | .092 | .069 | .129 | .110 |
| Interp.HD & ML | .088 | .076 | .099 | .110 |
| EO & ML | .066 | .065 | .048 | .085 |
| Pos.AS & EO | .058 | .065 | .061 | .039 |
| Pos.AS & ML | .056 | .044 | .083 | .061 |

- EO links most strongly to human interpretation and steering everywhere, and most of all at Toronto (Interp.HD & EO .181).
- ML links are strongest at Stanford (Steer.HD & ML .194, Prov.HD & ML .172), where they rank among the five strongest connections in the network.
- EO and ML co-occur only moderately (.066).

**Institutions.**
- SV1 does not distinguish the institutions (Kruskal-Wallis p = .644).
- On SV2, Stanford sits toward the ML and assistant-positioning pole (mean +0.13, against -0.05 for Georgia Tech and 0.00 for Toronto): Kruskal-Wallis p = .064 in Model 2A and **p = .008 in Model 2B**. This is the institutional ML difference seen at code level (below). It appears only on SV2, the axis least stable to the window choice, so we treat it as a code-level finding rather than a difference in network structure.
- Mean networks:

| Institution | Strongest connections (mean line weight) |
|---|---|
| Georgia Tech | Eng.HD–Prov.HD .206, Steer.HD–Interp.HD .200, Steer.HD–Prov.HD .197 |
| Stanford | Steer.HD–Prov.HD .228, Eng.HD–Steer.HD .197, **Steer.HD–ML .194** |
| Toronto | Eng.HD–Prov.HD .196, Prov.HD–Interp.HD .188, **Interp.HD–EO .181** |

**Original coding pass.** No difference: Mann-Whitney p = .388 on SV1 and .506 on SV2.

**Code-level tests (learner episodes; Fisher with episodes treated as independent, and GEE with exchangeable correlation clustered by entry).** The patch did not change any EO or ML code, so these tests are identical to the superseded run.

| Node | Grouping | Rates | Fisher p | GEE p |
|---|---|---|---|---|
| EO | Institution | GT .46, ST .38, TO .60 | .236 | .417 |
| EO | Cluster (1, 2, 3+) | .56, .48, .39 | .289 | .412 |
| EO | 3+ vs single-episode entries | .39 vs .56 | .131 | .188 (OR 0.49) |
| ML | Institution | GT .32, ST .62, TO .47 | **.019** | **.029** |
| ML | Cluster (1, 2, 3+) | .46, .39, .36 | .642 | .613 |
| ML | 3+ vs single-episode entries | .36 vs .46 | .385 | .352 (OR 0.65) |

- ML is more common at Stanford than at Georgia Tech (GEE odds ratio 3.62, p = .011).
- EO does not differ by institution or by cluster.

## 4. Comparison with Run 4.1

| | Run 4.1 (Model 1) | Model 2 |
|---|---|---|
| Nodes | 15 | 17 (adds EO_designed, ML_designed) |
| Variance SV1, SV2 | 33.9%, 12.8% | 27.0%, 10.7% |
| Goodness of fit SV1, SV2 | .99, .98 | .99, .97 |
| Window 2 \|r\| SV1, SV2 | .995, .942 | .994, .866 |
| Model B variance SV1, SV2 | 33.9%, 12.9% | 27.0%, 10.6% |
| Institution Kruskal-Wallis p (SV1, SV2) | .726, .615 | .644, .064 (2B: .597, .008) |
| Pass Mann-Whitney p (SV1, SV2) | .398, .438 | .388, .506 |
| SV1 reading | human-led vs AI-assisted production | the same; EO joins the human-led pole |
| SV2 reading | human steering with assistant positioning vs provenance and scaffolds | the same (sign reversed); ML and EO join the steering and positioning pole |
| Unit positions vs Run 4.1 | | r = .991 (SV1), \|r\| = .861 (SV2, sign reversed) |
| Node positions vs Run 4.1 (15 shared) | | r = .976 (SV1), \|r\| = .907 (SV2) |

**Units that moved most.** Shifts relative to Run 4.1 are moderate: mean 0.14, maximum 0.30, and 18 units moved more than 0.20. Movement on SV2 tracks **ML**: the correlation between an entry's share of ML-present episodes and its SV2 shift is r = -.60 (EO: r = -.08). Entries with ML move toward the ML node (mean SV2 shift -0.08 for ML only, -0.05 for EO and ML), and entries without ML move away from it (+0.10 for neither code, +0.05 for EO only). SV1 shifts track EO (r = -.36): entries with EO move toward the human-led pole.

| Unit | EO / ML episodes (of n) | Shift SV1, SV2 (aligned) | Explanation |
|---|---|---|---|
| ST-07, ST-09 | 0 / 1 (1) | +0.08, -0.29 | ML without EO: toward the ML pole |
| ST-33, GT-34 | 1 / 1 (1) | -0.18, -0.20 | AS-profile entries with both codes: toward the human-led side and the ML pole |
| GT-16 | 1 / 0 (2) | +0.01, +0.25 | EO without ML: away from the ML pole |
| GT-35 | 1 / 0 (1) | -0.01, +0.25 | EO without ML |
| GT-14, ST-32, TO-Fischer | 1 / 1 (1) | +0.02, -0.25 | HD-profile entries with both codes: toward the ML pole |
| GT-11 | 1 / 1 (2) | -0.03, -0.24 | Both codes |

**Comparison with the superseded Model 2 (unpatched data).** On the unpatched data, SV2 shifts tracked EO (r = -.59) and window 2 stability on SV2 was .959. After the patch, the weaker CM codes no longer anchor part of SV2, ML takes over that axis, and SV2 becomes less stable. EO and ML positions relative to the HD nodes, the EO- and ML-linked connections, and the code-level tests are essentially unchanged.

## 5. Extension codes (descriptive)

Values come from the v0.8 resolution where one exists: EO and ML intended (Stage A); holistic intended, Start and End configuration (v0.8 adjudication, the C12 sweep and patch v0.8.1 with its addendum, as carried in `AIM-AI_v081_all162_intended.csv`; no holistic Mixed remains). Other families use the v0.8 three-coder majority for the 65 recoded episodes and the v0.7.1 moderated value for the 97 others, and are **provisional**. Alpha values are the v0.8 three-coder Krippendorff's alpha (65 episodes). These are consistency statistics among AI-model coding sessions, not inter-rater reliability between independent human coders. Usability status follows section 3 of the brief.

**Episodes with no v0.8 majority** (shown as "No majority" in the tables): Dialogue Type GT-09-A2, GT-30-A2; Epistemic Object GT-31-A1, GT-66-A3, TO-Sanders-A3, TO-Seward-A2; Stated Purpose GT-19-A2, GT-28-C2, GT-66-A1, ST-28-A1, ST-28-A2, ST-28-A3, TO-BelloWrite-A3; Learner Variability GT-09-A4; EO reported TO-Goldfarb-A2; ML reported GT-22-A2, GT-58-A1, TO-Goldfarb-A1; R-D1 GT-58-A1; R-D2 GT-22-A2; R-D3 GT-28-A1; Uptake reported tier GT-19-A1.

**What instructor narratives in this corpus do not supply.** The reported profile is thin because of how faculty write about their teaching, not because the codes fail to apply.
- No episode in the corpus has a T1 trace: no transcript, log or student artifact of a learner's exchange with the AI. Every reported code rests on a participant account (T2, 140 learner tier codes) or an instructor or developer observation (T3, 132).
- 69% to 78% of learner episodes are NE on each reported dimension, and Stanford's entries, which are course policies, have no reported codes at all.
- Reported uptake is NE in 87% of learner episodes. Only 18 report how learners took up AI contributions, mostly as application (UP-AP, 9).
- Designed epistemic opportunities are almost always evaluation (EO-EV, 56 of 66 EO-present learner episodes). Inherited assumptions (EO-IN, 1) and redirection of an AI frame (EO-RD, 2) are rare, because they require the narrative to show what the AI assumed and what learners then did with it. That is the kind of detail a trace supplies and a design description seldom does.

These gaps describe reporting practice in instructor-authored collections. They mark where enactment studies, with traces and learner accounts, would be needed to test the reported profile.

## 6. Interpretation (with caveats)

- **Designed epistemic opportunity belongs to the human-led pattern.** EO joins the human-led pole and links most strongly to human interpretation and steering. Opportunities to examine AI-introduced assumptions are built into activities where learners already steer and interpret, almost always as evaluation (EO-EV).
- **Designed mediational literacy accompanies human steering in assistant-positioned designs.** ML sits beside Steer.HD toward Pos.AS. It is more common at Stanford, whose entries are largely course AI policies.
- **Model 1's structure is robust to adding these nodes.** SV1 is reproduced almost exactly (r = .99). SV2 is reproduced less closely (|r| = .86) and is less stable to the window choice, so claims that rest on SV2 position should be limited.
- **Co-mediation is rare.** Under the mutual-adaptation criterion only three learner episodes are holistically CM, all from Georgia Tech, each with an AI configured to initiate, challenge or role-play (see the Run 4.1 results). This is a finding about the instructor designs and partly a consequence of the criterion.

## 7. Limitations

1. **Not independent reliability.** All coding, adjudication and patch drafting were done by sessions of AI models under shared rules. Agreement statistics are consistency tests, not inter-rater reliability between independent human coders. The Stage A adjudicator's own earlier coding session (CCODEv8) was one of the three coders; this is noted on the one ruling where it was the minority.
2. **Borderline reliability of ML intended** (alpha .66), concentrated in the R17 boundary cases flagged in Stage A.
3. **Presence nodes only.** The model does not distinguish evaluation from redirection, or framing awareness from decision-making; the values are summarized in section 5.
4. **SV2 stability.** Window 2 |r| on SV2 is .87 (.78 in Model 2B), so SV2 positions, and the Stanford separation on SV2, are less robust than SV1.
5. **Scope.** The intended (design) profile only.
6. **Figures and model objects** travel in `run41_run5_drive_bundle.zip` (see the folder README).

## References

Bowman, D., Swiecki, Z., Cai, Z., Wang, Y., Eagan, B., Linderoth, J., & Shaffer, D. W. (2021). The mathematical foundations of epistemic network analysis. In A. R. Ruis & S. B. Lee (Eds.), *Advances in quantitative ethnography* (pp. 91–105). Springer. https://doi.org/10.1007/978-3-030-67788-6_7

Hayes, A. F., & Krippendorff, K. (2007). Answering the call for a standard reliability measure for coding data. *Communication Methods and Measures, 1*(1), 77–89. https://doi.org/10.1080/19312450709336664

Liang, K.-Y., & Zeger, S. L. (1986). Longitudinal data analysis using generalized linear models. *Biometrika, 73*(1), 13–22. https://doi.org/10.1093/biomet/73.1.13

Shaffer, D. W., Collier, W., & Ruis, A. R. (2016). A tutorial on epistemic network analysis: Analyzing the structure of connections in cognitive, social, and interaction data. *Journal of Learning Analytics, 3*(3), 9–45. https://doi.org/10.18608/jla.2016.33.3

## Appendix: extension-code tables

One table per code family, learner episodes and the parallel instructor-only panel, by institution (n and percentage of episodes). Instructor-only episodes occur only at Georgia Tech and Toronto.

#### Learner panel

**EO intended** (alpha 0.70; Model 2 (EO_designed); provisional values 0%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 73 (53%) | 46 (54%) | 15 (62%) | 12 (40%) |
| EO-EV | 56 (40%) | 34 (40%) | 6 (25%) | 16 (53%) |
| EO-RE | 4 (3%) | 2 (2%) | 2 (8%) | 0 (0%) |
| EO-CH | 3 (2%) | 1 (1%) | 0 (0%) | 2 (7%) |
| EO-RD | 2 (1%) | 1 (1%) | 1 (4%) | 0 (0%) |
| EO-IN | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |

**ML intended** (alpha 0.66; Model 2 (ML_designed), borderline alpha; provisional values 0%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| ML-NA | 83 (60%) | 58 (68%) | 9 (38%) | 16 (53%) |
| ML-CW | 17 (12%) | 6 (7%) | 5 (21%) | 6 (20%) |
| ML-DD | 15 (11%) | 9 (11%) | 2 (8%) | 4 (13%) |
| ML-EP | 10 (7%) | 5 (6%) | 3 (12%) | 2 (7%) |
| ML-MX | 7 (5%) | 4 (5%) | 2 (8%) | 1 (3%) |
| ML-RA | 4 (3%) | 1 (1%) | 2 (8%) | 1 (3%) |
| ML-FR | 3 (2%) | 2 (2%) | 1 (4%) | 0 (0%) |

**Epistemic Object (EB)** (alpha 0.55; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 73 (53%) | 46 (54%) | 15 (62%) | 12 (40%) |
| Evidence and relevance | 25 (18%) | 11 (13%) | 6 (25%) | 8 (27%) |
| Perspective and bias | 14 (10%) | 11 (13%) | 2 (8%) | 1 (3%) |
| Reasoning norms | 8 (6%) | 8 (9%) | 0 (0%) | 0 (0%) |
| Multiple | 5 (4%) | 2 (2%) | 0 (0%) | 3 (10%) |
| Explanation and causality | 5 (4%) | 2 (2%) | 0 (0%) | 3 (10%) |
| Authority and credibility | 5 (4%) | 3 (4%) | 1 (4%) | 1 (3%) |
| No majority | 4 (3%) | 2 (2%) | 0 (0%) | 2 (7%) |

**Uptake intended** (alpha 0.40; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 79 (57%) | 50 (59%) | 12 (50%) | 17 (57%) |
| UP-AP | 40 (29%) | 22 (26%) | 9 (38%) | 9 (30%) |
| UP-MX | 11 (8%) | 9 (11%) | 1 (4%) | 1 (3%) |
| UP-AD | 5 (4%) | 3 (4%) | 1 (4%) | 1 (3%) |
| UP-CT | 3 (2%) | 1 (1%) | 1 (4%) | 1 (3%) |
| UP-RJ | 1 (1%) | 0 (0%) | 0 (0%) | 1 (3%) |

**Uptake reported** (alpha 0.40; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 121 (87%) | 70 (82%) | 24 (100%) | 27 (90%) |
| UP-AP | 9 (6%) | 7 (8%) | 0 (0%) | 2 (7%) |
| UP-MX | 6 (4%) | 5 (6%) | 0 (0%) | 1 (3%) |
| UP-AD | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |
| UP-CT | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |
| UP-RJ | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |

**Dialogue Type (DT)** (alpha 0.31; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 68 (49%) | 35 (41%) | 15 (62%) | 18 (60%) |
| Instructional | 23 (17%) | 18 (21%) | 2 (8%) | 3 (10%) |
| Collaborative | 20 (14%) | 12 (14%) | 5 (21%) | 3 (10%) |
| Feedback-oriented | 18 (13%) | 12 (14%) | 1 (4%) | 5 (17%) |
| Mixed | 4 (3%) | 3 (4%) | 1 (4%) | 0 (0%) |
| Reflective | 4 (3%) | 3 (4%) | 0 (0%) | 1 (3%) |
| No majority | 2 (1%) | 2 (2%) | 0 (0%) | 0 (0%) |

**Stated Purpose (DP)** (alpha 0.53; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| Critical evaluation of AI (HD) | 35 (25%) | 21 (25%) | 2 (8%) | 12 (40%) |
| Guided practice (AS) | 22 (16%) | 16 (19%) | 0 (0%) | 6 (20%) |
| Multiple | 22 (16%) | 12 (14%) | 2 (8%) | 8 (27%) |
| Independent production (HD) | 20 (14%) | 10 (12%) | 8 (33%) | 2 (7%) |
| Not stated | 14 (10%) | 8 (9%) | 6 (25%) | 0 (0%) |
| Introduce or model (AD) | 10 (7%) | 9 (11%) | 0 (0%) | 1 (3%) |
| Inquiry and refinement (CM) | 9 (6%) | 6 (7%) | 3 (12%) | 0 (0%) |
| No majority | 7 (5%) | 3 (4%) | 3 (12%) | 1 (3%) |

**Learner variability (LV)** (alpha 0.48; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| None noted | 108 (78%) | 59 (69%) | 24 (100%) | 25 (83%) |
| Prior knowledge | 13 (9%) | 13 (15%) | 0 (0%) | 0 (0%) |
| Multiple | 6 (4%) | 6 (7%) | 0 (0%) | 0 (0%) |
| Orientation toward AI | 5 (4%) | 3 (4%) | 0 (0%) | 2 (7%) |
| AI literacy | 3 (2%) | 0 (0%) | 0 (0%) | 3 (10%) |
| Self-regulation | 2 (1%) | 2 (2%) | 0 (0%) | 0 (0%) |
| No majority | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |
| Motivation | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |

**Sociotechnical Frame** (alpha 0.49; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| High-stakes assessment | 62 (45%) | 29 (34%) | 9 (38%) | 24 (80%) |
| Low-stakes or formative | 32 (23%) | 27 (32%) | 2 (8%) | 3 (10%) |
| Self-directed or optional | 25 (18%) | 22 (26%) | 0 (0%) | 3 (10%) |
| Unclear | 18 (13%) | 7 (8%) | 11 (46%) | 0 (0%) |
| Professional or workplace | 2 (1%) | 0 (0%) | 2 (8%) | 0 (0%) |

**Laurillard activity type** (alpha 0.70; Descriptive context; provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| Inquiry, production | 83 (60%) | 50 (59%) | 17 (71%) | 16 (53%) |
| Practice | 22 (16%) | 16 (19%) | 0 (0%) | 6 (20%) |
| Reflection | 12 (9%) | 4 (5%) | 2 (8%) | 6 (20%) |
| Acquisition | 10 (7%) | 9 (11%) | 0 (0%) | 1 (3%) |
| Inquiry, discussion, collaboration | 10 (7%) | 6 (7%) | 3 (12%) | 1 (3%) |
| NE | 2 (1%) | 0 (0%) | 2 (8%) | 0 (0%) |

**Holistic intended** (alpha 0.70; Descriptive context; provisional values 0%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| HD | 96 (69%) | 55 (65%) | 20 (83%) | 21 (70%) |
| AS | 34 (24%) | 21 (25%) | 4 (17%) | 9 (30%) |
| AD | 6 (4%) | 6 (7%) | 0 (0%) | 0 (0%) |
| CM | 3 (2%) | 3 (4%) | 0 (0%) | 0 (0%) |

**Start Config** (alpha 0.69; Descriptive context; provisional values 53%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| HD | 93 (67%) | 53 (62%) | 19 (79%) | 21 (70%) |
| AS | 37 (27%) | 23 (27%) | 5 (21%) | 9 (30%) |
| AD | 6 (4%) | 6 (7%) | 0 (0%) | 0 (0%) |
| CM | 3 (2%) | 3 (4%) | 0 (0%) | 0 (0%) |

**End Config** (alpha 0.66; Descriptive context; provisional values 55%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| HD | 95 (68%) | 55 (65%) | 19 (79%) | 21 (70%) |
| AS | 35 (25%) | 21 (25%) | 5 (21%) | 9 (30%) |
| AD | 6 (4%) | 6 (7%) | 0 (0%) | 0 (0%) |
| CM | 3 (2%) | 3 (4%) | 0 (0%) | 0 (0%) |

**EO reported** (alpha 0.75; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 109 (78%) | 62 (73%) | 24 (100%) | 23 (77%) |
| EO-EV | 24 (17%) | 18 (21%) | 0 (0%) | 6 (20%) |
| EO-RE | 3 (2%) | 3 (4%) | 0 (0%) | 0 (0%) |
| EO-IN | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |
| EO-RD | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |
| No majority | 1 (1%) | 0 (0%) | 0 (0%) | 1 (3%) |

**ML reported** (alpha 0.64; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| ML-NA | 103 (74%) | 56 (66%) | 24 (100%) | 23 (77%) |
| ML-DD | 11 (8%) | 9 (11%) | 0 (0%) | 2 (7%) |
| ML-EP | 10 (7%) | 9 (11%) | 0 (0%) | 1 (3%) |
| ML-CW | 7 (5%) | 6 (7%) | 0 (0%) | 1 (3%) |
| ML-MX | 3 (2%) | 2 (2%) | 0 (0%) | 1 (3%) |
| No majority | 3 (2%) | 2 (2%) | 0 (0%) | 1 (3%) |
| ML-RA | 2 (1%) | 1 (1%) | 0 (0%) | 1 (3%) |

**R-D1 Engagement Type** (alpha 0.61; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 96 (69%) | 53 (62%) | 24 (100%) | 19 (63%) |
| Coded | 43 (31%) | 32 (38%) | 0 (0%) | 11 (37%) |

**R-D2 Interaction Structure (steering)** (alpha 0.65; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 104 (75%) | 60 (71%) | 24 (100%) | 20 (67%) |
| Coded | 35 (25%) | 25 (29%) | 0 (0%) | 10 (33%) |

**R-D3 Provenance of Production** (alpha 0.65; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 101 (73%) | 56 (66%) | 24 (100%) | 21 (70%) |
| Coded | 38 (27%) | 29 (34%) | 0 (0%) | 9 (30%) |

**R-D4 Interpretive Influence** (alpha 0.79; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 97 (70%) | 50 (59%) | 24 (100%) | 23 (77%) |
| Coded | 42 (30%) | 35 (41%) | 0 (0%) | 7 (23%) |

**R-D5 Positioning (learner orientation)** (alpha 0.74; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 108 (78%) | 60 (71%) | 24 (100%) | 24 (80%) |
| Coded | 31 (22%) | 25 (29%) | 0 (0%) | 6 (20%) |

**Evidence tiers across all reported fields** (T1 0, T2 140, T3 132, no majority 1; 839 fields carry no tier because the field is NE)


#### Instructor-only panel

**EO intended** (alpha 0.70; Model 2 (EO_designed); provisional values 0%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 20 (87%) | 18 (90%) | 2 (67%) |
| EO-EV | 3 (13%) | 2 (10%) | 1 (33%) |

**ML intended** (alpha 0.66; Model 2 (ML_designed), borderline alpha; provisional values 0%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| ML-NA | 20 (87%) | 18 (90%) | 2 (67%) |
| ML-DD | 2 (9%) | 1 (5%) | 1 (33%) |
| ML-CW | 1 (4%) | 1 (5%) | 0 (0%) |

**Epistemic Object (EB)** (alpha 0.55; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 20 (87%) | 18 (90%) | 2 (67%) |
| Perspective and bias | 2 (9%) | 1 (5%) | 1 (33%) |
| Evidence and relevance | 1 (4%) | 1 (5%) | 0 (0%) |

**Uptake intended** (alpha 0.40; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| UP-AP | 11 (48%) | 10 (50%) | 1 (33%) |
| NE | 9 (39%) | 7 (35%) | 2 (67%) |
| UP-AD | 2 (9%) | 2 (10%) | 0 (0%) |
| UP-MX | 1 (4%) | 1 (5%) | 0 (0%) |

**Uptake reported** (alpha 0.40; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 10 (43%) | 9 (45%) | 1 (33%) |
| UP-AP | 9 (39%) | 8 (40%) | 1 (33%) |
| UP-AD | 3 (13%) | 2 (10%) | 1 (33%) |
| UP-MX | 1 (4%) | 1 (5%) | 0 (0%) |

**Dialogue Type (DT)** (alpha 0.31; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 16 (70%) | 13 (65%) | 3 (100%) |
| Collaborative | 5 (22%) | 5 (25%) | 0 (0%) |
| Instructional | 2 (9%) | 2 (10%) | 0 (0%) |

**Stated Purpose (DP)** (alpha 0.53; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| Not stated | 19 (83%) | 16 (80%) | 3 (100%) |
| Critical evaluation of AI (HD) | 1 (4%) | 1 (5%) | 0 (0%) |
| Independent production (HD) | 1 (4%) | 1 (5%) | 0 (0%) |
| Introduce or model (AD) | 1 (4%) | 1 (5%) | 0 (0%) |
| Multiple | 1 (4%) | 1 (5%) | 0 (0%) |

**Learner variability (LV)** (alpha 0.48; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| None noted | 22 (96%) | 19 (95%) | 3 (100%) |
| Orientation toward AI | 1 (4%) | 1 (5%) | 0 (0%) |

**Sociotechnical Frame** (alpha 0.49; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| Instructor preparation | 20 (87%) | 18 (90%) | 2 (67%) |
| Professional or workplace | 2 (9%) | 1 (5%) | 1 (33%) |
| Unclear | 1 (4%) | 1 (5%) | 0 (0%) |

**Laurillard activity type** (alpha 0.70; Descriptive context; provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 23 (100%) | 20 (100%) | 3 (100%) |

**Holistic intended** (alpha 0.70; Descriptive context; provisional values 0%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| HD | 13 (57%) | 12 (60%) | 1 (33%) |
| AS | 8 (35%) | 6 (30%) | 2 (67%) |
| AD | 2 (9%) | 2 (10%) | 0 (0%) |

**Start Config** (alpha 0.69; Descriptive context; provisional values 44%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| HD | 13 (57%) | 12 (60%) | 1 (33%) |
| AS | 8 (35%) | 6 (30%) | 2 (67%) |
| AD | 2 (9%) | 2 (10%) | 0 (0%) |

**End Config** (alpha 0.66; Descriptive context; provisional values 44%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| HD | 13 (57%) | 12 (60%) | 1 (33%) |
| AS | 8 (35%) | 6 (30%) | 2 (67%) |
| AD | 2 (9%) | 2 (10%) | 0 (0%) |

**EO reported** (alpha 0.75; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 20 (87%) | 18 (90%) | 2 (67%) |
| EO-EV | 3 (13%) | 2 (10%) | 1 (33%) |

**ML reported** (alpha 0.64; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| ML-NA | 20 (87%) | 18 (90%) | 2 (67%) |
| ML-CW | 1 (4%) | 1 (5%) | 0 (0%) |
| ML-DD | 1 (4%) | 0 (0%) | 1 (33%) |
| ML-MX | 1 (4%) | 1 (5%) | 0 (0%) |

**R-D1 Engagement Type** (alpha 0.61; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| Coded | 14 (61%) | 12 (60%) | 2 (67%) |
| NE | 9 (39%) | 8 (40%) | 1 (33%) |

**R-D2 Interaction Structure (steering)** (alpha 0.65; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| Coded | 16 (70%) | 13 (65%) | 3 (100%) |
| NE | 7 (30%) | 7 (35%) | 0 (0%) |

**R-D3 Provenance of Production** (alpha 0.65; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| Coded | 19 (83%) | 16 (80%) | 3 (100%) |
| NE | 4 (17%) | 4 (20%) | 0 (0%) |

**R-D4 Interpretive Influence** (alpha 0.79; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 12 (52%) | 10 (50%) | 2 (67%) |
| Coded | 11 (48%) | 10 (50%) | 1 (33%) |

**R-D5 Positioning (learner orientation)** (alpha 0.74; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| Coded | 15 (65%) | 12 (60%) | 3 (100%) |
| NE | 8 (35%) | 8 (40%) | 0 (0%) |

**Evidence tiers across all reported fields** (T1 0, T2 91, T3 3; 90 fields carry no tier because the field is NE)

