# Run 5: Model 2 on the v0.8.1 (patched) coding: the Run 4.1 dimension codes plus the EO and ML
# presence nodes. Adapted from run4.R/run41.R with the Run 5 brief as amended on October 30, 2026:
# patched EOML input, run5_* outputs, EO- and ML-linked connections and code-level tests. The
# non-recoded sensitivity model was removed by the amendment (section 4, decision 1).
suppressMessages({library(rENA); library(geepack)})
setwd(commandArgs(TRUE)[1])
dall <- read.csv("AIM-AI_v081_ENA_ready_intended_EOML.csv", check.names=FALSE)
d0 <- dall[dall$Learner==1,]
all20 <- grep("^(Eng|Steer|Prov|Interp|Pos)\\.(AD|AS|CM|HD)$", names(d0), value=TRUE)
eoml <- c("EO_designed","ML_designed")
freq <- colSums(d0[,c(all20,eoml)]); thr3 <- c(all20,eoml)[freq >= 3]
cat("rENA", as.character(packageVersion("rENA")), "on", R.version.string, "\n")
cat("Learner episodes:", nrow(d0), " units:", length(unique(paste(d0$Institution,d0$EntryID))), "\n")
cat("Code frequencies:\n"); print(freq)
cat("Codes kept at threshold 3 (", length(thr3), "):", paste(thr3, collapse=", "), "\n")
fit <- function(d, codes, w){ acc <- ena.accumulate.data(units=d[,c("Institution","EntryID")], conversation=d[,c("Institution","ActivityID")], metadata=d[,"Institution",drop=FALSE], codes=d[,codes], window.size.back=w); ena.make.set(acc) }
linked <- function(v, node, k=6){ v <- v[grepl(paste0("(^|& )",node,"($| &)"), names(v))]; round(sort(v, decreasing=TRUE)[1:k],3) }
report <- function(tag, d, codes, save=NULL){
  set <- fit(d, codes, 1); set2 <- fit(d, codes, 2)
  pass <- tapply(d$OriginalPass, d$EntryID, function(x) x[1])
  pts <- as.data.frame(set$points); inst <- pts$Institution; sv <- as.matrix(set$points)[,1:2]
  eid <- sub(".*::","",pts$ENA_UNIT); pp <- pass[eid]
  cat("\n==========", tag, "==========\n"); cat("Codes (", length(codes), "):", paste(codes, collapse=", "), "\n")
  cat("Episodes:", nrow(d), " Units:", nrow(pts), "\n"); print(table(inst)); print(table(pp))
  cat("Variance SV1, SV2:", round(set$model$variance[1:2],3), "\n"); print(ena.correlations(set))
  for(k in 1:2){kt<-kruskal.test(sv[,k]~factor(inst)); cat(sprintf("Institution SV%d Kruskal-Wallis chi2=%.2f p=%.3f\n",k,kt$statistic,kt$p.value))}
  for(k in 1:2){wt<-wilcox.test(sv[pp=="Pilot",k],sv[pp=="Full",k]); cat(sprintf("Original pass SV%d Mann-Whitney W=%.0f p=%.3f\n",k,wt$statistic,wt$p.value))}
  print(aggregate(sv,list(Institution=inst),mean)); print(aggregate(sv,list(Pass=pp),mean))
  p2<-as.matrix(set2$points)[,1:2]; cat("Window 1 vs 2 |r| SV1:",round(abs(cor(sv[,1],p2[,1])),3)," SV2:",round(abs(cor(sv[,2],p2[,2])),3),"\n")
  nodes<-as.data.frame(set$rotation$nodes); cat("Node positions:\n"); print(nodes[order(nodes[,2]),1:3],row.names=FALSE)
  lw<-as.matrix(set$line.weights); cn<-colnames(lw); mlw<-sapply(split(as.data.frame(lw),inst),colMeans)
  allm <- setNames(colMeans(lw), cn)
  for(g in colnames(mlw)){v<-setNames(mlw[,g],cn);o<-order(-v)[1:6];cat("Top connections",g,"\n");print(round(v[o],3))}
  for(nd in intersect(eoml, codes)){
    cat("Strongest", nd, "connections, all units\n"); print(linked(allm, nd))
    for(g in colnames(mlw)){ cat("  ", g, "\n"); print(linked(setNames(mlw[,g],cn), nd, 4)) }
  }
  if(!is.null(save)){
    write.csv(data.frame(Unit=pts$ENA_UNIT,Institution=inst,OriginalPass=pp,SV1=round(sv[,1],4),SV2=round(sv[,2],4)),paste0(save,"_points.csv"),row.names=FALSE)
    write.csv(data.frame(connection=cn,All=round(allm,4),round(mlw,4)),paste0(save,"_mean_line_weights.csv"),row.names=FALSE)
    write.csv(data.frame(code=nodes$code,SV1=round(nodes[,2],4),SV2=round(nodes[,3],4)),paste0(save,"_node_positions.csv"),row.names=FALSE)
    write.csv(data.frame(Unit=pts$ENA_UNIT,round(lw,4),check.names=FALSE),paste0(save,"_unit_line_weights.csv"),row.names=FALSE)
    saveRDS(set,paste0(save,"_set.rds"))
  }
  invisible(set)
}
report("Model 2A (primary): Run 4.1 codes plus EO and ML presence, all learner episodes", d0, thr3, save="run5")
d1 <- d0[d0$NonGenerativeTool==0,]; thr3b <- c(all20,eoml)[colSums(d1[,c(all20,eoml)])>=3]
report("Model 2B: without TO-BelloWrite-A2 (NonGenerativeTool)", d1, thr3b, save="run5_2B")

# Code-level tests of EO_designed and ML_designed by institution and by episode-count cluster.
cat("\n========== Code-level tests (learner episodes) ==========\n")
nep <- table(d0$EntryID); d0$cluster <- factor(ifelse(nep[d0$EntryID]>=3,"3+",as.character(nep[d0$EntryID])), levels=c("1","2","3+"))
d0$Institution <- factor(d0$Institution); d0 <- d0[order(d0$EntryID, d0$EpisodeOrder),]
tests <- list()
for(nd in eoml) for(gv in c("Institution","cluster")){
  tb <- table(d0[[gv]], d0[[nd]]); fp <- fisher.test(tb)$p.value
  g <- geeglm(as.formula(paste(nd,"~",gv)), family=binomial, id=factor(d0$EntryID), data=d0, corstr="exchangeable")
  a <- anova(g)
  rates <- round(tb[,"1"]/rowSums(tb),3)
  cat(sprintf("%s by %s: %s | Fisher p=%.4f | GEE Wald chi2=%.2f df=%d p=%.4f\n", nd, gv,
      paste(sprintf("%s %.2f (%d/%d)", names(rates), rates, tb[,"1"], rowSums(tb)), collapse="; "), fp, a$X2, a$Df, a$`P(>|Chi|)`))
  cf <- summary(g)$coefficients
  for(r in rownames(cf)[-1]) cat(sprintf("   %s OR=%.2f p=%.4f\n", r, exp(cf[r,"Estimate"]), cf[r,"Pr(>|W|)"]))
  tests[[length(tests)+1]] <- data.frame(node=nd, grouping=gv, level=names(rates), n=as.vector(rowSums(tb)), present=as.vector(tb[,"1"]), prop=as.vector(rates),
    fisher_p=round(fp,4), gee_wald_chi2=round(a$X2,3), gee_df=a$Df, gee_p=round(a$`P(>|Chi|)`,4))
  # 3+ against single-episode entries and against all others, as in the Run 4 cluster report.
  if(gv=="cluster") for(cmp in c("1","other")){
    dd <- if(cmp=="1") d0[d0$cluster %in% c("1","3+"),] else d0
    dd$three <- as.integer(dd$cluster=="3+"); tb2 <- table(dd$three, dd[[nd]])
    g2 <- geeglm(as.formula(paste(nd,"~ three")), family=binomial, id=factor(dd$EntryID), data=dd, corstr="exchangeable")
    cf2 <- summary(g2)$coefficients
    cat(sprintf("   3+ vs %s: Fisher p=%.4f | GEE OR=%.2f p=%.4f\n", cmp, fisher.test(tb2)$p.value, exp(cf2["three","Estimate"]), cf2["three","Pr(>|W|)"]))
    tests[[length(tests)+1]] <- data.frame(node=nd, grouping=paste0("3+ vs ",cmp), level="3+", n=sum(dd$three), present=sum(dd[[nd]][dd$three==1]),
      prop=round(mean(dd[[nd]][dd$three==1]),3), fisher_p=round(fisher.test(tb2)$p.value,4), gee_wald_chi2=round(cf2["three","Wald"],3), gee_df=1, gee_p=round(cf2["three","Pr(>|W|)"],4))
  }
}
write.csv(do.call(rbind, tests), "run5_code_level_tests.csv", row.names=FALSE)
