"""Compare Run 4.1 (v0.8.1) with Run 4 (v0.8): unit positions, movers linked to patch rows, and nodes.
Usage: python compare41.py <work_dir> <patch_log.csv> <new_prefix> <old_prefix> <tag>
Writes <tag>_units.csv, <tag>_nodes.csv and <tag>.json in work_dir."""
import json, os, sys
import numpy as np, pandas as pd
os.chdir(sys.argv[1]); patch = pd.read_csv(sys.argv[2]); new, old, tag = sys.argv[3], sys.argv[4], sys.argv[5]
pn, po = pd.read_csv(new + "_points.csv"), pd.read_csv(old + "_points.csv")
nn, no = pd.read_csv(new + "_node_positions.csv"), pd.read_csv(old + "_node_positions.csv")
m = po.merge(pn[["Unit", "SV1", "SV2"]], on="Unit", suffixes=("_old", "_new"))
out, sign = {}, {}
for k in ("SV1", "SV2"):
    r = np.corrcoef(m[k + "_old"], m[k + "_new"])[0, 1]; sign[k] = 1 if r >= 0 else -1; out["r_" + k] = round(float(r), 3)
    m[k + "_new_aligned"] = sign[k] * m[k + "_new"]; m["d" + k] = m[k + "_new_aligned"] - m[k + "_old"]
out["r_SV1old_SV2new"] = round(float(np.corrcoef(m.SV1_old, m.SV2_new)[0, 1]), 3)
out["r_SV2old_SV1new"] = round(float(np.corrcoef(m.SV2_old, m.SV1_new)[0, 1]), 3)
m["Shift"] = np.hypot(m.dSV1, m.dSV2)
p = patch[~patch.New.astype(str).str.contains("unchanged")].copy()
p["Unit"] = p.EpisodeID.map(lambda e: e.rsplit("-", 1)[0])
ena = pd.read_csv("AIM-AI_v081_ENA_ready_intended_EOML.csv")
inst = ena.drop_duplicates("EntryID").set_index("EntryID").Institution
p["Unit"] = p.Unit.map(lambda u: inst[u] + "::" + u)
pr = p.groupby("Unit").apply(lambda g: "; ".join(f"{e} {f} {o}->{n}" for e, f, o, n in zip(g.EpisodeID, g.Field, g.Old, g.New))).rename("PatchRows")
m = m.merge(pr, on="Unit", how="left").fillna({"PatchRows": "none"})
m["Patched"] = m.PatchRows != "none"
m = m.sort_values("Shift", ascending=False)
m.round(4).to_csv(tag + "_units.csv", index=False)
out["shift"] = m.Shift.describe().round(3).to_dict()
out["mean_shift_patched"] = round(float(m[m.Patched].Shift.mean()), 3); out["mean_shift_unpatched"] = round(float(m[~m.Patched].Shift.mean()), 3)
out["n_patched_units"] = int(m.Patched.sum()); out["sign"] = sign
out["top10"] = m.head(10)[["Unit", "Shift", "dSV1", "dSV2", "PatchRows"]].round(3).to_dict(orient="records")
x = no.merge(nn, on="code", how="outer", suffixes=("_old", "_new"))
for k in ("SV1", "SV2"): x[k + "_new_aligned"] = sign[k] * x[k + "_new"]
s = x.dropna(); out["node_r_SV1"] = round(float(np.corrcoef(s.SV1_old, s.SV1_new_aligned)[0, 1]), 3); out["node_r_SV2"] = round(float(np.corrcoef(s.SV2_old, s.SV2_new_aligned)[0, 1]), 3)
out["nodes_only_old"] = x[x.SV1_new.isna()].code.tolist(); out["nodes_only_new"] = x[x.SV1_old.isna()].code.tolist()
x.round(4).to_csv(tag + "_nodes.csv", index=False)
json.dump(out, open(tag + ".json", "w"), indent=1)
print(json.dumps(out, indent=1))
