"""Descriptive summary of the AIM-AI extension codes (Run 5 brief, section 5), on the v0.8.1 files.

Values per episode: v0.8-resolved where a field was resolved under v0.8 (EO and ML intended from the
Stage A log; holistic intended, Start and End configuration from the v0.8 adjudication log or a
unanimous three-coder value, with the C12 sweep applied; holistic from the ENA file); otherwise the v0.8 three-coder majority for the 65 recoded episodes and
the v0.7.1 moderated value for the 97 others, both marked provisional.

Usage: python extension5.py <drive_dir> <work_dir>
"""
import json
import os
import sys

import pandas as pd

drive, work = sys.argv[1], sys.argv[2]
ena = pd.read_csv(os.path.join(work, "AIM-AI_v081_ENA_ready_intended_EOML.csv"))
v071 = pd.read_csv(os.path.join(drive, "AIM-AI_v071_moderated_coding_form.csv")).set_index("Episode ID")
coders = {n: pd.read_csv(os.path.join(drive, f)).set_index("Episode ID") for n, f in
          [("GPTv8", "episodes_GPTv8.csv"), ("CCODEv8", "episodes_CCODEv8.csv"), ("ClaudeIncog", "episodes_ClaudeIncog_parsed.csv")]}
prior = pd.read_csv(os.path.join(drive, "AIM-AI_v08_Adjudication_Log.csv"))
sweep = pd.read_csv(os.path.join(drive, "AIM-AI_v08_C12_Sweep_Log.csv"))
SWEEP_FIELD = {"St": "Start Config", "En": "End Config"}
irr = pd.read_csv(os.path.join(drive, "v8_IRR_by_field.csv"))
irr.columns = [c.strip() for c in irr.columns]
alpha = dict(zip(irr.Field.str.strip(), irr["Krippendorff alpha"]))

RESOLVED = {"Holistic: intended (judgment)", "Start Config", "End Config"}
STATUS = {
    "EO intended": "Model 2 (EO_designed)",
    "ML intended": "Model 2 (ML_designed), borderline alpha",
    "Holistic: intended (judgment)": "Descriptive context",
    "Start Config": "Descriptive context",
    "End Config": "Descriptive context",
    "Laurillard Activity Type (context)": "Descriptive context",
}
FIELDS = ["EO intended", "ML intended", "Epistemic Object (EB)", "Uptake intended", "Uptake reported",
          "Dialogue Type (DT)", "Stated Purpose (DP)", "Learner Variability Noted (LV)", "Sociotechnical Frame",
          "Laurillard Activity Type (context)", "Holistic: intended (judgment)", "Start Config", "End Config",
          "EO reported", "ML reported"]
REPORTED = ["R-D1 Engagement Type", "R-D2 Interaction Structure (steering)", "R-D3 Provenance of Production",
            "R-D4 Interpretive Influence", "R-D5 Positioning (learner orientation)"]
TIERS = ["R-D1 Tier", "R-D2 Tier", "R-D3 Tier", "R-D4 Tier", "R-D5 Tier", "EO reported tier", "ML reported tier", "Uptake reported tier"]


def norm(field, v):
    if pd.isna(v) or str(v).strip() == "":
        return "NE" if "Tier" not in field and "tier" not in field else "none"
    v = str(v).strip()
    if field == "ML reported" and v == "NE":
        return "ML-NA"
    return v


recoded = set(ena.loc[ena.CodingPass == "v8 Blind", "EpisodeID"])
eoml = ena.set_index("EpisodeID")
rows, nomaj = [], []
for e in ena.EpisodeID:
    rec = {"EpisodeID": e}
    for f in FIELDS + REPORTED + TIERS:
        if f == "Holistic: intended (judgment)":
            # The ENA file carries the final holistic code (v0.8 resolution and C12 sweep applied).
            rec[f], rec[f + "|src"] = eoml.at[e, "HolisticIntended"], ("v0.8 resolved" if e in recoded else "v0.7.1 + C12 sweep")
            continue
        if e not in recoded:
            rec[f], rec[f + "|src"] = norm(f, v071.at[e, f]), "v0.7.1 (provisional)"
            if f in ("EO intended", "ML intended"):
                rec[f + "|src"] = "v0.7.1 carried"
            continue
        if f == "EO intended":
            rec[f], rec[f + "|src"] = eoml.at[e, "EO_intended_v08"], "v0.8 resolved"
            continue
        if f == "ML intended":
            rec[f], rec[f + "|src"] = eoml.at[e, "ML_intended_v08"], "v0.8 resolved"
            continue
        vals = [norm(f, coders[c].at[e, f]) for c in coders]
        vc = pd.Series(vals).value_counts()
        if f in RESOLVED:
            fin = prior[(prior.EpisodeID == e) & (prior.Field == f)]
            if len(fin):
                rec[f], rec[f + "|src"] = fin.Final.iloc[0], "v0.8 resolved"
                continue
            if f == "Holistic: intended (judgment)":
                rec[f], rec[f + "|src"] = eoml.at[e, "HolisticIntended"], "v0.8 resolved"
                continue
        if vc.iloc[0] >= 2:
            rec[f] = vc.index[0]
            rec[f + "|src"] = "v0.8 resolved" if (f in RESOLVED and vc.iloc[0] == 3) else "v0.8 majority (provisional)"
        else:
            rec[f], rec[f + "|src"] = "No majority", "v0.8 no majority"
            nomaj.append({"EpisodeID": e, "Field": f, "GPTv8": vals[0], "CCODEv8": vals[1], "ClaudeIncog": vals[2]})
    rows.append(rec)
for _, r in sweep[sweep.Field.isin(SWEEP_FIELD)].iterrows():
    rec = next(x for x in rows if x["EpisodeID"] == r.EpisodeID)
    f = SWEEP_FIELD[r.Field]
    assert rec[f] == r.Before, (r.EpisodeID, f, rec[f], r.Before)
    rec[f] = r.After
    rec[f + "|src"] = rec[f + "|src"].replace("v0.7.1 (provisional)", "v0.7.1 + C12 sweep") + "; C12 sweep"
# v0.8.1: holistic, Start and End are taken from the patched all162 file, which carries the v0.8
# resolution, the C12 sweep, patch v0.8.1 and the GT-41-A1 correction.
a081 = pd.read_csv(os.path.join(work, "AIM-AI_v081_all162_intended.csv")).set_index("Episode ID")
for rec in rows:
    e = rec["EpisodeID"]
    for f, col in (("Holistic: intended (judgment)", "HolisticIntended"), ("Start Config", "StartConfig"), ("End Config", "EndConfig")):
        if rec[f] != a081.at[e, col]:
            rec[f + "|src"] += "; patch v0.8.1"
        rec[f] = a081.at[e, col]
vals = pd.DataFrame(rows).merge(ena[["EpisodeID", "Institution", "Learner"]], on="EpisodeID")
# Holistic intended must agree with the ENA file, which carries the v0.8-resolved holistic code.
chk = vals.merge(ena[["EpisodeID", "HolisticIntended"]], on="EpisodeID")
mism = chk[chk["Holistic: intended (judgment)"] != chk.HolisticIntended]
vals.to_csv(os.path.join(work, "run5_extension_values.csv"), index=False)
pd.DataFrame(nomaj).to_csv(os.path.join(work, "run5_extension_no_majority.csv"), index=False)


def table(df, field, panel):
    out = []
    groups = [("All", df)] + [(i, df[df.Institution == i]) for i in ("Georgia Tech", "Stanford", "Toronto")]
    for gname, g in groups:
        n = len(g)
        for val, k in g[field].value_counts().items():
            out.append({"Family": field, "Panel": panel, "Group": gname, "Value": val, "n": int(k), "N": n,
                        "pct": round(100 * k / n, 1) if n else None,
                        "alpha": alpha.get(field), "Status": STATUS.get(field, "Descriptive only (insufficient evidence)"),
                        "Provisional_share": round(float(g[field + "|src"].str.contains("provisional|no majority").mean()), 3) if n else None})
    return out


tabs = []
for panel, df in (("Learner", vals[vals.Learner == 1]), ("Instructor-only", vals[vals.Learner == 0])):
    for f in FIELDS:
        tabs += table(df, f, panel)
    # Reported-profile coverage: share NE per reported dimension, and tier distribution.
    for f in REPORTED:
        tabs += table(df.assign(**{f: df[f].where(df[f] == "NE", "Coded")}), f, panel)
    for f in TIERS:
        tabs += table(df, f, panel)
tabs = pd.DataFrame(tabs)
tabs.to_csv(os.path.join(work, "run5_extension_tables.csv"), index=False)

L = vals[vals.Learner == 1]
summary = {
    "episodes": len(vals), "learner": int(len(L)), "instructor_only": int((vals.Learner == 0).sum()),
    "holistic_mismatch_with_ENA": mism.EpisodeID.tolist(),
    "no_majority": pd.DataFrame(nomaj).groupby("Field").EpisodeID.apply(list).to_dict() if nomaj else {},
    "learner_reported_NE_share": {f: round(float((L[f] == "NE").mean()), 3) for f in REPORTED + ["EO reported", "Uptake reported"]},
    "learner_ML_reported_NA_share": round(float((L["ML reported"] == "ML-NA").mean()), 3),
    "learner_EO_intended": L["EO intended"].value_counts().to_dict(),
    "learner_EO_reported": L["EO reported"].value_counts().to_dict(),
    "learner_uptake_reported": L["Uptake reported"].value_counts().to_dict(),
    "all_tiers_learner": pd.concat([L[t] for t in TIERS]).value_counts().to_dict(),
    "T1_anywhere": int(pd.concat([vals[t] for t in TIERS]).eq("T1").sum()),
}
json.dump(summary, open(os.path.join(work, "run5_extension_summary.json"), "w"), indent=1, default=str)
print(json.dumps(summary, indent=1, default=str))
