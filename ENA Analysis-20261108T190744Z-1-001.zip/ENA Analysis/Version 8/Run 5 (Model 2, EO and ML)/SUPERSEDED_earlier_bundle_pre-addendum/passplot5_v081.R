suppressMessages(library(rENA)); setwd(commandArgs(TRUE)[1])  # folder holding run5_points.csv and run5_set.rds; outputs are written here
p<-read.csv("run5_points.csv"); set<-readRDS("run5_set.rds"); cols<-c(Pilot="#7A7A7A",Full="#D55E00")
png("run5_points_by_original_pass.png",1000,950,res=130)
lim<-c(-1,1)*max(abs(c(p$SV1,p$SV2)))*1.2
plot(p$SV1,p$SV2,col=adjustcolor(cols[p$OriginalPass],0.8),pch=19,xlim=lim,ylim=lim,asp=1,
  xlab=sprintf("SV1 (%.0f%%)",100*set$model$variance[1]),ylab=sprintf("SV2 (%.0f%%)",100*set$model$variance[2]),main="Run 5 (Model 2) entries by original coding pass",cex.main=1)
abline(h=0,v=0,col="grey88"); m<-aggregate(cbind(SV1,SV2)~OriginalPass,p,mean); points(m$SV1,m$SV2,pch=22,cex=2.4,bg=cols[m$OriginalPass])
n<-table(p$OriginalPass); legend("bottomleft",c(sprintf("Pilot (%d entries)",n[["Pilot"]]),sprintf("Full pass (%d entries)",n[["Full"]])),col=cols[c("Pilot","Full")],pch=19,bty="n"); dev.off()
