"""Compare Model 2 (Run 5) with Run 4.1 (Model 1 on v0.8.1): unit positions, movers explained by EO and ML codes,
and node positions for the shared codes.

Usage: python compare5.py <work_dir>
Inputs in work_dir: run5_points.csv, run41_points.csv, run5_node_positions.csv, run41_node_positions.csv,
AIM-AI_v081_ENA_ready_intended_EOML.csv. Outputs: run5_vs_run41_units.csv, run5_vs_run41_nodes.csv, run5_vs_run41.json.
"""
import json
import os
import sys

import numpy as np
import pandas as pd

os.chdir(sys.argv[1])
p5 = pd.read_csv("run5_points.csv")
p4 = pd.read_csv("run41_points.csv")
n5 = pd.read_csv("run5_node_positions.csv")
n4 = pd.read_csv("run41_node_positions.csv")
d = pd.read_csv("AIM-AI_v081_ENA_ready_intended_EOML.csv")
d = d[d.Learner == 1]

m = p4.merge(p5[["Unit", "SV1", "SV2"]], on="Unit", suffixes=("_run41", "_run5"))
assert len(m) == 81
out = {}
sign = {}
for k in ("SV1", "SV2"):
    r = np.corrcoef(m[k + "_run41"], m[k + "_run5"])[0, 1]
    sign[k] = 1 if r >= 0 else -1
    out["r_" + k] = round(float(r), 3)
# Cross-axis correlations, in case the axes swap.
out["r_SV1run41_SV2run5"] = round(float(np.corrcoef(m.SV1_run41, m.SV2_run5)[0, 1]), 3)
out["r_SV2run41_SV1run5"] = round(float(np.corrcoef(m.SV2_run41, m.SV1_run5)[0, 1]), 3)
for k in ("SV1", "SV2"):
    m[k + "_run5_aligned"] = sign[k] * m[k + "_run5"]
    m["d" + k] = m[k + "_run5_aligned"] - m[k + "_run41"]
m["Shift"] = np.hypot(m.dSV1, m.dSV2)

d["Unit"] = d.Institution + "::" + d.EntryID
g = d.groupby("Unit").agg(Episodes=("EpisodeID", "size"), EO_episodes=("EO_designed", "sum"),
                          ML_episodes=("ML_designed", "sum"), Source=("EOML_Source", "first"),
                          EO_values=("EO_intended_v08", lambda s: ";".join(s.dropna().astype(str))),
                          ML_values=("ML_intended_v08", lambda s: ";".join(s.dropna().astype(str))))
g["EO_share"] = (g.EO_episodes / g.Episodes).round(3)
g["ML_share"] = (g.ML_episodes / g.Episodes).round(3)
m = m.merge(g.reset_index(), on="Unit")
m["EOML_pattern"] = np.select([(m.EO_share > 0) & (m.ML_share > 0), m.EO_share > 0, m.ML_share > 0],
                              ["EO and ML", "EO only", "ML only"], "neither")
m = m.sort_values("Shift", ascending=False)
cols = ["Unit", "Institution", "OriginalPass", "Source", "Episodes", "EO_episodes", "ML_episodes", "EO_share", "ML_share",
        "EOML_pattern", "EO_values", "ML_values", "SV1_run41", "SV2_run41", "SV1_run5_aligned", "SV2_run5_aligned", "dSV1", "dSV2", "Shift"]
m[cols].round(4).to_csv("run5_vs_run41_units.csv", index=False)

out["mean_shift_by_pattern"] = m.groupby("EOML_pattern").Shift.agg(["count", "mean", "median"]).round(3).to_dict(orient="index")
out["mean_dSV1_by_pattern"] = m.groupby("EOML_pattern").dSV1.mean().round(3).to_dict()
out["mean_dSV2_by_pattern"] = m.groupby("EOML_pattern").dSV2.mean().round(3).to_dict()
out["corr_shift_EO_share"] = round(float(np.corrcoef(m.Shift, m.EO_share)[0, 1]), 3)
out["corr_shift_ML_share"] = round(float(np.corrcoef(m.Shift, m.ML_share)[0, 1]), 3)
out["corr_dSV2_EO_share"] = round(float(np.corrcoef(m.dSV2, m.EO_share)[0, 1]), 3)
out["corr_dSV2_ML_share"] = round(float(np.corrcoef(m.dSV2, m.ML_share)[0, 1]), 3)
out["corr_dSV1_EO_share"] = round(float(np.corrcoef(m.dSV1, m.EO_share)[0, 1]), 3)
out["corr_dSV1_ML_share"] = round(float(np.corrcoef(m.dSV1, m.ML_share)[0, 1]), 3)
out["sign"] = sign
out["top12"] = m[cols].head(12).round(3).to_dict(orient="records")

nn = n4.merge(n5, on="code", how="outer", suffixes=("_run41", "_run5"))
nn["SV1_run5_aligned"] = sign["SV1"] * nn.SV1_run5
nn["SV2_run5_aligned"] = sign["SV2"] * nn.SV2_run5
shared = nn.dropna()
out["node_r_SV1"] = round(float(np.corrcoef(shared.SV1_run41, shared.SV1_run5_aligned)[0, 1]), 3)
out["node_r_SV2"] = round(float(np.corrcoef(shared.SV2_run41, shared.SV2_run5_aligned)[0, 1]), 3)
nn.round(4).to_csv("run5_vs_run41_nodes.csv", index=False)
json.dump(out, open("run5_vs_run41.json", "w"), indent=1)
print(json.dumps({k: v for k, v in out.items() if k != "top12"}, indent=1))
print(m[cols].head(15).round(3).to_string())
