# Run 4.1: Model 1 on the v0.8.1 (patched) coding. run4.R with the v0.8.1 input, run41_* outputs,
# and the Run 4 17-code list as the comparison model in place of the fixed 16-code list.
suppressMessages(library(rENA))
setwd(commandArgs(TRUE)[1])
d0 <- read.csv("AIM-AI_v081_ENA_ready_intended_EOML.csv", check.names=FALSE); d0 <- d0[d0$Learner==1,]
all20 <- grep("^(Eng|Steer|Prov|Interp|Pos)\\.(AD|AS|CM|HD)$", names(d0), value=TRUE)
run4codes <- c("Eng.AD","Eng.AS","Eng.CM","Eng.HD","Steer.AS","Steer.CM","Steer.HD","Prov.AD","Prov.AS","Prov.CM","Prov.HD","Interp.AS","Interp.CM","Interp.HD","Pos.AS","Pos.CM","Pos.HD")
freq <- colSums(d0[,all20]); thr3 <- all20[freq >= 3]
cat("rENA", as.character(packageVersion("rENA")), "on", R.version.string, "\n")
cat("Learner episodes:", nrow(d0), " units:", length(unique(paste(d0$Institution,d0$EntryID))), "\n")
cat("Code frequencies:\n"); print(freq)
cat("Codes kept at threshold 3 (", length(thr3), "):", paste(thr3, collapse=", "), "\n")
fit <- function(d, codes, w){ acc <- ena.accumulate.data(units=d[,c("Institution","EntryID")], conversation=d[,c("Institution","ActivityID")], metadata=d[,"Institution",drop=FALSE], codes=d[,codes], window.size.back=w); ena.make.set(acc) }
report <- function(tag, d, codes, save=NULL){
  set <- fit(d, codes, 1); set2 <- fit(d, codes, 2)
  pass <- tapply(d$OriginalPass, d$EntryID, function(x) x[1])
  pts <- as.data.frame(set$points); inst <- pts$Institution; sv <- as.matrix(set$points)[,1:2]
  eid <- sub(".*::","",pts$ENA_UNIT); pp <- pass[eid]
  cat("\n==========", tag, "==========\n"); cat("Codes (", length(codes), "):", paste(codes, collapse=", "), "\n")
  cat("Units:", nrow(pts), "\n"); print(table(inst)); print(table(pp))
  cat("Variance SV1, SV2:", round(set$model$variance[1:2],3), "\n"); print(ena.correlations(set))
  for(k in 1:2){kt<-kruskal.test(sv[,k]~factor(inst)); cat(sprintf("Institution SV%d Kruskal-Wallis chi2=%.2f p=%.3f\n",k,kt$statistic,kt$p.value))}
  for(k in 1:2){wt<-wilcox.test(sv[pp=="Pilot",k],sv[pp=="Full",k]); cat(sprintf("Original pass SV%d Mann-Whitney W=%.0f p=%.3f\n",k,wt$statistic,wt$p.value))}
  print(aggregate(sv,list(Institution=inst),mean)); print(aggregate(sv,list(Pass=pp),mean))
  p2<-as.matrix(set2$points)[,1:2]; cat("Window 1 vs 2 |r| SV1:",round(abs(cor(sv[,1],p2[,1])),3)," SV2:",round(abs(cor(sv[,2],p2[,2])),3),"\n")
  nodes<-as.data.frame(set$rotation$nodes); cat("Node positions:\n"); print(nodes[order(nodes[,2]),1:3],row.names=FALSE)
  lw<-as.matrix(set$line.weights); cn<-colnames(lw); mlw<-sapply(split(as.data.frame(lw),inst),colMeans)
  for(g in colnames(mlw)){v<-setNames(mlw[,g],cn);o<-order(-v)[1:6];cat("Top connections",g,"\n");print(round(v[o],3))}
  if(!is.null(save)){
    write.csv(data.frame(Unit=pts$ENA_UNIT,Institution=inst,OriginalPass=pp,SV1=round(sv[,1],4),SV2=round(sv[,2],4)),paste0(save,"_points.csv"),row.names=FALSE)
    write.csv(data.frame(connection=cn,round(mlw,4)),paste0(save,"_mean_line_weights.csv"),row.names=FALSE)
    write.csv(data.frame(code=nodes$code,SV1=round(nodes[,2],4),SV2=round(nodes[,3],4)),paste0(save,"_node_positions.csv"),row.names=FALSE)
    write.csv(data.frame(Unit=pts$ENA_UNIT,round(lw,4),check.names=FALSE),paste0(save,"_unit_line_weights.csv"),row.names=FALSE)
    saveRDS(set,paste0(save,"_set.rds"))
  }
  invisible(set)
}
report("Model 1A (Run 4.1 primary): threshold 3, all learner episodes", d0, thr3, save="run41")
report("Comparison: the Run 4 17-code list on the patched data", d0, run4codes, save="run41_codes17")
d1 <- d0[d0$NonGenerativeTool==0,]; thr3b <- all20[colSums(d1[,all20])>=3]
report("Model 1B: without TO-BelloWrite-A2 (NonGenerativeTool)", d1, thr3b, save="run41_1B")

# Code-level Fisher tests of pilot against full entries (the three Run 3 differences), learner episodes
cat("\n========== Pilot against full entries (learner episodes, OriginalPass) ==========\n")
d0$HolCM <- as.integer(d0$HolisticIntended=="CM"); d0$PosNE <- as.integer(rowSums(d0[,c("Pos.AD","Pos.AS","Pos.CM","Pos.HD")])==0)
for(v in c("Steer.HD","Interp.HD","HolCM","PosNE")){
  t <- table(factor(d0$OriginalPass,levels=c("Pilot","Full")), factor(d0[[v]],levels=c(0,1)))
  ft <- fisher.test(t); cat(sprintf("%-10s Pilot %.2f (%d/%d)  Full %.2f (%d/%d)  Fisher p=%.3f\n", v,
    t["Pilot","1"]/sum(t["Pilot",]), t["Pilot","1"], sum(t["Pilot",]), t["Full","1"]/sum(t["Full",]), t["Full","1"], sum(t["Full",]), ft$p.value))
}
