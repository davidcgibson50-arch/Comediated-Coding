
#### Learner panel

**EO intended** (alpha 0.70; Model 2 (EO_designed); provisional values 0%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 73 (53%) | 46 (54%) | 15 (62%) | 12 (40%) |
| EO-EV | 56 (40%) | 34 (40%) | 6 (25%) | 16 (53%) |
| EO-RE | 4 (3%) | 2 (2%) | 2 (8%) | 0 (0%) |
| EO-CH | 3 (2%) | 1 (1%) | 0 (0%) | 2 (7%) |
| EO-RD | 2 (1%) | 1 (1%) | 1 (4%) | 0 (0%) |
| EO-IN | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |

**ML intended** (alpha 0.66; Model 2 (ML_designed), borderline alpha; provisional values 0%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| ML-NA | 83 (60%) | 58 (68%) | 9 (38%) | 16 (53%) |
| ML-CW | 17 (12%) | 6 (7%) | 5 (21%) | 6 (20%) |
| ML-DD | 15 (11%) | 9 (11%) | 2 (8%) | 4 (13%) |
| ML-EP | 10 (7%) | 5 (6%) | 3 (12%) | 2 (7%) |
| ML-MX | 7 (5%) | 4 (5%) | 2 (8%) | 1 (3%) |
| ML-RA | 4 (3%) | 1 (1%) | 2 (8%) | 1 (3%) |
| ML-FR | 3 (2%) | 2 (2%) | 1 (4%) | 0 (0%) |

**Epistemic Object (EB)** (alpha 0.55; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 73 (53%) | 46 (54%) | 15 (62%) | 12 (40%) |
| Evidence and relevance | 25 (18%) | 11 (13%) | 6 (25%) | 8 (27%) |
| Perspective and bias | 14 (10%) | 11 (13%) | 2 (8%) | 1 (3%) |
| Reasoning norms | 8 (6%) | 8 (9%) | 0 (0%) | 0 (0%) |
| Multiple | 5 (4%) | 2 (2%) | 0 (0%) | 3 (10%) |
| Explanation and causality | 5 (4%) | 2 (2%) | 0 (0%) | 3 (10%) |
| Authority and credibility | 5 (4%) | 3 (4%) | 1 (4%) | 1 (3%) |
| No majority | 4 (3%) | 2 (2%) | 0 (0%) | 2 (7%) |

**Uptake intended** (alpha 0.40; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 79 (57%) | 50 (59%) | 12 (50%) | 17 (57%) |
| UP-AP | 40 (29%) | 22 (26%) | 9 (38%) | 9 (30%) |
| UP-MX | 11 (8%) | 9 (11%) | 1 (4%) | 1 (3%) |
| UP-AD | 5 (4%) | 3 (4%) | 1 (4%) | 1 (3%) |
| UP-CT | 3 (2%) | 1 (1%) | 1 (4%) | 1 (3%) |
| UP-RJ | 1 (1%) | 0 (0%) | 0 (0%) | 1 (3%) |

**Uptake reported** (alpha 0.40; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 121 (87%) | 70 (82%) | 24 (100%) | 27 (90%) |
| UP-AP | 9 (6%) | 7 (8%) | 0 (0%) | 2 (7%) |
| UP-MX | 6 (4%) | 5 (6%) | 0 (0%) | 1 (3%) |
| UP-AD | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |
| UP-CT | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |
| UP-RJ | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |

**Dialogue Type (DT)** (alpha 0.31; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 68 (49%) | 35 (41%) | 15 (62%) | 18 (60%) |
| Instructional | 23 (17%) | 18 (21%) | 2 (8%) | 3 (10%) |
| Collaborative | 20 (14%) | 12 (14%) | 5 (21%) | 3 (10%) |
| Feedback-oriented | 18 (13%) | 12 (14%) | 1 (4%) | 5 (17%) |
| Mixed | 4 (3%) | 3 (4%) | 1 (4%) | 0 (0%) |
| Reflective | 4 (3%) | 3 (4%) | 0 (0%) | 1 (3%) |
| No majority | 2 (1%) | 2 (2%) | 0 (0%) | 0 (0%) |

**Stated Purpose (DP)** (alpha 0.53; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| Critical evaluation of AI (HD) | 35 (25%) | 21 (25%) | 2 (8%) | 12 (40%) |
| Guided practice (AS) | 22 (16%) | 16 (19%) | 0 (0%) | 6 (20%) |
| Multiple | 22 (16%) | 12 (14%) | 2 (8%) | 8 (27%) |
| Independent production (HD) | 20 (14%) | 10 (12%) | 8 (33%) | 2 (7%) |
| Not stated | 14 (10%) | 8 (9%) | 6 (25%) | 0 (0%) |
| Introduce or model (AD) | 10 (7%) | 9 (11%) | 0 (0%) | 1 (3%) |
| Inquiry and refinement (CM) | 9 (6%) | 6 (7%) | 3 (12%) | 0 (0%) |
| No majority | 7 (5%) | 3 (4%) | 3 (12%) | 1 (3%) |

**Learner variability (LV)** (alpha 0.48; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| None noted | 108 (78%) | 59 (69%) | 24 (100%) | 25 (83%) |
| Prior knowledge | 13 (9%) | 13 (15%) | 0 (0%) | 0 (0%) |
| Multiple | 6 (4%) | 6 (7%) | 0 (0%) | 0 (0%) |
| Orientation toward AI | 5 (4%) | 3 (4%) | 0 (0%) | 2 (7%) |
| AI literacy | 3 (2%) | 0 (0%) | 0 (0%) | 3 (10%) |
| Self-regulation | 2 (1%) | 2 (2%) | 0 (0%) | 0 (0%) |
| No majority | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |
| Motivation | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |

**Sociotechnical Frame** (alpha 0.49; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| High-stakes assessment | 62 (45%) | 29 (34%) | 9 (38%) | 24 (80%) |
| Low-stakes or formative | 32 (23%) | 27 (32%) | 2 (8%) | 3 (10%) |
| Self-directed or optional | 25 (18%) | 22 (26%) | 0 (0%) | 3 (10%) |
| Unclear | 18 (13%) | 7 (8%) | 11 (46%) | 0 (0%) |
| Professional or workplace | 2 (1%) | 0 (0%) | 2 (8%) | 0 (0%) |

**Laurillard activity type** (alpha 0.70; Descriptive context; provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| Inquiry, production | 83 (60%) | 50 (59%) | 17 (71%) | 16 (53%) |
| Practice | 22 (16%) | 16 (19%) | 0 (0%) | 6 (20%) |
| Reflection | 12 (9%) | 4 (5%) | 2 (8%) | 6 (20%) |
| Acquisition | 10 (7%) | 9 (11%) | 0 (0%) | 1 (3%) |
| Inquiry, discussion, collaboration | 10 (7%) | 6 (7%) | 3 (12%) | 1 (3%) |
| NE | 2 (1%) | 0 (0%) | 2 (8%) | 0 (0%) |

**Holistic intended** (alpha 0.70; Descriptive context; provisional values 0%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| HD | 95 (68%) | 55 (65%) | 19 (79%) | 21 (70%) |
| AS | 33 (24%) | 20 (24%) | 4 (17%) | 9 (30%) |
| AD | 6 (4%) | 6 (7%) | 0 (0%) | 0 (0%) |
| CM | 3 (2%) | 3 (4%) | 0 (0%) | 0 (0%) |
| Mixed | 2 (1%) | 1 (1%) | 1 (4%) | 0 (0%) |

**Start Config** (alpha 0.69; Descriptive context; provisional values 53%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| HD | 93 (67%) | 53 (62%) | 19 (79%) | 21 (70%) |
| AS | 36 (26%) | 22 (26%) | 5 (21%) | 9 (30%) |
| AD | 7 (5%) | 7 (8%) | 0 (0%) | 0 (0%) |
| CM | 3 (2%) | 3 (4%) | 0 (0%) | 0 (0%) |

**End Config** (alpha 0.66; Descriptive context; provisional values 55%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| HD | 95 (68%) | 55 (65%) | 19 (79%) | 21 (70%) |
| AS | 34 (24%) | 20 (24%) | 5 (21%) | 9 (30%) |
| AD | 7 (5%) | 7 (8%) | 0 (0%) | 0 (0%) |
| CM | 3 (2%) | 3 (4%) | 0 (0%) | 0 (0%) |

**EO reported** (alpha 0.75; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 109 (78%) | 62 (73%) | 24 (100%) | 23 (77%) |
| EO-EV | 24 (17%) | 18 (21%) | 0 (0%) | 6 (20%) |
| EO-RE | 3 (2%) | 3 (4%) | 0 (0%) | 0 (0%) |
| EO-IN | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |
| EO-RD | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |
| No majority | 1 (1%) | 0 (0%) | 0 (0%) | 1 (3%) |

**ML reported** (alpha 0.64; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| ML-NA | 103 (74%) | 56 (66%) | 24 (100%) | 23 (77%) |
| ML-DD | 11 (8%) | 9 (11%) | 0 (0%) | 2 (7%) |
| ML-EP | 10 (7%) | 9 (11%) | 0 (0%) | 1 (3%) |
| ML-CW | 7 (5%) | 6 (7%) | 0 (0%) | 1 (3%) |
| ML-MX | 3 (2%) | 2 (2%) | 0 (0%) | 1 (3%) |
| No majority | 3 (2%) | 2 (2%) | 0 (0%) | 1 (3%) |
| ML-RA | 2 (1%) | 1 (1%) | 0 (0%) | 1 (3%) |

**R-D1 Engagement Type** (alpha 0.61; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 96 (69%) | 53 (62%) | 24 (100%) | 19 (63%) |
| Coded | 43 (31%) | 32 (38%) | 0 (0%) | 11 (37%) |

**R-D2 Interaction Structure (steering)** (alpha 0.65; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 104 (75%) | 60 (71%) | 24 (100%) | 20 (67%) |
| Coded | 35 (25%) | 25 (29%) | 0 (0%) | 10 (33%) |

**R-D3 Provenance of Production** (alpha 0.65; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 101 (73%) | 56 (66%) | 24 (100%) | 21 (70%) |
| Coded | 38 (27%) | 29 (34%) | 0 (0%) | 9 (30%) |

**R-D4 Interpretive Influence** (alpha 0.79; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 97 (70%) | 50 (59%) | 24 (100%) | 23 (77%) |
| Coded | 42 (30%) | 35 (41%) | 0 (0%) | 7 (23%) |

**R-D5 Positioning (learner orientation)** (alpha 0.74; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 108 (78%) | 60 (71%) | 24 (100%) | 24 (80%) |
| Coded | 31 (22%) | 25 (29%) | 0 (0%) | 6 (20%) |

**Evidence tiers across all reported fields** (T1 0, T2 140, T3 132, no majority 1; 839 fields carry no tier because the field is NE)


#### Instructor-only panel

**EO intended** (alpha 0.70; Model 2 (EO_designed); provisional values 0%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 20 (87%) | 18 (90%) | 2 (67%) |
| EO-EV | 3 (13%) | 2 (10%) | 1 (33%) |

**ML intended** (alpha 0.66; Model 2 (ML_designed), borderline alpha; provisional values 0%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| ML-NA | 20 (87%) | 18 (90%) | 2 (67%) |
| ML-DD | 2 (9%) | 1 (5%) | 1 (33%) |
| ML-CW | 1 (4%) | 1 (5%) | 0 (0%) |

**Epistemic Object (EB)** (alpha 0.55; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 20 (87%) | 18 (90%) | 2 (67%) |
| Perspective and bias | 2 (9%) | 1 (5%) | 1 (33%) |
| Evidence and relevance | 1 (4%) | 1 (5%) | 0 (0%) |

**Uptake intended** (alpha 0.40; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| UP-AP | 11 (48%) | 10 (50%) | 1 (33%) |
| NE | 9 (39%) | 7 (35%) | 2 (67%) |
| UP-AD | 2 (9%) | 2 (10%) | 0 (0%) |
| UP-MX | 1 (4%) | 1 (5%) | 0 (0%) |

**Uptake reported** (alpha 0.40; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 10 (43%) | 9 (45%) | 1 (33%) |
| UP-AP | 9 (39%) | 8 (40%) | 1 (33%) |
| UP-AD | 3 (13%) | 2 (10%) | 1 (33%) |
| UP-MX | 1 (4%) | 1 (5%) | 0 (0%) |

**Dialogue Type (DT)** (alpha 0.31; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 16 (70%) | 13 (65%) | 3 (100%) |
| Collaborative | 5 (22%) | 5 (25%) | 0 (0%) |
| Instructional | 2 (9%) | 2 (10%) | 0 (0%) |

**Stated Purpose (DP)** (alpha 0.53; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| Not stated | 19 (83%) | 16 (80%) | 3 (100%) |
| Critical evaluation of AI (HD) | 1 (4%) | 1 (5%) | 0 (0%) |
| Independent production (HD) | 1 (4%) | 1 (5%) | 0 (0%) |
| Introduce or model (AD) | 1 (4%) | 1 (5%) | 0 (0%) |
| Multiple | 1 (4%) | 1 (5%) | 0 (0%) |

**Learner variability (LV)** (alpha 0.48; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| None noted | 22 (96%) | 19 (95%) | 3 (100%) |
| Orientation toward AI | 1 (4%) | 1 (5%) | 0 (0%) |

**Sociotechnical Frame** (alpha 0.49; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| Instructor preparation | 20 (87%) | 18 (90%) | 2 (67%) |
| Professional or workplace | 2 (9%) | 1 (5%) | 1 (33%) |
| Unclear | 1 (4%) | 1 (5%) | 0 (0%) |

**Laurillard activity type** (alpha 0.70; Descriptive context; provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 23 (100%) | 20 (100%) | 3 (100%) |

**Holistic intended** (alpha 0.70; Descriptive context; provisional values 0%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| HD | 13 (57%) | 12 (60%) | 1 (33%) |
| AS | 8 (35%) | 6 (30%) | 2 (67%) |
| AD | 2 (9%) | 2 (10%) | 0 (0%) |

**Start Config** (alpha 0.69; Descriptive context; provisional values 44%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| HD | 13 (57%) | 12 (60%) | 1 (33%) |
| AS | 8 (35%) | 6 (30%) | 2 (67%) |
| AD | 2 (9%) | 2 (10%) | 0 (0%) |

**End Config** (alpha 0.66; Descriptive context; provisional values 44%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| HD | 13 (57%) | 12 (60%) | 1 (33%) |
| AS | 8 (35%) | 6 (30%) | 2 (67%) |
| AD | 2 (9%) | 2 (10%) | 0 (0%) |

**EO reported** (alpha 0.75; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 20 (87%) | 18 (90%) | 2 (67%) |
| EO-EV | 3 (13%) | 2 (10%) | 1 (33%) |

**ML reported** (alpha 0.64; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| ML-NA | 20 (87%) | 18 (90%) | 2 (67%) |
| ML-CW | 1 (4%) | 1 (5%) | 0 (0%) |
| ML-DD | 1 (4%) | 0 (0%) | 1 (33%) |
| ML-MX | 1 (4%) | 1 (5%) | 0 (0%) |

**R-D1 Engagement Type** (alpha 0.61; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| Coded | 14 (61%) | 12 (60%) | 2 (67%) |
| NE | 9 (39%) | 8 (40%) | 1 (33%) |

**R-D2 Interaction Structure (steering)** (alpha 0.65; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| Coded | 16 (70%) | 13 (65%) | 3 (100%) |
| NE | 7 (30%) | 7 (35%) | 0 (0%) |

**R-D3 Provenance of Production** (alpha 0.65; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| Coded | 19 (83%) | 16 (80%) | 3 (100%) |
| NE | 4 (17%) | 4 (20%) | 0 (0%) |

**R-D4 Interpretive Influence** (alpha 0.79; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 12 (52%) | 10 (50%) | 2 (67%) |
| Coded | 11 (48%) | 10 (50%) | 1 (33%) |

**R-D5 Positioning (learner orientation)** (alpha 0.74; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| Coded | 15 (65%) | 12 (60%) | 3 (100%) |
| NE | 8 (35%) | 8 (40%) | 0 (0%) |

**Evidence tiers across all reported fields** (T1 0, T2 91, T3 3; 90 fields carry no tier because the field is NE)

