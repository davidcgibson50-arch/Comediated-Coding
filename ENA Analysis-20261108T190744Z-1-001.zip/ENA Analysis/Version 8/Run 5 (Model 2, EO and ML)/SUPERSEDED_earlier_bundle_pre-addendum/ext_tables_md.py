"""Render run5_extension_tables.csv as markdown tables (one per code family), learner and instructor panels.
Usage: python ext_tables_md.py <work_dir> > run5_extension_tables.md"""
import sys, os
import pandas as pd
t = pd.read_csv(os.path.join(sys.argv[1], "run5_extension_tables.csv"))
NAMES = {"Holistic: intended (judgment)": "Holistic intended", "Laurillard Activity Type (context)": "Laurillard activity type",
         "Learner Variability Noted (LV)": "Learner variability (LV)"}
TIERS = [f for f in t.Family.unique() if "ier" in f]
for panel in ("Learner", "Instructor-only"):
    x0 = t[t.Panel == panel]
    groups = [g for g in ["All", "Georgia Tech", "Stanford", "Toronto"] if g in set(x0.Group)]
    print(f"\n#### {panel} panel\n")
    for fam in [f for f in x0.Family.unique() if f not in TIERS]:
        x = x0[x0.Family == fam]
        N = x.groupby("Group").N.first()
        a = x.alpha.iloc[0]
        prov = x[x.Group == "All"].Provisional_share.iloc[0]
        print(f"**{NAMES.get(fam, fam)}** (alpha {a:.2f}; {x.Status.iloc[0]}; provisional values {100*prov:.0f}%)\n")
        print("| Value | " + " | ".join(f"{g} (n={N[g]})" for g in groups) + " |")
        print("|---|" + "---|" * len(groups))
        pv = x.pivot_table(index="Value", columns="Group", values="n", fill_value=0)
        for v in pv.sort_values("All", ascending=False).index:
            cells = [f"{int(pv.at[v, g])} ({100*pv.at[v, g]/N[g]:.0f}%)" if g in pv.columns else "0 (0%)" for g in groups]
            print(f"| {v} | " + " | ".join(cells) + " |")
        print()
    # Tier distribution across all reported fields.
    x = x0[x0.Family.isin(TIERS) & (x0.Group == "All")]
    tot = x.groupby("Value").n.sum()
    tiers = ", ".join([f"T1 {int(tot.get('T1', 0))}"] + [f"{k} {int(v)}" for k, v in tot.items() if k.startswith("T")] + ([f"no majority {int(tot['No majority'])}"] if "No majority" in tot else []))
    print(f"**Evidence tiers across all reported fields** ({tiers}; {int(tot.get('none', 0))} fields carry no tier because the field is NE)\n")
