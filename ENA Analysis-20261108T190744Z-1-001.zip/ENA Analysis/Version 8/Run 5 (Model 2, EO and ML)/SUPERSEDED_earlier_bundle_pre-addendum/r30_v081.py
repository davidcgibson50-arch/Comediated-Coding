"""r30.py for v0.8.1: recompute the Codebook v0.7.2 R30
sequence-direction index (HS, StepChange, SS, EntrySequenceChange, SD,
SequenceOscillation) on a file that already carries the Run 3.1 GT-41-A1 ruling. Learner episodes only; order within an
entry is EpisodeID order, as in v0.7.2."""
import sys, pandas as pd, numpy as np
src, out = sys.argv[1], sys.argv[2]
T = 0.5
d = pd.read_csv(src)

# The Run 3.1 ruling (GT-41-A1 I-D5 = AS) is already in the v0.8 files, so it is checked, not re-applied.
m = d.EpisodeID == "GT-41-A1"
assert d.loc[m, "Pos.AS"].item() == 1

P = ["Eng", "Steer", "Prov", "Interp", "Pos"]; V = {"AD": 0, "AS": 1, "CM": 2, "HD": 3}
for p in P:
    assert (d[[f"{p}.{k}" for k in V]].sum(axis=1) <= 1).all(), p

def hs(r):
    s = [V[k] for p in P for k in V if r[f"{p}.{k}"] == 1]
    return round(sum(s) / len(s), 3) if s else np.nan

def lab(x):
    if pd.isna(x): return "NE"
    x = round(x, 3)
    return "Toward human direction" if x >= T else "Toward AI direction" if x <= -T else "Stable"

for c in ["HS", "StepChange", "SS", "EntrySequenceChange", "SD", "SequenceOscillation"]:
    d[c] = pd.Series([None] * len(d), dtype=object)
L = d.Learner == 1
d.loc[L, "HS"] = d[L].apply(hs, axis=1)
for e, g in d[L].sort_values("EpisodeID").groupby("EntryID"):
    idx = list(g.index); h = [d.at[i, "HS"] for i in idx]
    steps = [None] + [round(h[i] - h[i - 1], 3) for i in range(1, len(h))]
    for i, s in zip(idx, steps):
        d.at[i, "StepChange"] = s
        d.at[i, "SS"] = "NE" if s is None else lab(s)
    if len(idx) == 1:
        d.at[idx[0], "SD"] = "NE"
        continue
    sd = round(h[-1] - h[0], 3)
    labs = {lab(s) for s in steps[1:]}
    osc = "Oscillating" if {"Toward human direction", "Toward AI direction"} <= labs else None
    for i in idx:
        d.at[i, "EntrySequenceChange"] = sd; d.at[i, "SD"] = lab(sd); d.at[i, "SequenceOscillation"] = osc
d.to_csv(out, index=False)

# summary, with sensitivity thresholds
ent = d[L].groupby("EntryID").agg(n=("EpisodeID", "size"), sd=("EntrySequenceChange", "first"), osc=("SequenceOscillation", "first"))
multi = ent[ent.n > 1]
print(f"Learner entries {len(ent)}; multi-episode {len(multi)}; oscillating {multi.osc.notna().sum()}")
for t in (0.34, 0.5, 0.75, 1.0):
    s = multi.sd.astype(float).round(3)
    print(f"  threshold {t}: toward human {(s >= t).sum()}, toward AI {(s <= -t).sum()}, stable {((s > -t) & (s < t)).sum()}")
