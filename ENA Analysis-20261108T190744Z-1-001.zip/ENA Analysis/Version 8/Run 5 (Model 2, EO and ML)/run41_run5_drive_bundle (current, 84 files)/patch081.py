"""Apply AIM-AI patch v0.8.1 to the Stage A ENA file and the all162 intended file.

Usage: python patch081.py <drive_dir> <ena_eoml.csv> <out_dir>
Step 1 checks every Old value against both files and stops on any mismatch before writing.
Step 2 applies the rows whose New differs from Old (the "(unchanged)" rows are a record only and
are checked, not applied), rebuilds the one-hot columns, updates HolisticIntended and
TrajectoryUseCase, adds PatchRow, and recomputes the R30 columns with r30_v081.py.
"""
import json
import os
import subprocess
import sys

import pandas as pd

drive, ena_path, out = sys.argv[1], sys.argv[2], sys.argv[3]
here = os.path.dirname(os.path.abspath(__file__))
patch = pd.concat([pd.read_csv(os.path.join(drive, "AIM-AI_v081_Patch_Log.csv")),
                   pd.read_csv(os.path.join(drive, "AIM-AI_v081_Patch_Log_addendum.csv"))], ignore_index=True)
ena = pd.read_csv(ena_path)
a162 = pd.read_csv(os.path.join(drive, "AIM-AI_v08_all162_intended.csv"))
DIM = {"I-D1": "Eng", "I-D2": "Steer", "I-D3": "Prov", "I-D4": "Interp", "I-D5": "Pos"}
CONF = ["AD", "AS", "CM", "HD"]
E = ena.set_index("EpisodeID")
A = a162.set_index("Episode ID")
# Correction outside the patch log (David Gibson, October 30, 2026): the Run 3.1 ruling GT-41-A1 I-D5 = AS is
# final, and "Mixed" in the all162 file was a synchronization error. Applied before the checks; PatchRow stays 0.
assert A.at["GT-41-A1", "I-D5"] == "Mixed" and E.at["GT-41-A1", "Pos.AS"] == 1
a162.loc[a162["Episode ID"] == "GT-41-A1", "I-D5"] = "AS"
A = a162.set_index("Episode ID")
VALID = {"AD", "AS", "CM", "HD", "NE"}
bad = [(e, f, A.at[e, f]) for e in A.index for f in DIM if A.at[e, f] not in VALID]
assert not bad, f"Invalid dimension values: {bad}"


def ena_dim(e, f):
    p = DIM[f]
    on = [k for k in CONF if E.at[e, f"{p}.{k}"] == 1]
    return on[0] if len(on) == 1 else ("NE" if not on else "+".join(on))


# Consistency of the two files before patching (dimensions, holistic, trajectory).
pre = []
for e in E.index:
    for f in DIM:
        if ena_dim(e, f) != A.at[e, f]:
            pre.append({"EpisodeID": e, "Field": f, "ENA": ena_dim(e, f), "all162": A.at[e, f]})
    for f in ("HolisticIntended", "TrajectoryUseCase"):
        if E.at[e, f] != A.at[e, f]:
            pre.append({"EpisodeID": e, "Field": f, "ENA": E.at[e, f], "all162": A.at[e, f]})

# Step 1: check every Old value.
checks, mism = [], []
for i, r in patch.iterrows():
    e, f, old, new = r.EpisodeID, r.Field, r.Old, r.New
    record = "(unchanged)" in str(new)
    if record:
        fields = list(DIM) + ["HolisticIntended", "StartConfig", "EndConfig"] if f == "(all CM codes)" else ["I-D1", "I-D5"]
        cm = [g for g in fields if A.at[e, g] == "CM"]
        ok = len(cm) > 0 if f == "(all CM codes)" else all(A.at[e, g] == "CM" for g in fields)
        ok = ok and all(ena_dim(e, g) == "CM" for g in fields if g in DIM and A.at[e, g] == "CM")
        checks.append({"row": i + 2, "EpisodeID": e, "Field": f, "Old": old, "ENA": "CM in " + ",".join(cm), "all162": "CM in " + ",".join(cm), "match": ok, "applied": False})
        if not ok:
            mism.append(checks[-1])
        continue
    if f in DIM:
        ev, av = ena_dim(e, f), A.at[e, f]
    elif f in ("HolisticIntended", "TrajectoryUseCase"):
        ev, av = E.at[e, f], A.at[e, f]
    else:  # StartConfig, EndConfig exist in the all162 file only
        ev, av = "(not in ENA file)", A.at[e, f]
    ok = av == old and (ev == old or ev == "(not in ENA file)")
    checks.append({"row": i + 2, "EpisodeID": e, "Field": f, "Old": old, "New": new, "ENA": ev, "all162": av, "match": ok, "applied": ok})
    if not ok:
        mism.append(checks[-1])
os.makedirs(out, exist_ok=True)
pd.DataFrame(checks).to_csv(os.path.join(out, "run41_patch_old_value_check.csv"), index=False)
print("Rows:", len(patch), " to apply:", sum(c["applied"] for c in checks), " record only:", sum("(unchanged)" in str(n) for n in patch.New))
print("Pre-patch differences between ENA and all162 files:", pre)
if mism:
    print("MISMATCH, nothing written:", mism)
    sys.exit(1)
print("All Old values match.")


def counts(ena_df, a_df):
    L = ena_df[ena_df.Learner == 1]
    AL = a_df[a_df.Learner == 1]
    c = {k: int(L[k].sum()) for k in ["Eng.CM", "Steer.CM", "Prov.CM", "Interp.CM", "Pos.CM"]}
    c["Holistic CM (learner)"] = int((L.HolisticIntended == "CM").sum())
    c["Holistic CM episodes"] = sorted(L.EpisodeID[L.HolisticIntended == "CM"])
    c["Holistic Mixed (all 162)"] = sorted(ena_df.EpisodeID[ena_df.HolisticIntended == "Mixed"])
    c["Within-episode use case (learner)"] = int((L.TrajectoryUseCase == "Within-episode").sum())
    c["Within-episode use case (all 162)"] = int((ena_df.TrajectoryUseCase == "Within-episode").sum())
    c["Start differs from End (learner)"] = int((AL.StartConfig != AL.EndConfig).sum())
    c["Start differs from End (all 162)"] = int((a_df.StartConfig != a_df.EndConfig).sum())
    c["EO_designed (learner)"] = int(L.EO_designed.sum())
    c["ML_designed (learner)"] = int(L.ML_designed.sum())
    c["Codes at threshold 3"] = int(sum(L[f"{p}.{k}"].sum() >= 3 for p in DIM.values() for k in CONF))
    return c


before = counts(ena, a162)

# Step 2: apply.
new_ena, new_a = ena.copy().set_index("EpisodeID"), a162.copy().set_index("Episode ID")
changed = set()
for c in checks:
    if not c["applied"]:
        continue
    e, f, v = c["EpisodeID"], c["Field"], c["New"]
    new_a.at[e, f] = v
    if f in DIM:
        for k in CONF:
            new_ena.at[e, f"{DIM[f]}.{k}"] = int(k == v)
    elif f in ("HolisticIntended", "TrajectoryUseCase"):
        new_ena.at[e, f] = v
    changed.add(e)
new_ena["PatchRow"] = new_ena.index.isin(changed).astype(int)
new_a["PatchRow"] = new_a.index.isin(changed).astype(int)
tmp = os.path.join(out, "_tmp_patched.csv")
new_ena.reset_index().to_csv(tmp, index=False)
ena_out = os.path.join(out, "AIM-AI_v081_ENA_ready_intended_EOML.csv")
r = subprocess.run([sys.executable, os.path.join(here, "r30_v081.py"), tmp, ena_out], capture_output=True, text=True, check=True)
os.remove(tmp)
new_a.reset_index().to_csv(os.path.join(out, "AIM-AI_v081_all162_intended.csv"), index=False)
after = counts(pd.read_csv(ena_out), new_a.reset_index())

# Changed R30 values (learner episodes).
o = ena.set_index("EpisodeID")
n = pd.read_csv(ena_out).set_index("EpisodeID")
r30_changes = []
for e in n.index[n.Learner == 1]:
    for col in ["HS", "StepChange", "SS", "EntrySequenceChange", "SD", "SequenceOscillation"]:
        a, b = o.at[e, col], n.at[e, col]
        if not ((pd.isna(a) and pd.isna(b)) or a == b):
            r30_changes.append({"EpisodeID": e, "Field": col, "Before": a, "After": b})
pd.DataFrame(r30_changes).to_csv(os.path.join(out, "run41_r30_changes.csv"), index=False)
summary = {"before": before, "after": after, "episodes_changed": sorted(changed), "n_episodes_changed": len(changed),
           "learner_episodes_changed": int(n.loc[sorted(changed), "Learner"].sum()),
           "pre_patch_file_differences": pre, "r30_output": r.stdout, "n_r30_value_changes": len(r30_changes)}
json.dump(summary, open(os.path.join(out, "run41_patch_summary.json"), "w"), indent=1, default=str)
print(json.dumps({k: v for k, v in summary.items() if k != "pre_patch_file_differences"}, indent=1, default=str))
