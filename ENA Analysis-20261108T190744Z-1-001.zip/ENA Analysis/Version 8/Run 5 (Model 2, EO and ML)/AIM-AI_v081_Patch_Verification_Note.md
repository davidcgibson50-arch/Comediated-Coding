# AIM-AI patch v0.8.1: verification note

Prepared October 30, 2026, for David Gibson. Patch log: `AIM-AI_v081_Patch_Log.csv` (35 rows) and `AIM-AI_v081_Patch_Log_addendum.csv` (4 rows). Amendment: `AIM-AI_Run4-1_Model2_Amendment_ClaudeCode.md`. All rows were applied, including the 14 marked "Extended CM sweep (approval requested)" and the 4 addendum rows, all approved by David on October 30, 2026.

## Inputs and outputs

- Inputs: `AIM-AI_v08_ENA_ready_intended_EOML.csv` (the approved Stage A output) and `AIM-AI_v08_all162_intended.csv`.
- Outputs: `AIM-AI_v081_ENA_ready_intended_EOML.csv` and `AIM-AI_v081_all162_intended.csv`, each with a new column `PatchRow` (1 for the 14 patched episodes).
- Scripts: `patch081.py` (GT-41-A1 correction, value check, old-value check, application, counts) and `r30_v081.py` (R30 recomputation).
- Row-by-row check: `run41_patch_old_value_check.csv`. R30 changes: `run41_r30_changes.csv`. Summary: `run41_patch_summary.json`.

## 1. Old-value check (before anything was written)

- **All 39 rows (35 in the log, 4 in the addendum) match both files.** Thirty-four rows change a value. Five rows are "(unchanged)" records, and for these we confirmed that the listed CM codes are present: GT-09-A3, GT-09-A4 and GT-15-A1 (all CM codes); TO-SmithMyth-A1 (I-D1 and I-D5); TO-Wong-A1 (I-D5).
- Dimension fields (I-D1 to I-D5) were checked against the one-hot columns of the ENA file and against the all162 file. `HolisticIntended` and `TrajectoryUseCase` were checked in both files. `StartConfig` and `EndConfig` exist only in the all162 file and were checked there.
- **No mismatch.**

## 2. Correction outside the patch log: GT-41-A1 I-D5

Before patching, the two input files differed in one cell: GT-41-A1 I-D5 was AS in the ENA file and "Mixed" in the all162 file.
- The Run 3.1 ruling (intended D5 = AS) is final. The "Mixed" value in all162 was a synchronization error, confirmed by David on October 30, 2026.
- We set I-D5 = AS in `AIM-AI_v081_all162_intended.csv`. The ENA file already carried AS, so no model input changed.
- This is a correction, not a patch row, so GT-41-A1 keeps `PatchRow = 0`. `patch081.py` applies it before the old-value check, so the whole patch is reproducible from the two v0.8 inputs.

**Value check.** "Mixed" is not a valid dimension value. A scan of all 810 dimension cells in the all162 file (162 episodes by I-D1 to I-D5) found **no other value outside AD, AS, CM, HD and NE**. The holistic code contained two "Mixed" values (GT-12-A1, ST-21-A1), which the codebook allows where no configuration predominates; both are resolved by the addendum (section 3), so **no episode now carries a holistic "Mixed"**. After the correction and the patch, the two output files agree on every dimension, holistic and trajectory field for all 162 episodes.

## 3. Application

- **34 rows applied** to 14 episodes, all of them learner episodes: GT-08-A2, GT-12-A1, GT-18-A1, GT-32-A2, GT-44-A2, GT-67-A1, ST-02-A2, ST-10-A2, ST-21-A1, ST-28-A2, ST-38-A1, TO-BelloConv-A1, TO-SmithMyth-A1, TO-Wong-A1.
- One-hot columns were rebuilt for every changed dimension. `HolisticIntended` and `TrajectoryUseCase` were updated in both files, and `StartConfig` and `EndConfig` in the all162 file.
- **Addendum (approved October 30, 2026).**
  - GT-12-A1: HolisticIntended Mixed to AS, StartConfig AD to AS, EndConfig AD to AS (Recurrent; Start equals End, consistent with C10).
  - ST-21-A1: HolisticIntended Mixed to HD; Start AS, End HD and Within-episode unchanged.
  - The holistic, Start and End codes are not ENA nodes and do not enter R30, so the ENA models (Run 4.1 and Model 2) are unchanged; we re-fitted both and confirmed byte-identical points. The cluster, sequence and dependence analyses, which use the holistic code, were re-run.
- **R30 recomputation.** We adapted `r30.py` as `r30_v081.py`. The original re-applies the GT-41-A1 ruling and asserts that positioning is empty, which no longer holds, so the adapted script checks the ruling instead. Run on the unpatched Stage A file, it reproduces every R30 column exactly. After the patch, 14 R30 values change in 10 learner episodes (GT-08-A2, GT-08-A3, GT-18-A1, GT-67-A1 to A3, ST-28-A2, ST-28-A3, TO-BelloConv-A1, TO-Wong-A1). The SD counts at threshold 0.5 are unchanged (11 toward human direction, 9 toward AI direction, 20 stable, 3 oscillating). At 0.34, toward AI direction rises from 13 to 14 (GT-67).

## 4. Before and after counts (learner episodes)

| Code | Expected before | Found before | Expected after | Found after |
|---|---|---|---|---|
| Eng.CM | 11 | 11 | 6 | 6 |
| Steer.CM | 6 | 6 | 3 | 3 |
| Prov.CM | 4 | 4 | 2 | 2 |
| Interp.CM | 3 | 3 | 2 | 2 |
| Pos.CM | 7 | 7 | 5 | 5 |
| Holistic CM | 6 | 6 | 3 | 3 (GT-09-A3, GT-09-A4, GT-15-A1) |
| EO_designed / ML_designed | unaffected | 66 / 56 | unaffected | 66 / 56 |
| Codes at frequency threshold 3 | 17 | 17 | 15 | 15 |
| Holistic Mixed (all 162) | not stated | 2 (GT-12-A1, ST-21-A1) | 0 | 0 |

**One difference from the amendment.** The amendment expects Within-episode use cases to rise from 10 to 13. In the files they rise from **1 to 4** (GT-13-A1, plus GT-67-A1, ST-02-A2 and ST-21-A1), both among learner episodes and across all 162 episodes. The increase of three matches. No count in the files gives 10, so the amendment's figure may refer to another basis. We report it rather than adjust it.

**C10 consistency.** Before the patch, eight episodes had Start different from End without a Within-episode use case (the eight listed in the Run 4 brief). After the patch, Start differs from End in exactly the four Within-episode episodes, so no C10 conflict remains.

## 5. Superseded outputs

All Stage B outputs built on the unpatched file are kept only as `SUPERSEDED_*`. In Drive, the earlier results document is `SUPERSEDED_AIM-AI_ENA_Run5_results.md`. Stage A outputs are unaffected and remain valid inputs to the patch.

## Limitation

All coding, adjudication and patch drafting were done by sessions of AI models under shared rules. Agreement statistics reported anywhere in this project are therefore consistency tests, not inter-rater reliability between independent human coders.
