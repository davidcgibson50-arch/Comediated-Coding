# Run 5 (Model 2, EO and ML): folder contents

Updated October 30, 2026, after patch v0.8.1 and its addendum.

## Current files

- **Stage A (approved):** `AIM-AI_v08_EO_ML_Adjudication_Log.csv`, `AIM-AI_Run5_StageA_note.md`, and `AIM-AI_v08_ENA_ready_intended_EOML.csv` (the Stage A output, the input to the patch).
- **Patch v0.8.1:** `AIM-AI_v081_ENA_ready_intended_EOML.csv` (model input for Run 4.1 and Model 2), `AIM-AI_v081_all162_intended.csv`, `AIM-AI_v081_Patch_Verification_Note.md`.
- **Run 4.1 (Model 1 on v0.8.1):** `AIM-AI_ENA_Run4-1_results.md`.
- **Model 2 on v0.8.1:** `AIM-AI_ENA_Run5_results.md`.

## Added by hand from `run41_run5_drive_bundle.zip`

The Drive connector accepts binary files only as base64 text, which cannot be transferred reliably, so these travel in a zip:
- all `run41_*` and `run5_*` outputs (points, mean line weights, node positions, unit line weights, model objects as RDS, model logs, comparison tables, cluster, sequence and dependence outputs, code-level tests, extension-code tables and values, and all figures);
- the scripts: `patch081.py`, `r30_v081.py`, `run41.R`, `plots41.R`, `passplot41.R`, `compare41.py`, `cluster4.py`, `run5_v081.R`, `plots5_v081.R`, `passplot5_v081.R`, `compare5_v081.py`, `extension5_v081.py`, `ext_tables_md.py`, `stageA.py`;
- copies of the data files, the verification note, the addendum log `AIM-AI_v081_Patch_Log_addendum.csv` and both results documents.

## Superseded

Files whose names begin with `SUPERSEDED_` were built before the patch, or before its addendum. Keep them only as a record:
- the first Model 2 results, built on the unpatched file;
- the first uploads of the two v0.8.1 data files, the verification note and the Run 4.1 results, which predate the addendum rows for GT-12-A1 and ST-21-A1.
