# AIM-AI ENA Run 5: Model 2 (dimensions plus EO and ML), results and comparison with Model 1

Date: October 30, 2026. Codebook: AIM-AI v0.8.3. Profile modelled: **intended (T4)**. Run 5 adds the designed epistemic-opportunity (EO) and mediational-literacy (ML) codes to the Run 4 dimensional model as two presence nodes (decision of October 30, 2026, option a). Model 1 (Run 4) remains the primary dimensional model; Model 2 has its own projected space.

## Files in this set

- **Stage A (approved October 30, 2026):** `AIM-AI_v08_EO_ML_Adjudication_Log.csv`, `AIM-AI_v08_ENA_ready_intended_EOML.csv` (the model input), `AIM-AI_Run5_StageA_note.md`.
- **ENA output (Model 2A):** `run5_points.csv`, `run5_mean_line_weights.csv` (all units and by institution), `run5_node_positions.csv`, `run5_unit_line_weights.csv`, `run5_set.rds` (model object), `run5_model_output.txt`.
- **Model 2B and sensitivity models:** the same files with the prefixes `run5_2B_`, `run5_sens_nonrecoded_` (the v0.7.1-carried episodes) and `run5_sens_recoded_` (the v0.8-resolved episodes); `run5_sens_cooccurrence.csv`.
- **Figures:** `run5_points_by_institution.png`, `run5_points_by_original_pass.png`, `run5_mean_network_{Georgia_Tech,Stanford,Toronto}.png`. EO and ML nodes are shown in green.
- **Comparison with Model 1:** `run5_vs_run4_units.csv` (aligned positions, shift, and each unit's EO and ML codes), `run5_vs_run4_nodes.csv`, `run5_compare.json`.
- **Code-level tests:** `run5_code_level_tests.csv`.
- **Extension codes:** `run5_extension_values.csv` (every episode, every family, with the source of each value), `run5_extension_tables.csv` and `run5_extension_tables.md` (the tables in section 5), `run5_extension_no_majority.csv`, `run5_extension_summary.json`.
- **Scripts:** `stageA.py` (Stage A), `run5.R` (models and code-level tests), `plots5.R` and `passplot5.R` (figures), `compare5.py` (comparison with Model 1), `extension5.py` and `ext_tables_md.py` (extension-code summary). `run5.R` is `run4.R` with the EOML input, the two presence nodes, EO- and ML-linked connection summaries, the sensitivity models and the code-level tests; `plots5.R` and `passplot5.R` differ from the Run 4 versions only in file names, titles and the green EO and ML labels.

## 1. What Model 2 adds

- **Stage A.** EO intended and ML intended were resolved for the 65 recoded episodes: 95 unanimous cells, 29 upheld majorities, 2 overturned majorities and 4 three-way splits, all approved. The presence codes for the 97 non-recoded episodes are v0.7.1 codes carried over (`EOML_Source`).
- **Usability rule (brief, section 3).** A code enters Model 2 if it is resolved under v0.8, has Krippendorff's alpha of at least .667, and is present in at least 3 learner episodes. EO intended (alpha .70) enters as `EO_designed`. ML intended (alpha .66) enters as `ML_designed` with a borderline-reliability caveat. All other extension codes are reported descriptively in section 5.
- **Frequencies (learner episodes).** `EO_designed` 66 of 139 and `ML_designed` 56 of 139, both far above the threshold of 3. The 17 Run 4 dimension codes keep their Run 4 frequencies, so Model 2 has **19 nodes**.

## 2. ENA settings (unchanged from Run 4 Model 1A)

- **Software:** rENA 0.3.1 on R 4.3.3.
- **Data:** learner episodes only: 139 episodes in **81 units** (Georgia Tech 45, Stanford 18, Toronto 18); 28 pilot and 53 full-pass entries by `OriginalPass`.
- **Units:** Institution + EntryID. **Conversation:** Institution + ActivityID.
- **Window:** 1, with window 2 as a sensitivity check. SVD rotation.
- **Codes:** the 17 Run 4 codes plus `EO_designed` and `ML_designed`.
- **Model 2B:** without TO-BelloWrite-A2 (`NonGenerativeTool == 1`).

## 3. Results (Model 2A)

**Model quality.**
- Variance explained: SV1 25.1%, SV2 10.2% (Model 1: 31.4% and 12.4%). Two additional nodes that co-occur with many codes spread the variance more evenly, so a lower share on the first two dimensions is expected.
- Goodness of fit (Pearson): SV1 .99, SV2 .98.
- Window 2 sensitivity: |r| = .992 for SV1 and .959 for SV2.
- Model 2B is practically identical: SV1 25.1%, SV2 10.1%, goodness of fit .99 and .98, window 2 |r| .992 and .966, and the same tests. Its SV1 sign is reversed, which is arbitrary in SVD.

**Axes, read from node positions.** The SV1 sign in Model 2A is the reverse of Model 1 (human-led codes are positive here); the reading is unchanged.
- **SV1 runs from AI-assisted production to human-led work, as in Model 1.**
  - Negative pole: Prov.AS (-2.41), Eng.AD (-1.89), Steer.CM (-1.41), Eng.AS (-1.38), Pos.CM (-1.22), Pos.AS (-0.94).
  - Positive pole: Eng.HD (1.24), Interp.HD (0.94), Interp.CM (0.68), Eng.CM (0.54), **EO_designed (0.50)**.
- **SV2 separates human steering and interpretation (with assistant positioning) from provenance and AI-structured scaffolds.**
  - Negative pole: Interp.CM (-1.75), Pos.AS (-1.35), **EO_designed (-0.99)**, Steer.HD (-0.57), Interp.HD (-0.48), **ML_designed (-0.35)**.
  - Positive pole: Prov.CM (2.83), Prov.AD (2.04), Prov.HD (1.59), Steer.AS (1.44), Pos.HD (1.30), Interp.AS (1.18).
- **Where EO and ML sit.**
  - EO sits on the human-led side of SV1 and on the negative SV2 pole. Its nearest nodes are Steer.HD (distance 0.52), Interp.HD (0.67) and ML (0.72). It is 1.38 from the centroid of the HD triad (Eng.HD, Prov.HD, Interp.HD) and 1.48 from Pos.AS. The triad centroid is pulled upward by Prov.HD, which sits on the provenance pole of SV2, so EO is close to the steering and interpretation members of the triad rather than to its provenance member.
  - ML sits near the origin, slightly on the human-led side (0.16, -0.35). Its nearest node is Steer.HD (0.22), then EO (0.72) and Interp.HD (0.79). It is 0.84 from the triad centroid and 1.49 from Pos.AS.
  - Neither node sits near Pos.AS. Designed epistemic opportunity and mediational literacy are therefore features of human-steered, human-interpreted designs, not of designs that position the AI as an assistant.

**EO- and ML-linked connections (mean line weights).**

| Connection | All units | Georgia Tech | Stanford | Toronto |
|---|---|---|---|---|
| Steer.HD & EO | .135 | .136 | .113 | .155 |
| Interp.HD & EO | .135 | .132 | .099 | .181 |
| Prov.HD & EO | .112 | .112 | .059 | .162 |
| Eng.HD & EO | .098 | .106 | .034 | .140 |
| Steer.HD & ML | .100 | .074 | .184 | .082 |
| Prov.HD & ML | .098 | .067 | .163 | .111 |
| Interp.HD & ML | .089 | .076 | .101 | .111 |
| Eng.HD & ML | .088 | .069 | .124 | .098 |
| EO & ML | .066 | .065 | .049 | .085 |
| Pos.AS & EO | .057 | .065 | .054 | .039 |
| Pos.AS & ML | .055 | .044 | .077 | .061 |

- EO binds most strongly to human steering and human interpretation everywhere. Toronto has the strongest EO links (Interp.HD & EO .181).
- ML is strongest at Stanford, where Steer.HD & ML (.184) and Prov.HD & ML (.163) are among the five strongest connections in the Stanford network. Stanford's ML-present episodes (15 of 24) come mainly from course AI policies and assignments that make students attend to what the AI does for them or assumes (ML-CW 5, ML-EP 3, ML-DD 2, ML-MX 2, ML-RA 2, ML-FR 1).
- EO and ML co-occur only moderately (.066), so they are not redundant nodes.

**Institutions.**
- The three institutions are not distinguishable: Kruskal-Wallis p = .712 on SV1 and .801 on SV2 (Model 1: .691 and .973).
- Mean networks remain anchored on the human-led connections:

| Institution | Strongest connections (mean line weight) |
|---|---|
| Georgia Tech | Eng.HD–Prov.HD .201, Steer.HD–Prov.HD .198, Steer.HD–Interp.HD .198 |
| Stanford | Steer.HD–Prov.HD .219, Eng.HD–Steer.HD .192, **Steer.HD–ML .184** |
| Toronto | Prov.HD–Interp.HD .188, Eng.HD–Prov.HD .184, **Interp.HD–EO .181** |

- Adding EO and ML gives each institution a distinctive third link: ML at Stanford, EO at Toronto.

**Original coding pass.** No difference in ENA space: Mann-Whitney p = .340 on SV1 and .578 on SV2 (Model 1: .350 and .827).

**Code-level tests (learner episodes; Fisher with episodes treated as independent, and GEE with exchangeable correlation clustered by entry).**

| Node | Grouping | Rates | Fisher p | GEE p |
|---|---|---|---|---|
| EO | Institution | GT .46, ST .38, TO .60 | .236 | .417 |
| EO | Cluster (1, 2, 3+) | .56, .48, .39 | .289 | .412 |
| EO | 3+ vs single-episode entries | .39 vs .56 | .131 | .188 (OR 0.49) |
| ML | Institution | GT .32, ST .62, TO .47 | **.019** | **.029** |
| ML | Cluster (1, 2, 3+) | .46, .39, .36 | .642 | .613 |
| ML | 3+ vs single-episode entries | .36 vs .46 | .385 | .352 (OR 0.65) |

- ML is more common at Stanford than at Georgia Tech (GEE odds ratio 3.62, p = .011), and the institutional difference survives clustering by entry. Toronto lies between them (OR 1.95, p = .124).
- EO does not differ by institution or by episode-count cluster. Both nodes are somewhat less frequent in 3+ entries, but no test approaches significance.

## 4. Comparison with Model 1 (Run 4)

**Unit positions.** After aligning signs, Model 2 positions correlate with Model 1 at **r = .991 on SV1** (sign reversed) and **r = .894 on SV2**; the cross-axis correlations are near zero (-.09 and -.05), so the axes did not swap. The 17 shared nodes correlate .96 on SV1 and .96 on SV2. Adding EO and ML leaves the main structure of Model 1 intact and mainly adjusts SV2.

**Units that moved most.** Shifts are small: mean 0.12, median 0.11, maximum 0.29 (in Model 1 units, with Model 2 signs aligned). Eleven units moved more than 0.20. Movement on SV2 tracks EO: the correlation between an entry's share of EO-present episodes and its SV2 shift is r = -.59 (for ML, r = -.14). Entries with EO move toward the EO node (mean SV2 shift -0.05), and entries without EO move away from it, because the space is re-centred (+0.09 for entries with neither code, +0.07 for ML only).

| Unit | EO / ML episodes (of n) | Code source | Shift SV1, SV2 (aligned) | Explanation |
|---|---|---|---|---|
| ST-13 | 0 / 1 (1) | v0.7.1 | +0.06, +0.28 | ML without EO: away from the EO pole on SV2 |
| ST-02 | 0 / 0 (2) | v0.7.1 | +0.03, +0.28 | Neither code: away from the EO pole |
| ST-29 | 0 / 1 (1) | v0.8 | +0.08, +0.26 | ML-CW without EO (Stage A three-way split) |
| GT-34, ST-33 | 1 / 1 (1) | v0.7.1 | -0.18, -0.19 | AS-profile entries with both codes: pulled toward the human-led side and the EO pole |
| GT-63 | 0 / 0 (2) | v0.8 | +0.10, +0.24 | Neither code (both episodes NE and ML-NA) |
| GT-67 | 1 / 0 (3) | v0.7.1 | +0.05, +0.22 | EO in only one of three episodes |
| ST-08 | 1 / 0 (1) | v0.7.1 | -0.02, -0.22 | EO only: toward the EO pole |
| GT-21, GT-50 | 0 / 0 (1) | v0.7.1 | +0.11, +0.18 | Neither code: HD-profile entries move away from the EO and ML cluster |

The full list, with each unit's EO and ML values, is in `run5_vs_run4_units.csv`.

**Single comparison table.**

| | Model 1 (Run 4) | Model 2 (Run 5) |
|---|---|---|
| Nodes | 17 | 19 (adds EO_designed, ML_designed) |
| Variance SV1, SV2 | 31.4%, 12.4% | 25.1%, 10.2% |
| Goodness of fit SV1, SV2 | .99, .98 | .99, .98 |
| Window 2 \|r\| SV1, SV2 | .991, .943 | .992, .959 |
| Model B variance SV1, SV2 | 31.5%, 12.5% | 25.1%, 10.1% |
| Institution Kruskal-Wallis p (SV1, SV2) | .691, .973 | .712, .801 |
| Pass Mann-Whitney p (SV1, SV2) | .350, .827 | .340, .578 |
| SV1 reading | AI-assisted production vs human-led work | the same (sign reversed) |
| SV2 reading | human steering and interpretation vs provenance and scaffolds | the same; EO and ML join the steering and interpretation pole |
| Distinctive institutional link | Stanford Steer.HD–Pos.AS | Stanford Steer.HD–ML; Toronto Interp.HD–EO |
| Unit positions vs Model 1 | | r = .991 (SV1), .894 (SV2) |

**Sensitivity: v0.7.1-carried against v0.8-resolved EO and ML codes.** We fitted the model separately on the 80 learner episodes whose EO and ML codes are carried from v0.7.1 (52 units, 16 codes above threshold) and on the 59 recoded learner episodes (29 units, 17 codes). Each subset has its own space, so we compare neighbourhoods rather than coordinates.
- **Presence rates do not differ:** EO .50 (carried) against .44 (resolved), Fisher p = .498; ML .35 against .47, p = .163.
- **EO behaves the same in both subsets.** Its strongest links are Steer.HD and Interp.HD in both (carried .146 and .138; resolved .117 and .131), and its nearest nodes are human steering and interpretation in both. Among EO-present episodes, Eng.HD is somewhat more frequent in the resolved subset (.85 against .63, p = .094).
- **ML differs in its neighbourhood.** In the resolved subset ML sits next to Steer.HD (distance 0.23), as in Model 2. In the carried subset it moves to the scaffold pole beside Steer.AS (0.31) and Prov.AD. Among ML-present episodes, Steer.HD is more frequent in the carried subset (.89 against .64, p = .055). The carried ML codes therefore attach more to policy-style human steering, and the resolved ones to a broader mix including CM steering (.11). This is consistent with ML's borderline reliability and with the fact that the carried codes were never re-tested under R17's strict exclusion.
- **Caveats.** The subsets are not comparable samples: the recoded episodes over-represent Toronto and pilot entries (Toronto 11 of 29 units, against 7 of 52). The recoded-only model is small (29 units), and its node optimisation reported singular systems (the fit is still .99), so its node positions are approximate.

## 5. Extension codes (descriptive)

Values come from the v0.8 resolution where one exists: EO and ML intended (Stage A); holistic intended, Start and End configuration (v0.8 adjudication and the C12 sweep). Other families use the v0.8 three-coder majority for the 65 recoded episodes and the v0.7.1 moderated value for the 97 others, and are **provisional**. Alpha values are the v0.8 three-coder Krippendorff's alpha (65 episodes). Usability status follows section 3 of the brief.

**Episodes with no v0.8 majority** (shown as "No majority" in the tables): Dialogue Type GT-09-A2, GT-30-A2; Epistemic Object GT-31-A1, GT-66-A3, TO-Sanders-A3, TO-Seward-A2; Stated Purpose GT-19-A2, GT-28-C2, GT-66-A1, ST-28-A1, ST-28-A2, ST-28-A3, TO-BelloWrite-A3; Learner Variability GT-09-A4; EO reported TO-Goldfarb-A2; ML reported GT-22-A2, GT-58-A1, TO-Goldfarb-A1; R-D1 GT-58-A1; R-D2 GT-22-A2; R-D3 GT-28-A1; Uptake reported tier GT-19-A1.

**What instructor narratives in this corpus do not supply.** The reported profile is thin because of how faculty write about their teaching, not because the codes fail to apply.
- No episode in the corpus has a T1 trace: no transcript, log or student artifact of a learner's exchange with the AI. Every reported code rests on a participant account (T2, 140 learner tier codes) or an instructor or developer observation (T3, 132).
- 69% to 78% of learner episodes are NE on each reported dimension, and Stanford's entries, which are course policies, have no reported codes at all.
- Reported uptake is NE in 87% of learner episodes. Only 18 report how learners took up AI contributions, mostly as application (UP-AP, 9).
- Designed epistemic opportunities are almost always evaluation (EO-EV, 56 of 66 EO-present learner episodes). Inherited assumptions (EO-IN, 1) and redirection of an AI frame (EO-RD, 2) are rare, because they require the narrative to show what the AI assumed and what learners then did with it. That is the kind of detail a trace supplies and a design description seldom does.

These gaps describe reporting practice in instructor-authored collections. They mark where enactment studies, with traces and learner accounts, would be needed to test the reported profile.

## 6. Interpretation (with caveats)

- **Designed epistemic opportunity belongs to the human-led pattern.** EO joins the human steering and interpretation pole and links most strongly to Steer.HD and Interp.HD. In these intended designs, opportunities to examine AI-introduced assumptions are built into activities where learners already steer and interpret, and almost always take the form of evaluation against evidence or criteria (EO-EV).
- **Designed mediational literacy is near the centre of the space and varies by institution.** ML is tied to human steering but less strongly than EO, and it is the one node with a robust institutional difference (Stanford above Georgia Tech, p = .03 after clustering). This partly reflects the kind of entry each collection holds.
- **Model 1's structure is robust to adding these nodes.** SV1 is reproduced almost exactly (r = .99) and SV2 closely (r = .89). Model 2 therefore extends Model 1 rather than replacing it.
- **ML's position depends on code source.** EO behaves the same whether its codes were carried from v0.7.1 or resolved under v0.8. ML does not. Together with its borderline alpha (.66), this means ML findings should be stated cautiously, and the 28 carried ML-present learner episodes are the obvious candidates for re-testing under R17.

## 7. Limitations and open items

1. **Mixed provenance of the EO and ML codes.** For the 97 non-recoded episodes, `EO_designed` and `ML_designed` are v0.7.1 codes, never re-tested under v0.8 (the C12 sweep did not touch them). The sensitivity analysis shows this matters for ML's neighbourhood, though not for its overall rate.
2. **Borderline reliability of ML intended** (alpha .66, below the .667 criterion), concentrated in the R17 boundary cases flagged in Stage A.
3. **Presence nodes only.** Following the October 30 decision, EO and ML enter as presence, so the model does not distinguish evaluation from redirection, or framing awareness from decision-making. The specific values are summarized in section 5.
4. **Not independent reliability.** The three coders and the Stage A adjudicator were sessions of AI models; agreement reflects consistency under shared rules. The adjudicator's own earlier coding session (CCODEv8) was one of the three coders, which is noted on the one ruling where it was the minority.
5. **Open items carried from Run 4:** the CM codes resting on C1's interlocutor clause (ST-28-A2, TO-BelloConv-A1, ST-10-A2) have not been re-tested against mutual adaptation; eight episodes have a trajectory inconsistent with C10; episode segmentation remains frozen. None of these affects the EO or ML codes directly, but ST-28-A2 (ML-RA) and TO-BelloConv-A1 (ML-RA) carry both an open CM code and an ML code.
6. **Scope.** The intended (design) profile only. The extension-code summary in section 5 shows why a reported-profile model is not yet possible with this corpus.
7. **Figures and model objects.** The Drive connector accepts binary files only as base64 text, which could not be transferred reliably, so the PNG and RDS files travel separately in `run5_drive_bundle.zip` (see the folder README).

## References

Bowman, D., Swiecki, Z., Cai, Z., Wang, Y., Eagan, B., Linderoth, J., & Shaffer, D. W. (2021). The mathematical foundations of epistemic network analysis. In A. R. Ruis & S. B. Lee (Eds.), *Advances in quantitative ethnography* (pp. 91–105). Springer. https://doi.org/10.1007/978-3-030-67788-6_7

Hayes, A. F., & Krippendorff, K. (2007). Answering the call for a standard reliability measure for coding data. *Communication Methods and Measures, 1*(1), 77–89. https://doi.org/10.1080/19312450709336664

Liang, K.-Y., & Zeger, S. L. (1986). Longitudinal data analysis using generalized linear models. *Biometrika, 73*(1), 13–22. https://doi.org/10.1093/biomet/73.1.13

Shaffer, D. W., Collier, W., & Ruis, A. R. (2016). A tutorial on epistemic network analysis: Analyzing the structure of connections in cognitive, social, and interaction data. *Journal of Learning Analytics, 3*(3), 9–45. https://doi.org/10.18608/jla.2016.33.3

## Appendix: extension-code tables

One table per code family, learner episodes and the parallel instructor-only panel, by institution (n and percentage of episodes). Instructor-only episodes occur only at Georgia Tech and Toronto.

#### Learner panel

**EO intended** (alpha 0.70; Model 2 (EO_designed); provisional values 0%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 73 (53%) | 46 (54%) | 15 (62%) | 12 (40%) |
| EO-EV | 56 (40%) | 34 (40%) | 6 (25%) | 16 (53%) |
| EO-RE | 4 (3%) | 2 (2%) | 2 (8%) | 0 (0%) |
| EO-CH | 3 (2%) | 1 (1%) | 0 (0%) | 2 (7%) |
| EO-RD | 2 (1%) | 1 (1%) | 1 (4%) | 0 (0%) |
| EO-IN | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |

**ML intended** (alpha 0.66; Model 2 (ML_designed), borderline alpha; provisional values 0%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| ML-NA | 83 (60%) | 58 (68%) | 9 (38%) | 16 (53%) |
| ML-CW | 17 (12%) | 6 (7%) | 5 (21%) | 6 (20%) |
| ML-DD | 15 (11%) | 9 (11%) | 2 (8%) | 4 (13%) |
| ML-EP | 10 (7%) | 5 (6%) | 3 (12%) | 2 (7%) |
| ML-MX | 7 (5%) | 4 (5%) | 2 (8%) | 1 (3%) |
| ML-RA | 4 (3%) | 1 (1%) | 2 (8%) | 1 (3%) |
| ML-FR | 3 (2%) | 2 (2%) | 1 (4%) | 0 (0%) |

**Epistemic Object (EB)** (alpha 0.55; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 73 (53%) | 46 (54%) | 15 (62%) | 12 (40%) |
| Evidence and relevance | 25 (18%) | 11 (13%) | 6 (25%) | 8 (27%) |
| Perspective and bias | 14 (10%) | 11 (13%) | 2 (8%) | 1 (3%) |
| Reasoning norms | 8 (6%) | 8 (9%) | 0 (0%) | 0 (0%) |
| Multiple | 5 (4%) | 2 (2%) | 0 (0%) | 3 (10%) |
| Explanation and causality | 5 (4%) | 2 (2%) | 0 (0%) | 3 (10%) |
| Authority and credibility | 5 (4%) | 3 (4%) | 1 (4%) | 1 (3%) |
| No majority | 4 (3%) | 2 (2%) | 0 (0%) | 2 (7%) |

**Uptake intended** (alpha 0.40; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 79 (57%) | 50 (59%) | 12 (50%) | 17 (57%) |
| UP-AP | 40 (29%) | 22 (26%) | 9 (38%) | 9 (30%) |
| UP-MX | 11 (8%) | 9 (11%) | 1 (4%) | 1 (3%) |
| UP-AD | 5 (4%) | 3 (4%) | 1 (4%) | 1 (3%) |
| UP-CT | 3 (2%) | 1 (1%) | 1 (4%) | 1 (3%) |
| UP-RJ | 1 (1%) | 0 (0%) | 0 (0%) | 1 (3%) |

**Uptake reported** (alpha 0.40; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 121 (87%) | 70 (82%) | 24 (100%) | 27 (90%) |
| UP-AP | 9 (6%) | 7 (8%) | 0 (0%) | 2 (7%) |
| UP-MX | 6 (4%) | 5 (6%) | 0 (0%) | 1 (3%) |
| UP-AD | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |
| UP-CT | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |
| UP-RJ | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |

**Dialogue Type (DT)** (alpha 0.31; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 68 (49%) | 35 (41%) | 15 (62%) | 18 (60%) |
| Instructional | 23 (17%) | 18 (21%) | 2 (8%) | 3 (10%) |
| Collaborative | 20 (14%) | 12 (14%) | 5 (21%) | 3 (10%) |
| Feedback-oriented | 18 (13%) | 12 (14%) | 1 (4%) | 5 (17%) |
| Mixed | 4 (3%) | 3 (4%) | 1 (4%) | 0 (0%) |
| Reflective | 4 (3%) | 3 (4%) | 0 (0%) | 1 (3%) |
| No majority | 2 (1%) | 2 (2%) | 0 (0%) | 0 (0%) |

**Stated Purpose (DP)** (alpha 0.53; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| Critical evaluation of AI (HD) | 35 (25%) | 21 (25%) | 2 (8%) | 12 (40%) |
| Guided practice (AS) | 22 (16%) | 16 (19%) | 0 (0%) | 6 (20%) |
| Multiple | 22 (16%) | 12 (14%) | 2 (8%) | 8 (27%) |
| Independent production (HD) | 20 (14%) | 10 (12%) | 8 (33%) | 2 (7%) |
| Not stated | 14 (10%) | 8 (9%) | 6 (25%) | 0 (0%) |
| Introduce or model (AD) | 10 (7%) | 9 (11%) | 0 (0%) | 1 (3%) |
| Inquiry and refinement (CM) | 9 (6%) | 6 (7%) | 3 (12%) | 0 (0%) |
| No majority | 7 (5%) | 3 (4%) | 3 (12%) | 1 (3%) |

**Learner variability (LV)** (alpha 0.48; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| None noted | 108 (78%) | 59 (69%) | 24 (100%) | 25 (83%) |
| Prior knowledge | 13 (9%) | 13 (15%) | 0 (0%) | 0 (0%) |
| Multiple | 6 (4%) | 6 (7%) | 0 (0%) | 0 (0%) |
| Orientation toward AI | 5 (4%) | 3 (4%) | 0 (0%) | 2 (7%) |
| AI literacy | 3 (2%) | 0 (0%) | 0 (0%) | 3 (10%) |
| Self-regulation | 2 (1%) | 2 (2%) | 0 (0%) | 0 (0%) |
| No majority | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |
| Motivation | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |

**Sociotechnical Frame** (alpha 0.49; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| High-stakes assessment | 62 (45%) | 29 (34%) | 9 (38%) | 24 (80%) |
| Low-stakes or formative | 32 (23%) | 27 (32%) | 2 (8%) | 3 (10%) |
| Self-directed or optional | 25 (18%) | 22 (26%) | 0 (0%) | 3 (10%) |
| Unclear | 18 (13%) | 7 (8%) | 11 (46%) | 0 (0%) |
| Professional or workplace | 2 (1%) | 0 (0%) | 2 (8%) | 0 (0%) |

**Laurillard activity type** (alpha 0.70; Descriptive context; provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| Inquiry, production | 83 (60%) | 50 (59%) | 17 (71%) | 16 (53%) |
| Practice | 22 (16%) | 16 (19%) | 0 (0%) | 6 (20%) |
| Reflection | 12 (9%) | 4 (5%) | 2 (8%) | 6 (20%) |
| Acquisition | 10 (7%) | 9 (11%) | 0 (0%) | 1 (3%) |
| Inquiry, discussion, collaboration | 10 (7%) | 6 (7%) | 3 (12%) | 1 (3%) |
| NE | 2 (1%) | 0 (0%) | 2 (8%) | 0 (0%) |

**Holistic intended** (alpha 0.70; Descriptive context; provisional values 0%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| HD | 92 (66%) | 54 (64%) | 18 (75%) | 20 (67%) |
| AS | 33 (24%) | 20 (24%) | 4 (17%) | 9 (30%) |
| AD | 6 (4%) | 6 (7%) | 0 (0%) | 0 (0%) |
| CM | 6 (4%) | 4 (5%) | 1 (4%) | 1 (3%) |
| Mixed | 2 (1%) | 1 (1%) | 1 (4%) | 0 (0%) |

**Start Config** (alpha 0.69; Descriptive context; provisional values 53%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| HD | 89 (64%) | 53 (62%) | 17 (71%) | 19 (63%) |
| AS | 37 (27%) | 22 (26%) | 6 (25%) | 9 (30%) |
| AD | 7 (5%) | 7 (8%) | 0 (0%) | 0 (0%) |
| CM | 6 (4%) | 3 (4%) | 1 (4%) | 2 (7%) |

**End Config** (alpha 0.66; Descriptive context; provisional values 55%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| HD | 93 (67%) | 56 (66%) | 17 (71%) | 20 (67%) |
| AS | 31 (22%) | 18 (21%) | 4 (17%) | 9 (30%) |
| CM | 8 (6%) | 4 (5%) | 3 (12%) | 1 (3%) |
| AD | 7 (5%) | 7 (8%) | 0 (0%) | 0 (0%) |

**EO reported** (alpha 0.75; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 109 (78%) | 62 (73%) | 24 (100%) | 23 (77%) |
| EO-EV | 24 (17%) | 18 (21%) | 0 (0%) | 6 (20%) |
| EO-RE | 3 (2%) | 3 (4%) | 0 (0%) | 0 (0%) |
| EO-IN | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |
| EO-RD | 1 (1%) | 1 (1%) | 0 (0%) | 0 (0%) |
| No majority | 1 (1%) | 0 (0%) | 0 (0%) | 1 (3%) |

**ML reported** (alpha 0.64; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| ML-NA | 103 (74%) | 56 (66%) | 24 (100%) | 23 (77%) |
| ML-DD | 11 (8%) | 9 (11%) | 0 (0%) | 2 (7%) |
| ML-EP | 10 (7%) | 9 (11%) | 0 (0%) | 1 (3%) |
| ML-CW | 7 (5%) | 6 (7%) | 0 (0%) | 1 (3%) |
| ML-MX | 3 (2%) | 2 (2%) | 0 (0%) | 1 (3%) |
| No majority | 3 (2%) | 2 (2%) | 0 (0%) | 1 (3%) |
| ML-RA | 2 (1%) | 1 (1%) | 0 (0%) | 1 (3%) |

**R-D1 Engagement Type** (alpha 0.61; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 96 (69%) | 53 (62%) | 24 (100%) | 19 (63%) |
| Coded | 43 (31%) | 32 (38%) | 0 (0%) | 11 (37%) |

**R-D2 Interaction Structure (steering)** (alpha 0.65; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 104 (75%) | 60 (71%) | 24 (100%) | 20 (67%) |
| Coded | 35 (25%) | 25 (29%) | 0 (0%) | 10 (33%) |

**R-D3 Provenance of Production** (alpha 0.65; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 101 (73%) | 56 (66%) | 24 (100%) | 21 (70%) |
| Coded | 38 (27%) | 29 (34%) | 0 (0%) | 9 (30%) |

**R-D4 Interpretive Influence** (alpha 0.79; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 97 (70%) | 50 (59%) | 24 (100%) | 23 (77%) |
| Coded | 42 (30%) | 35 (41%) | 0 (0%) | 7 (23%) |

**R-D5 Positioning (learner orientation)** (alpha 0.74; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=139) | Georgia Tech (n=85) | Stanford (n=24) | Toronto (n=30) |
|---|---|---|---|---|
| NE | 108 (78%) | 60 (71%) | 24 (100%) | 24 (80%) |
| Coded | 31 (22%) | 25 (29%) | 0 (0%) | 6 (20%) |

**Evidence tiers across all reported fields** (T1 0, T2 140, T3 132, no majority 1; 839 fields carry no tier because the field is NE)


#### Instructor-only panel

**EO intended** (alpha 0.70; Model 2 (EO_designed); provisional values 0%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 20 (87%) | 18 (90%) | 2 (67%) |
| EO-EV | 3 (13%) | 2 (10%) | 1 (33%) |

**ML intended** (alpha 0.66; Model 2 (ML_designed), borderline alpha; provisional values 0%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| ML-NA | 20 (87%) | 18 (90%) | 2 (67%) |
| ML-DD | 2 (9%) | 1 (5%) | 1 (33%) |
| ML-CW | 1 (4%) | 1 (5%) | 0 (0%) |

**Epistemic Object (EB)** (alpha 0.55; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 20 (87%) | 18 (90%) | 2 (67%) |
| Perspective and bias | 2 (9%) | 1 (5%) | 1 (33%) |
| Evidence and relevance | 1 (4%) | 1 (5%) | 0 (0%) |

**Uptake intended** (alpha 0.40; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| UP-AP | 11 (48%) | 10 (50%) | 1 (33%) |
| NE | 9 (39%) | 7 (35%) | 2 (67%) |
| UP-AD | 2 (9%) | 2 (10%) | 0 (0%) |
| UP-MX | 1 (4%) | 1 (5%) | 0 (0%) |

**Uptake reported** (alpha 0.40; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 10 (43%) | 9 (45%) | 1 (33%) |
| UP-AP | 9 (39%) | 8 (40%) | 1 (33%) |
| UP-AD | 3 (13%) | 2 (10%) | 1 (33%) |
| UP-MX | 1 (4%) | 1 (5%) | 0 (0%) |

**Dialogue Type (DT)** (alpha 0.31; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 16 (70%) | 13 (65%) | 3 (100%) |
| Collaborative | 5 (22%) | 5 (25%) | 0 (0%) |
| Instructional | 2 (9%) | 2 (10%) | 0 (0%) |

**Stated Purpose (DP)** (alpha 0.53; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| Not stated | 19 (83%) | 16 (80%) | 3 (100%) |
| Critical evaluation of AI (HD) | 1 (4%) | 1 (5%) | 0 (0%) |
| Independent production (HD) | 1 (4%) | 1 (5%) | 0 (0%) |
| Introduce or model (AD) | 1 (4%) | 1 (5%) | 0 (0%) |
| Multiple | 1 (4%) | 1 (5%) | 0 (0%) |

**Learner variability (LV)** (alpha 0.48; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| None noted | 22 (96%) | 19 (95%) | 3 (100%) |
| Orientation toward AI | 1 (4%) | 1 (5%) | 0 (0%) |

**Sociotechnical Frame** (alpha 0.49; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| Instructor preparation | 20 (87%) | 18 (90%) | 2 (67%) |
| Professional or workplace | 2 (9%) | 1 (5%) | 1 (33%) |
| Unclear | 1 (4%) | 1 (5%) | 0 (0%) |

**Laurillard activity type** (alpha 0.70; Descriptive context; provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 23 (100%) | 20 (100%) | 3 (100%) |

**Holistic intended** (alpha 0.70; Descriptive context; provisional values 0%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| HD | 13 (57%) | 12 (60%) | 1 (33%) |
| AS | 8 (35%) | 6 (30%) | 2 (67%) |
| AD | 2 (9%) | 2 (10%) | 0 (0%) |

**Start Config** (alpha 0.69; Descriptive context; provisional values 44%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| HD | 13 (57%) | 12 (60%) | 1 (33%) |
| AS | 8 (35%) | 6 (30%) | 2 (67%) |
| AD | 2 (9%) | 2 (10%) | 0 (0%) |

**End Config** (alpha 0.66; Descriptive context; provisional values 44%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| HD | 13 (57%) | 12 (60%) | 1 (33%) |
| AS | 8 (35%) | 6 (30%) | 2 (67%) |
| AD | 2 (9%) | 2 (10%) | 0 (0%) |

**EO reported** (alpha 0.75; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 20 (87%) | 18 (90%) | 2 (67%) |
| EO-EV | 3 (13%) | 2 (10%) | 1 (33%) |

**ML reported** (alpha 0.64; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| ML-NA | 20 (87%) | 18 (90%) | 2 (67%) |
| ML-CW | 1 (4%) | 1 (5%) | 0 (0%) |
| ML-DD | 1 (4%) | 0 (0%) | 1 (33%) |
| ML-MX | 1 (4%) | 1 (5%) | 0 (0%) |

**R-D1 Engagement Type** (alpha 0.61; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| Coded | 14 (61%) | 12 (60%) | 2 (67%) |
| NE | 9 (39%) | 8 (40%) | 1 (33%) |

**R-D2 Interaction Structure (steering)** (alpha 0.65; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| Coded | 16 (70%) | 13 (65%) | 3 (100%) |
| NE | 7 (30%) | 7 (35%) | 0 (0%) |

**R-D3 Provenance of Production** (alpha 0.65; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| Coded | 19 (83%) | 16 (80%) | 3 (100%) |
| NE | 4 (17%) | 4 (20%) | 0 (0%) |

**R-D4 Interpretive Influence** (alpha 0.79; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| NE | 12 (52%) | 10 (50%) | 2 (67%) |
| Coded | 11 (48%) | 10 (50%) | 1 (33%) |

**R-D5 Positioning (learner orientation)** (alpha 0.74; Descriptive only (insufficient evidence); provisional values 100%)

| Value | All (n=23) | Georgia Tech (n=20) | Toronto (n=3) |
|---|---|---|---|
| Coded | 15 (65%) | 12 (60%) | 3 (100%) |
| NE | 8 (35%) | 8 (40%) | 0 (0%) |

**Evidence tiers across all reported fields** (T1 0, T2 91, T3 3; 90 fields carry no tier because the field is NE)
