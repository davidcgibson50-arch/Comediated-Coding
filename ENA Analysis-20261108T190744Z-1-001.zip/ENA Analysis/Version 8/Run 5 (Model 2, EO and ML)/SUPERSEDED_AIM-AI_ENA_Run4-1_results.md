# AIM-AI ENA Run 4.1: Model 1 on the v0.8.1 coding, results and comparison with Run 4

Date: October 30, 2026. Codebook: AIM-AI v0.8.3. Coding: v0.8 plus patch v0.8.1 (`AIM-AI_v081_Patch_Log.csv`). Profile modelled: **intended (T4)**. Run 4.1 repeats Run 4 Models 1A and 1B on the patched data and supersedes Run 4 for the intended profile.

## Files in this set

- **Patched data:** `AIM-AI_v081_ENA_ready_intended_EOML.csv` (model input), `AIM-AI_v081_all162_intended.csv`, and `AIM-AI_v081_Patch_Verification_Note.md`.
- **ENA output:** `run41_points.csv`, `run41_mean_line_weights.csv`, `run41_node_positions.csv`, `run41_unit_line_weights.csv`, `run41_set.rds` (model object), `run41_model_output.txt`; the same files with the prefixes `run41_codes17_` (the Run 4 17-code list on the patched data) and `run41_1B_` (Model 1B).
- **Figures:** `run41_points_by_institution.png`, `run41_points_by_original_pass.png`, `run41_mean_network_{Georgia_Tech,Stanford,Toronto}.png`, and the cluster figures `run41_cluster_positions.png`, `run41_mean_networks_by_cluster.png`, `run41_heatmap_sequence_position.png`, `run41_heatmap_dimension_by_cluster.png`.
- **Comparison with Run 4:** `run41_vs_run4_units.csv` (aligned positions, shift and patch rows for all 81 units), `run41_vs_run4_nodes.csv`, `run41_vs_run4.json`.
- **Cluster, sequence and dependence analyses:** `run41_results.json`, `run41_cluster_entries.csv`, `run41_cluster_mean_line_weights.csv`, `run41_code_level_tests.csv`, `run41_sequence_steps.csv`, `run41_step_table.csv`, `run41_instructor_panel.csv`.
- **Scripts:** `patch081.py`, `r30_v081.py`, `run41.R`, `plots41.R`, `passplot41.R`, `compare41.py`, `cluster4.py` (unchanged from Run 4).

## 1. What changed since Run 4

- **Patch v0.8.1** (approved October 30, 2026) changed 30 cells in 13 learner episodes:
  - **CM codes re-tested against mutual adaptation** (C1, C4, C6 and C12). The CM codes in ST-28-A2, TO-BelloConv-A1 and ST-10-A2, which rested on C1's interlocutor clause, became HD or AS. The extended CM sweep re-coded GT-67-A1, GT-08-A2, GT-18-A1 and TO-Wong-A1, and confirmed CM in GT-09-A3, GT-09-A4, GT-15-A1, TO-SmithMyth-A1 (I-D1, I-D5) and TO-Wong-A1 (I-D5).
  - **C10 conflicts resolved.** Start and End configurations were corrected in the eight episodes listed in the Run 4 brief. GT-67-A1, ST-02-A2 and ST-21-A1 became Within-episode.
- **Learner-episode counts.** Eng.CM falls from 11 to 6, Steer.CM from 6 to 3, Prov.CM from 4 to 2, Interp.CM from 3 to 2 and Pos.CM from 7 to 5. Holistic CM falls from 6 to 3 (GT-09-A3, GT-09-A4, GT-15-A1). Within-episode use cases rise from 1 to 4. EO and ML are unaffected.
- **Code set.** At the frequency threshold of 3 learner episodes, **15 codes** are retained: Prov.CM and Interp.CM drop out, and Steer.CM sits exactly at 3.
- **Data check.** Every `Old` value in the patch log matched both files. GT-41-A1 I-D5 was corrected from "Mixed" to AS in the all162 file (a synchronization error; the ENA file already carried the Run 3.1 ruling). See the verification note.

## 2. ENA settings (unchanged from Run 4)

- **Software:** rENA 0.3.1 on R 4.3.3.
- **Data:** learner episodes only: 139 episodes in **81 units** (Georgia Tech 45, Stanford 18, Toronto 18); 28 pilot and 53 full-pass entries by `OriginalPass`.
- **Units:** Institution + EntryID. **Conversation:** Institution + ActivityID.
- **Window:** 1, with window 2 as a sensitivity check. SVD rotation.
- **Model 1B:** without TO-BelloWrite-A2 (`NonGenerativeTool == 1`).

## 3. Results (Model 1A)

**Model quality.**
- Variance explained: SV1 33.9%, SV2 12.8% (Run 4: 31.4% and 12.4%).
- Goodness of fit (Pearson): SV1 .99, SV2 .98.
- Window 2 sensitivity: |r| = .995 for SV1 and .942 for SV2.
- **Model 1B** is practically identical: SV1 33.9%, SV2 12.9%, window 2 |r| .995 and .955, and the same tests.
- **The Run 4 17-code list on the patched data** gives SV1 33.6% and SV2 12.8%, with the same tests. The change from Run 4 therefore comes from the coding, not from dropping Prov.CM and Interp.CM.
- The node optimisation reported singular systems in some fits (logged in `run41_model_output.txt`). Goodness of fit is unaffected.

**Axes, read from node positions.** The reading is the same as in Run 4.
- **SV1 runs from human-led to AI-assisted work.**
  - Negative pole: Eng.HD (-1.17), Interp.HD (-0.83), Steer.HD (-0.32).
  - Positive pole: Prov.AS (2.11), Eng.AS (1.31), Eng.AD (1.06), Pos.AS (0.87), Steer.CM (0.84).
- **SV2 runs from human steering and interpretation with assistant positioning to provenance and AI-structured scaffolds.**
  - Negative pole: Pos.AS (-1.76), Steer.HD (-0.67), Steer.CM (-0.39), Interp.HD (-0.30).
  - Positive pole: Prov.AD (1.78), Pos.HD (1.67), Steer.AS (1.52), Interp.AS (1.11), Prov.HD (1.00).
- **Where the CM nodes moved.** With fewer and different episodes behind them, the remaining CM nodes moved toward the centre: Steer.CM from (1.41, 0.65) to (0.84, -0.39), Pos.CM from (1.17, 0.40) to (0.56, 0.14) and Eng.CM from (-0.53, 0.40) to (-0.14, 0.79).

**Institutions.** The three institutions are not distinguishable: Kruskal-Wallis p = .726 on SV1 and .615 on SV2 (Run 4: .691 and .973). The mean networks keep the Run 4 pattern:

| Institution | Strongest connections (mean line weight) |
|---|---|
| Georgia Tech | Eng.HD–Prov.HD .247, Steer.HD–Interp.HD .241, Prov.HD–Interp.HD .236 |
| Stanford | Steer.HD–Prov.HD .305, Eng.HD–Steer.HD .244, Eng.HD–Prov.HD .227, Steer.HD–Pos.AS .206 |
| Toronto | Eng.HD–Prov.HD .262, Prov.HD–Interp.HD .254, Eng.HD–Interp.HD .240 |

**Original coding pass.**
- **ENA space:** Mann-Whitney p = .398 on SV1 and .438 on SV2 (Run 4: .350 and .827).
- **Code level, pilot against full entries (learner episodes):**
  - Steer.HD .74 against .86, Fisher p = .086 (Run 4: .035).
  - Interp.HD .54 against .72, p = .034 (Run 4: .022).
  - Holistic CM .03 against .01, p = .582 (Run 4: .086).
- The Steer.HD and holistic CM gaps narrowed because three pilot CM episodes became HD. The Interp.HD gap remains.

## 4. Comparison with Run 4

| | Run 4 | Run 4.1 |
|---|---|---|
| Codes | 17 | 15 (Prov.CM and Interp.CM below threshold) |
| Variance SV1, SV2 | 31.4%, 12.4% | 33.9%, 12.8% |
| Goodness of fit SV1, SV2 | .99, .98 | .99, .98 |
| Window 2 \|r\| SV1, SV2 | .991, .943 | .995, .942 |
| Model 1B variance SV1, SV2 | 31.5%, 12.5% | 33.9%, 12.9% |
| Institution Kruskal-Wallis p (SV1, SV2) | .691, .973 | .726, .615 |
| Pass Mann-Whitney p (SV1, SV2) | .350, .827 | .398, .438 |
| Unit positions vs Run 4 | | r = .993 (SV1), .958 (SV2); no sign flip |
| Node positions vs Run 4 (15 shared) | | r = .966 (SV1), .948 (SV2) |

**Units that moved most.** Shifts are small (mean 0.05, median 0.02) and concentrate in the patched units: mean shift 0.16 for the 13 units with patch rows, against 0.03 for the other 68.

| Unit | Shift | Patch rows |
|---|---|---|
| TO-BelloConv | 0.49 | A1: I-D2 and I-D3 CM to HD; holistic, Start and End CM to HD |
| TO-Wong | 0.34 | A1: I-D1 CM to HD |
| ST-10 | 0.33 | A2: I-D1 CM to HD, I-D5 CM to AS; Start AS to HD, End CM to HD |
| ST-28 | 0.27 | A2: I-D2 and I-D3 CM to HD; holistic, Start and End CM to HD |
| GT-18 | 0.26 | A1: I-D1 and I-D2 CM to AS |
| GT-67 | 0.19 | A1: I-D1, I-D4 and I-D5 CM to HD; holistic and End CM to HD; Within-episode |
| GT-15 | 0.17 | none (its CM codes stand; it moved because the CM nodes moved) |
| GT-08 | 0.12 | A2: I-D1 CM to AS |

Episodes moving from CM to HD shift toward the human-led pole. Those moving from CM to AS (GT-18, GT-08) shift toward the AI-assisted pole.

## 5. Cluster, sequence and dependence analyses (October 28 findings, Run 4.1)

We re-ran the Run 4 section 5 analyses with `cluster4.py` unchanged. `TrajectoryUseCase`, `HS`, `StepChange` and `EntrySequenceChange` changed for GT-08, GT-18, GT-67, ST-02, ST-21, ST-28, TO-BelloConv and TO-Wong, and the dimension codes changed in all 13 patched episodes, so every analysis is affected. The clusters are unchanged (41, 27 and 13 entries).

| # | October 28 finding | Run 4.1 evidence | Verdict | Confidence (Run 4 → Run 4.1) |
|---|---|---|---|---|
| 1 | Episode count does not move entries in ENA space. | 3+ vs 1, controlling for institution, word count and topics: SV1 b = -0.13, p = .42; SV2 b = -0.03, p = .68. | **Holds** | Moderate → **Moderate** |
| 2 | Longer accounts tighten the human-constructive triad. | Triad +0.34 (p = .025); +0.30 (p = .056) with institution; +0.34 (p = .053) with institution and depth. Steering connections do not differ (p = .98). | **Holds**, borderline | Low → **Low** |
| 3 | Co-mediation and unstated positioning concentrate in the 3+ cluster. | Positioning NE unchanged: 45% vs 24%, GEE OR 2.85 after controls (p = .040), entry permutation p = .06. Holistic CM in 3+ entries now rests on two episodes in one entry (GT-09): Fisher p = .24, GEE p = .28. Pos.HD 9% vs 19%, p = .11 to .21. Eng.AS p = .12 to .25. Prov.AS unchanged (GEE p = .016 after controls; permutation p = .07 to .09). | **Holds for NE; the co-mediation part no longer holds**; Eng.AS and Pos.HD weaken further | NE: Low → **Low**; CM: Very low → **not supported**; Pos.HD: Very low → **Very low**; Prov.AS: **Low** |
| 4 | Sequential designs move responsibility toward the learner. | Unchanged for sequential entries: 8 of 9 with a change move toward HD (sign test p = .039); order permutation p = .009. All 40 multi-episode entries: p = .18 (Run 4: .15). SD at 0.5: 11, 9 and 20, with 3 oscillating (unchanged); at 0.34, toward AI rises from 13 to 14 (GT-67). | **Holds** for sequential designs; wider support still weak | Moderate → **Moderate** |
| 5 | Instructor-only episodes form a distinct, assistant-positioned profile. | No instructor episode was patched. Holistic HD 13, AS 8, AD 2; Pos.AS 83%. | **Unchanged from Run 4** (partly reversed relative to October 28) | High / Low → **High / Low** |

**Dependence.**
- The intraclass correlation of HS within multi-episode entries rises from .29 to .32 (design effect 1.46, effective n 67).
- Carryover of the holistic configuration between consecutive episodes strengthens (consecutive agreement .67 against .52 for random pairs, p = .014; Run 4: p = .032), as does engagement (p = .019).
- Removing CM codes that varied within entries makes consecutive episodes more alike.

**Step table (use-case pairs).**
- Sequential pairs are unchanged: 19 steps, mean +0.32, 9 toward HD and 3 toward AD.
- Mixed use-case pairs now include the three new Within-episode episodes: 20 steps, mean +0.02, 7 toward HD and 9 toward AD.

**Interpretive note (amendment, decision 3).** Under the mutual-adaptation criterion (C12, with C1 and C4 read alongside it), designed co-mediation is rare in this corpus. Only three learner episodes remain holistically CM, all from Georgia Tech (GT-09-A3, GT-09-A4, GT-15-A1). In all three, the AI is configured to initiate, challenge or role-play in response to the learner: a co-founder, prospect and co-interviewer; a Socratic challenger; a simulated counterpart that escalates or de-escalates. We report this as a finding about the instructor designs. It also partly reflects the criterion we adopted: designs in which learners converse freely with an AI, but which do not configure the AI to initiate or contest, are coded HD or AS under C12.

## 6. Limitations

1. **Not independent reliability.** All coding, adjudication and patch drafting were done by sessions of AI models under shared rules. Our agreement statistics are consistency tests, not inter-rater reliability between independent human coders.
2. **Small CM base.** Three holistic CM episodes, and nodes such as Steer.CM at exactly the threshold, make any CM-specific reading fragile.
3. **Segmentation** remains frozen as in Run 3.
4. **Scope.** The intended (design) profile only.
5. **Figures and model objects** travel in `run41_run5_drive_bundle.zip` (see the folder README), because the Drive connector cannot transfer binary files reliably.

## References

Bowman, D., Swiecki, Z., Cai, Z., Wang, Y., Eagan, B., Linderoth, J., & Shaffer, D. W. (2021). The mathematical foundations of epistemic network analysis. In A. R. Ruis & S. B. Lee (Eds.), *Advances in quantitative ethnography* (pp. 91–105). Springer. https://doi.org/10.1007/978-3-030-67788-6_7

Liang, K.-Y., & Zeger, S. L. (1986). Longitudinal data analysis using generalized linear models. *Biometrika, 73*(1), 13–22. https://doi.org/10.1093/biomet/73.1.13

Shaffer, D. W., Collier, W., & Ruis, A. R. (2016). A tutorial on epistemic network analysis: Analyzing the structure of connections in cognitive, social, and interaction data. *Journal of Learning Analytics, 3*(3), 9–45. https://doi.org/10.18608/jla.2016.33.3
