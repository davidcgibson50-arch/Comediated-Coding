# AIM-AI Run 5, Stage A: v0.8 resolution of EO intended and ML intended

Prepared October 30, 2026, for David Gibson. Codebook v0.8.3 (R16, R17). Stage B has not been started; it waits for your review of the flagged rulings.

## Files

- `AIM-AI_v08_EO_ML_Adjudication_Log.csv`: 130 rows (65 episodes by 2 fields) in the columns the brief specifies.
- `AIM-AI_v08_ENA_ready_intended_EOML.csv`: the Run 4 input with `EO_designed` and `ML_designed` replaced for the 65 recoded episodes, plus `EO_intended_v08`, `ML_intended_v08` and `EOML_Source`. All other columns are identical to the Run 4 input.

## Procedure

We took the three v0.8 coders' `EO intended` and `ML intended` values from `episodes_GPTv8.csv`, `episodes_CCODEv8.csv` and `claude-incognito-codesv8.xlsx`. Unanimous values stand. Every non-unanimous cell was adjudicated against the source text (`07_GT_sources_for_recode.txt` and the Stanford and Toronto corpus files), with the majority treated as a starting point. We applied R17's exclusion strictly: knowledge of AI capabilities, limitations or prompting does not count as ML. For EO we coded the most extensive designed move, and we kept the coders' working threshold. EO-EV requires a designed check of AI-introduced substantive content against evidence or criteria the AI did not supply, not only a fidelity or correctness check of output. The v0.7.1 values appear in the log for reference only and played no part in the rulings.

## Resolution routes

| Route | EO intended | ML intended | Total |
|---|---|---|---|
| Unanimous | 50 | 45 | 95 |
| Majority upheld | 15 | 14 | 29 |
| Majority overturned | 0 | 2 | 2 |
| Three-way split | 0 | 4 | 4 |
| **Total** | 65 | 65 | 130 |

Ten rulings carry `ReviewFlag = Yes`: two overturned majorities, four three-way splits, and four upheld majorities that turn on a close reading of R17.

## Flagged rulings

| Episode | Field | GPTv8 / CCODEv8 / ClaudeIncog | Resolved | Route | Basis |
|---|---|---|---|---|---|
| GT-22-A2 | ML | FR / DD / FR | **ML-DD** | Majority overturned | The graded training log has teams decide, with reasons, whether each AI response shows a weakness, a gap in the client model or a limit of the simulation. CCODEv8, the minority coder, was the adjudicator's own coding session. |
| TO-Seward-A2 | ML | NA / CW / CW | **ML-NA** | Majority overturned | The designed task is a critique of where the AI ad fails, which is limitations knowledge (R17). "Value of human judgment" is instructor commentary. **Presence changes 1 to 0.** |
| GT-30-A2 | ML | DD / MX / CW | ML-MX | Three-way split | Documenting AI use and what still needed human judgment (CW) plus justifying choices independently of AI (DD). |
| GT-31-A2 | ML | NA / FR / CW | ML-CW | Three-way split | The reflection in every assignment covers the capstone, so the code follows GT-31-A1. |
| ST-29-A1 | ML | NA / CW / DD | ML-CW | Three-way split | The disclosure template separates AI tasks from tasks kept by the author. No justification is required, so not DD. |
| ST-32-A1 | ML | NA / CW / MX | ML-CW | Three-way split | The policy names the work that must stay with the student and plans discussion of AI's effect on learning. The prohibitions are design conditions. |
| GT-28-B1 | ML | FR / NA / NA | ML-NA | Majority upheld (R17) | Understanding how models construct images is technical knowledge. |
| GT-28-C1 | ML | FR / NA / NA | ML-NA | Majority upheld (R17) | Copying versus computational restructuring concerns how the network works. |
| ST-09-A1 | ML | NA / DD / DD | ML-DD | Majority upheld (R17) | Co-created class agreement on when to use AI. The benefits-and-limitations element alone would be excluded. |
| TO-Goldfarb-A2 | ML | EP / NA / NA | ML-NA | Majority upheld (R17) | Red-teaming builds knowledge of model vulnerabilities. |

No EO ruling was flagged. All 15 contested EO cells kept the majority value, including TO-Goldfarb-A2 (EO-EV, not EO-CH: students test the models with false premises rather than contest an assumption the AI introduced).

## Before and after totals

| `EO_designed` / `ML_designed` | All 162 episodes | Learner episodes (139) |
|---|---|---|
| v0.7.1 values (moderated coding form, equal to the Run 3 input) | 73 / 59 | 70 / 55 |
| Run 4 input (`AIM-AI_v08_ENA_ready_intended.csv`) | 69 / 60 | 66 / 57 |
| **After Stage A** | **69 / 59** | **66 / 56** |

**Episodes whose presence code changed from v0.7.1: 9 (8 learner episodes).**
- EO, 1 to 0: GT-09-A2, GT-28-B1, GT-28-C3, GT-61-A1, TO-KhazraRQ-A1.
- EO, 0 to 1: TO-MacKay-A1.
- ML, 0 to 1: GT-09-A3, ST-29-A1.
- ML, 1 to 0: GT-28-B1, TO-Wood-A1 (instructor episode).

GT-28-B1 changed on both. TO-Seward-A2 is unchanged from v0.7.1 (ML-NA in both).

## A discrepancy with the brief, for your decision

The brief states that the Run 4 input's `EO_designed` and `ML_designed` columns were carried over from v0.7.1. For the 65 recoded episodes they were not: they already equal the EO and ML rows of `AIM-AI_v08_Adjudication_Log.csv`, which resolved these same 35 contested cells during the v0.8 resolution. Ten of the 65 episodes therefore already differ from v0.7.1 in the Run 4 input, and Model 1 never used these columns.

We made our rulings independently and compared them with that log afterwards. They agree on 33 of 35 cells, including all four three-way splits. The two disagreements are the overturned majorities above:
- GT-22-A2 ML: we resolved DD against the log's FR. Presence is the same either way.
- TO-Seward-A2 ML: we resolved NA against the log's CW. Presence differs.

As a result, Stage A changes the Run 4 input in only one place, TO-Seward-A2 `ML_designed` (1 to 0). If you prefer the earlier log's rulings, the totals become 69 / 60 (all) and 66 / 57 (learners), and Model 2 is otherwise unaffected.

## Open items relevant to Stage B

- The 97 non-recoded episodes keep v0.7.1 EO and ML codes that were never re-tested under v0.8 (Stage B item 7 tests whether this matters).
- The frequency threshold is met comfortably (66 and 56 learner episodes), so both presence nodes can enter Model 2.
- ML intended has a borderline alpha (.66). The flagged R17 rulings above are where that unreliability concentrates.
- Coders and adjudicator are sessions of AI models, so agreement reflects consistency under shared rules, not independent human reliability.
