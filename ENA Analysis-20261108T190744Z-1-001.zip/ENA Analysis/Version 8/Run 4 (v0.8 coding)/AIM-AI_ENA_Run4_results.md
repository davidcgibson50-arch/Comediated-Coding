# AIM-AI ENA Run 4: v0.8 coding, results and comparison with Run 3

Date: October 29, 2026\. Codebook: AIM-AI v0.8.3 (v0.8.2 plus R30, sequence direction). Profile modelled: **intended (T4)**. Run 4 repeats the Run 3 primary analysis on the v0.8 coding and supersedes Run 3 for the intended profile.

## Files in this set

- **Model input:** `AIM-AI_v08_ENA_ready_intended.csv` (162 episodes, 40 columns, including the Run 3.1 ruling GT-41-A1 Pos.AS \= 1).  
- **ENA output:**  
  - `run4_points.csv`, `run4_mean_line_weights.csv`, `run4_node_positions.csv`, `run4_unit_line_weights.csv`, `run4_set.rds` (model object), `run4_model_output.txt`;  
  - the fixed 16-code comparison model: `run4_fixed16_points.csv`, `run4_fixed16_mean_line_weights.csv`, `run4_fixed16_node_positions.csv`, `run4_fixed16_unit_line_weights.csv`, `run4_fixed16_set.rds`;  
  - `run4_points_by_institution.png`, `run4_points_by_original_pass.png`, `run4_mean_network_{Georgia_Tech,Stanford,Toronto}.png`.  
- **Comparison with Run 3:** `run4_vs_run3_units.csv` (aligned positions, shift and code changes for all 81 units), `run4_vs_run3_nodes.csv`.  
- **Scripts:** `run4.R` (model), `plots4.R` and `passplot4.R` (figures), `compare4.py` (comparison). `run4.R` is `run3.R` with the input file, `OriginalPass` in place of `CodingPass`, the `run4_` prefix and the pilot-against-full Fisher tests changed; `plots4.R` differs from `plots3.R` only in file names and title.

## 1\. What changed since Run 3

- **Coding.** The 65 calibration-exposed episodes (31 entries) were recoded blind under Codebook v0.8 by three coders, and every non-unanimous intended cell was adjudicated against the source text (181 cells). Calibration Rule C12 (majority initiator) was then swept across all 162 episodes. The sweep changed 100 cells in 32 episodes, and 17 holistic codes moved from AS to HD.  
- **Learner episodes (the model data).** 35 learner episodes in 32 entries changed on at least one intended dimension or the holistic code. The changes are dominated by C12: engagement AS to HD (20 episodes), provenance AS to HD (18) and holistic AS to HD (12). The rest come mainly from the v0.8 adjudication: positioning CM to AS (3) and CM to HD (1), interpretation HD to NE (2), HD to AS (1) and HD to CM (1), holistic CM to HD (GT-66-A2), one episode moving from HD to AS on engagement, provenance and the holistic code (GT-58-A1), and the GT-41-A1 positioning ruling (NE to AS).  
- **Code frequencies (learner episodes).** Eng.AS falls from 51 to 32 and Eng.HD rises from 65 to 85; Prov.AS falls from 43 to 27 and Prov.HD rises from 78 to 95\. Pos.AS rises from 62 to 66; Pos.CM falls from 11 to 7\. Interp.CM reaches 3 and enters the model.  
- **Code set.** At the frequency threshold of 3 learner episodes, 17 codes are retained (Run 3: 16). Steer.AD (1), Interp.AD (1) and Pos.AD (2) stay out.  
- **Pass variable.** `CodingPass` now reads `v8 Blind` for the recoded episodes, so all pass comparisons use `OriginalPass` (Pilot or Full), as the brief requires.

**Reproduction check.** Before fitting Run 4 we ran `run3.R` unchanged on the Run 3 input in the same environment. It reproduced `run3_points.csv` exactly (largest absolute difference 0.0000 on both axes), so the differences reported below come from the data, not from the software.

## 2\. ENA settings (unchanged from Run 3\)

- **Software:** rENA 0.3.1 on R 4.3.3.  
- **Data:** learner episodes only (`Learner == 1`): 139 episodes in **81 units** (Georgia Tech 45, Stanford 18, Toronto 18); 28 pilot and 53 full-pass entries by `OriginalPass`.  
- **Units:** Institution \+ EntryID. **Conversation:** Institution \+ ActivityID.  
- **Window:** 1, with window 2 as a sensitivity check. SVD rotation.  
- **Codes:** frequency threshold 3 on the v0.8 data (17 codes: Eng.AD, Eng.AS, Eng.CM, Eng.HD, Steer.AS, Steer.CM, Steer.HD, Prov.AD, Prov.AS, Prov.CM, Prov.HD, Interp.AS, Interp.CM, Interp.HD, Pos.AS, Pos.CM, Pos.HD). Comparison model: the Run 3 fixed 16-code list (the same list without Interp.CM).  
- **Model 1B:** the primary model without TO-BelloWrite-A2 (`NonGenerativeTool == 1`).  
- **Tests:** Kruskal-Wallis across institutions and Mann-Whitney by `OriginalPass` on SV1 and SV2; Fisher tests of pilot against full entries at the episode level.

## 3\. Results (Model 1A)

**Model quality.**

- Variance explained: SV1 31.4%, SV2 12.4%.  
- Goodness of fit (Pearson): SV1 .99, SV2 .98 (Spearman .99 and .98).  
- Window 2 sensitivity: \|r\| \= .991 for SV1 and .943 for SV2.  
- The fixed 16-code model is practically identical (SV1 31.5%, SV2 12.5%, goodness of fit .99 and .98, the same tests), so adding Interp.CM changes little.  
- Model 1B is practically identical: SV1 31.5%, SV2 12.5%, institution p \= .703 and .934, pass p \= .398 and .691.

**Axes, read from node positions.**

- **SV1 still runs from human-led to AI-assisted work.**  
  - Negative pole: Eng.HD (-1.15), Interp.HD (-0.82), with Prov.CM, Eng.CM and Interp.CM further in. The learner works constructively and interprets.  
  - Positive pole: Prov.AS (2.17), Steer.CM (1.41), Eng.AS (1.24), Pos.CM (1.17), Eng.AD (1.04), Pos.AS (0.88). AI-produced material is adapted, and the AI is an assistant or a partner.  
  - One change from Run 3: Prov.HD now sits slightly positive on SV1 (0.22; Run 3 \-0.66). Under C12, designs in which the learner edits or rebuilds AI output are coded Prov.HD, so Prov.HD now also appears in designs with assistant positioning and AI-structured steps; engagement and interpretation carry the human-led pole.  
- **SV2 now separates two kinds of human-steered design.**  
  - Negative pole: Interp.CM (-1.98), Pos.AS (-1.74), Steer.HD (-0.73), with Eng.HD and Interp.HD (-0.33). The learner steers, and the AI is framed as an assistant.  
  - Positive pole: Prov.CM (2.12), Prov.AD (1.96), Pos.HD (1.56), Steer.AS (1.39), Prov.HD (1.13), Interp.AS (1.06). Advisor positioning and AI-structured scaffolds, often with mixed provenance.  
  - In Run 3, SV2 was read as human steering and interpretation against AI-structured scaffolds. The scaffold pole is the same, but Pos.AS has moved from near the origin (-0.17) to the negative pole and Pos.HD from near the origin (0.19) to the positive pole. SV2 is therefore now as much about how the AI is positioned as about who structures the work. Interp.CM rests on 3 episodes, so its extreme position should not be read on its own. We read SV2 cautiously.

**Institutions.**

- The three institutions are not distinguishable: Kruskal-Wallis p \= .691 on SV1 and .973 on SV2.  
- All three mean networks are now anchored on the human-directed codes, with engagement joining steering, production and interpretation:

| Institution | Strongest connections (mean line weight) |
| :---- | :---- |
| Georgia Tech | Eng.HD–Prov.HD .242, Steer.HD–Interp.HD .240, Steer.HD–Prov.HD .235, Prov.HD–Interp.HD .232 |
| Toronto | Prov.HD–Interp.HD .254, Eng.HD–Prov.HD .244, Eng.HD–Interp.HD .222 |
| Stanford | Steer.HD–Prov.HD .295, Eng.HD–Steer.HD .236, Eng.HD–Prov.HD .220, Steer.HD–Pos.AS .182 |

- Stanford keeps its distinctive link between human steering and assistant positioning (Steer.HD–Pos.AS .182, unchanged from Run 3), typical of its course policies. Toronto's network now centres on production and interpretation rather than steering.

**Original coding pass.**

- In ENA space the two passes do not differ: Mann-Whitney p \= .350 on SV1 and p \= .827 on SV2 (Run 3: .785 and .104).  
- At the code level (learner episodes, 61 pilot and 78 full-pass episodes):

| Code | Pilot entries | Full entries | Fisher p | Run 3 |
| :---- | :---- | :---- | :---- | :---- |
| Steer.HD | .70 | .86 | .035 | .70, .86, p \= .035 |
| Interp.HD | .52 | .72 | .022 | .56, .73, p \= .048 |
| Holistic CM | .08 | .01 | .086 | .10, .01, p \= .043 |
| Positioning left NE | .31 | .31 | 1.000 | .31, .31 |

- The steering and interpretation gaps persist; the holistic CM gap falls below significance, because one pilot CM episode (GT-66-A2) became HD in the v0.8 recode. As in Run 3, the original pass coincides with two different sets of entries, so these residual differences cannot be separated from real differences between the samples. That the Interp.HD gap widened slightly after a blind recode of most pilot entries points again to a sample difference rather than to coder drift.

## 4\. Comparison with Run 3

**The two spaces are similar but not interchangeable.** Run 4 unit positions correlate with Run 3 at r \= .70 on SV1 (Spearman .72) and r \= .67 on SV2 (Spearman .75). No sign flip was needed on either axis. Node positions correlate at r \= .77 and .78 over the 16 shared codes. The correlations are lower than between Runs 2 and 3 (.83 and .84) because the C12 sweep changed the dominant pattern of 32 of the 81 entries and the rotation moved with it.

**Which units moved, and why.** Entries with at least one learner-episode code change moved a mean of 0.47 in the aligned plane; entries without a change moved 0.26 (maximum 0.51), only because the rotation itself changed. The largest movements all trace to recorded code changes:

| Unit | Shift | Direction | Source | Learner-episode code changes |
| :---- | :---- | :---- | :---- | :---- |
| TO-Bentley | 0.99 | toward the human-led pole | v0.8 recode and adjudication (C12 rev. b) | A1 Eng and Prov AS→HD; holistic Mixed→HD |
| GT-35, GT-55, TO-ThavConcept | 0.93 each | toward the human-led pole | C12 sweep | A1 Eng and Prov AS→HD; holistic AS→HD |
| ST-29, GT-30 | 0.93 each | toward the human-led pole | v0.8 recode (D1) and C12 sweep (D3) | Eng and Prov AS→HD; holistic AS→HD |
| GT-58 | 0.89 | toward the AI-assisted pole | v0.8 recode (adjudicated majority AS) | A1 Eng and Prov HD→AS; holistic HD→AS |
| GT-41 | 0.87 | toward the human-led pole | C12 sweep and Run 3.1 ruling | A1 and A2 Eng and Prov AS→HD; holistic AS→HD; A1 Pos NE→AS |
| ST-02 | 0.52 | toward the human-led pole | C12 sweep | A1 Eng and Prov AS→HD; holistic AS→HD |
| GT-08 | 0.51 | toward the AI-assisted pole | none (rotation only) | none |
| GT-09 | 0.51 | toward the AI-assisted pole | v0.8 recode (adjudicated majority CM) | A4 Interp HD→CM |
| GT-63 | 0.48 | toward the human-led pole | v0.8 recode and C12 sweep | A1 Eng and Prov AS→HD; Interp NE→HD; holistic AS→HD |

Six entries share an identical Run 4 position (shift 0.93) because their single learner episode now carries the same HD code pattern. GT-58 is the one entry that moved against the general direction: the v0.8 adjudication upheld the majority AS for its GAUF-tagged assignments, where the Run 3 code had been HD. The full list is in `run4_vs_run3_units.csv`.

**Summary of the two runs.**

|  | Run 3 (v0.7.1, moderated) | Run 4 (v0.8 coding) |
| :---- | :---- | :---- |
| Codes | 16 | 17 (Interp.CM enters); fixed 16 gives the same result |
| Variance explained (SV1, SV2) | 32.8%, 12.6% | 31.4%, 12.4% |
| Goodness of fit (SV1, SV2) | .99, .98 | .99, .98 |
| Window 2 | r | (SV1, SV2) |
| SV1 reading | human-led (Eng, Prov, Interp HD) to AI-assisted (Prov.AS, Pos.AS, Eng.AS, Steer.CM) | same; Prov.HD moves near the origin |
| SV2 reading | human steering and interpretation to AI scaffolds and mixed provenance | assistant positioning with human steering to advisor positioning, AI scaffolds and mixed provenance |
| Institutions, Kruskal-Wallis p (SV1, SV2) | .836, .965 | .691, .973 |
| Strongest institutional connection | Steer.HD–Interp.HD in all three | Eng.HD–Prov.HD (Georgia Tech), Prov.HD–Interp.HD (Toronto), Steer.HD–Prov.HD (Stanford) |
| Original pass, Mann-Whitney p (SV1, SV2) | .785, .104 | .350, .827 |
| Pilot against full (Fisher p): Steer.HD, Interp.HD, holistic CM | .035, .048, .043 | .035, .022, .086 |
| Unit positions, Run 4 against Run 3 |  | r \= .70 (SV1), .67 (SV2) |

## 5\. Interpretation (with caveats)

- **The headline structure holds.** SV1 still separates human-led designs from AI-assisted production, institutions remain indistinguishable, and the pass effect in ENA space stays absent.  
- **The human-directed pattern is now broader.** With C12, designs in which the learner reshapes AI output against the learner's own aims or an outside standard count as human-produced and human-engaged. *The mean networks are therefore anchored on a four-code human-directed core (engagement, steering, production, interpretation) rather than on steering and interpretation alone.*  
- **Positioning matters more in the second dimension.** Assistant positioning combined with human steering now forms its own pole on SV2, opposite advisor positioning and AI scaffolds. This is the pattern of a learner who directs the work while the AI is framed as a helper.  
- **Co-mediated designs remain rare** (6 learner episodes with holistic CM, against 7 in Run 3), and Interp.CM rests on 3 episodes. The CM codes still contribute little to the structure.

## 6\. Limitations and open items

1. **Not independent reliability.** The v0.8 coders were sessions of AI models (two of the Claude family and one GPT), so agreement reflects consistency under shared rules rather than independent human reliability. The two Claude-family coders agreed more closely with each other than either did with the GPT coder, which is why every non-unanimous intended cell was adjudicated against the source text.  
2. **Open CM questions.** CM codes that rest on C1's interlocutor clause (D1 and D2 in ST-28-A2 and TO-BelloConv-A1; D1 and D5 in ST-10-A2) have not been re-tested against the mutual-adaptation criterion. If they changed, Eng.CM, Steer.CM and Pos.CM would weaken further and Interp.CM could fall below the threshold, which would return the model to the 16-code list (shown above to give the same result).  
3. **Trajectory use cases.** Eight episodes have Start different from End but a use case other than Within-episode (GT-32-A2, GT-44-A2, GT-67-A1, ST-02-A2, ST-10-A2, ST-21-A1, ST-38-A1, TO-SmithMyth-A1). The use case does not enter the ENA model, but it does enter the sequence analyses in the cluster report.  
4. **Episode segmentation remains frozen** as in Run 3 (its limitation 3).  
5. **Scope.** This is the intended (design) profile only. It describes how instructors framed activities (R29), not what learners did. Reported-profile and extension codes for the 65 recoded episodes remain unresolved.

## References

Bowman, D., Swiecki, Z., Cai, Z., Wang, Y., Eagan, B., Linderoth, J., & Shaffer, D. W. (2021). The mathematical foundations of epistemic network analysis. In A. R. Ruis & S. B. Lee (Eds.), *Advances in quantitative ethnography* (pp. 91–105). Springer. [https\://doi.org/10.1007/978-3-030-67788-6\_7](https://doi.org/10.1007/978-3-030-67788-6_7)

Shaffer, D. W., Collier, W., & Ruis, A. R. (2016). A tutorial on epistemic network analysis: Analyzing the structure of connections in cognitive, social, and interaction data. *Journal of Learning Analytics, 3*(3), 9–45. [https\://doi.org/10.18608/jla.2016.33.3](https://doi.org/10.18608/jla.2016.33.3)