"""Run 4 against Run 3: unit-position correlations (allowing an SVD sign flip), the units that moved
most with their code changes from the v0.7.2 (Run 3) file, the C12 sweep log and the adjudication log,
and node positions side by side. Usage: python compare4.py <out_dir> <drive_dir> <run3_repro_dir>"""
import sys, os, numpy as np, pandas as pd
out, drv, r3 = sys.argv[1:4]
p4 = pd.read_csv(os.path.join(out, "run4_points.csv")); p3 = pd.read_csv(os.path.join(drv, "run3_points.csv"))
m = p4.merge(p3, on="Unit", suffixes=("_r4", "_r3"))
assert len(m) == 81
sign = {}
for k in ("SV1", "SV2"):
    r = np.corrcoef(m[k + "_r4"], m[k + "_r3"])[0, 1]; sign[k] = np.sign(r)
    rs = pd.Series(m[k + "_r4"]).corr(pd.Series(m[k + "_r3"]), method="spearman")
    print(f"{k}: Pearson r = {r:.3f}, Spearman rho = {rs:.3f}")
for k in ("SV1", "SV2"):
    m[k + "_r3a"] = m[k + "_r3"] * sign[k]
    m["d" + k] = m[k + "_r4"] - m[k + "_r3a"]
m["Shift"] = np.hypot(m.dSV1, m.dSV2)
m["EntryID"] = m.Unit.str.split("::").str[1]

# code changes by entry: compare the 20 dimension codes and holistic in learner episodes
a = pd.read_csv(os.path.join(drv, "AIM-AI_v072_moderated_ENA_ready_intended.csv"))
b = pd.read_csv(os.path.join(drv, "AIM-AI_v08_ENA_ready_intended.csv"))
dims = ["Eng", "Steer", "Prov", "Interp", "Pos"]
def cfg(row, d):
    s = [k for k in ("AD", "AS", "CM", "HD") if row[f"{d}.{k}"] == 1]
    return s[0] if s else "NE"
ch = []
for _, rb in b[b.Learner == 1].iterrows():
    ra = a[a.EpisodeID == rb.EpisodeID].iloc[0]
    for d in dims:
        if cfg(ra, d) != cfg(rb, d): ch.append((rb.EntryID, rb.EpisodeID, d, cfg(ra, d), cfg(rb, d)))
    if ra.HolisticIntended != rb.HolisticIntended: ch.append((rb.EntryID, rb.EpisodeID, "Holistic", ra.HolisticIntended, rb.HolisticIntended))
ch = pd.DataFrame(ch, columns=["EntryID", "EpisodeID", "Field", "Run3", "Run4"])
sw = pd.read_csv(os.path.join(drv, "AIM-AI_v08_C12_Sweep_Log.csv"))
adj = pd.read_csv(os.path.join(drv, "AIM-AI_v08_Adjudication_Log.csv"))
pas = b.groupby("EntryID").CodingPass.first()
def src(e):
    eps = ch[ch.EntryID == e].EpisodeID.unique()
    s = []
    if any(x in set(sw.EpisodeID) for x in eps): s.append("C12 sweep")
    if pas.get(e) == "v8 Blind": s.append("v0.8 blind recode")
    if e == "GT-41": s.append("Run 3.1 ruling (Pos.AS)")
    return "; ".join(s)
summ = ch.groupby("EntryID").apply(lambda g: "; ".join(f"{r.EpisodeID} {r.Field} {r.Run3}->{r.Run4}" for r in g.itertuples())).rename("CodeChanges")
m = m.merge(summ, left_on="EntryID", right_index=True, how="left")
m["CodeChanges"] = m.CodeChanges.fillna("none")
m["Source"] = m.EntryID.map(src)
m["CodingPassV8"] = m.EntryID.map(pas)
cols = ["Unit", "Institution_r4", "OriginalPass", "CodingPassV8", "SV1_r3a", "SV2_r3a", "SV1_r4", "SV2_r4", "dSV1", "dSV2", "Shift", "Source", "CodeChanges"]
res = m[cols].rename(columns={"Institution_r4": "Institution", "SV1_r3a": "SV1_run3_aligned", "SV2_r3a": "SV2_run3_aligned", "SV1_r4": "SV1_run4", "SV2_r4": "SV2_run4"}).sort_values("Shift", ascending=False)
res.round(4).to_csv(os.path.join(out, "run4_vs_run3_units.csv"), index=False)
changed = set(ch.EntryID)
print(f"\nEntries with any learner-episode code change: {len(changed)} of 81; their mean shift {m[m.EntryID.isin(changed)].Shift.mean():.3f}, "
      f"unchanged entries' mean shift {m[~m.EntryID.isin(changed)].Shift.mean():.3f} (max {m[~m.EntryID.isin(changed)].Shift.max():.3f})")
print("\nTop 12 movers:"); print(res.head(12)[["Unit", "Shift", "dSV1", "dSV2", "Source", "CodeChanges"]].to_string(index=False))
print("\nLearner-episode code changes by field:"); print(ch.groupby(["Field", "Run3", "Run4"]).size().to_string())

# node positions
n4 = pd.read_csv(os.path.join(out, "run4_node_positions.csv")); n3 = pd.read_csv(os.path.join(r3, "run3_node_positions.csv"))
n = n4.merge(n3, on="code", how="outer", suffixes=("_run4", "_run3"))
for k in ("SV1", "SV2"): n[k + "_run3"] = n[k + "_run3"] * sign[k]
n.round(3).to_csv(os.path.join(out, "run4_vs_run3_nodes.csv"), index=False)
print(f"\nSigns applied to Run 3 for alignment: SV1 {sign['SV1']:+.0f}, SV2 {sign['SV2']:+.0f}"); print(n.round(2).sort_values("SV1_run4").to_string(index=False))
nn = n.dropna(); print("node r SV1 %.3f SV2 %.3f" % (np.corrcoef(nn.SV1_run4, nn.SV1_run3)[0, 1], np.corrcoef(nn.SV2_run4, nn.SV2_run3)[0, 1]))
