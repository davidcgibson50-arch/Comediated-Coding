# AIM-AI Run 4 episode clusters: summary report

October 29, 2026 · David Gibson

We repeated the October 28 cluster, sequence and dependence analyses in the Run 4 ENA space, which is built on the v0.8 coding (blind recode of 65 episodes plus the C12 majority-initiator sweep across all 162). As before, we grouped the 81 entries by their number of learner episodes (1, 2, or 3 and more) and asked whether longer, multi-episode designs carry a different mediation structure. The clearest October 28 result survives: sequential designs still hand cognitive responsibility back to the learner from stage to stage. The rest hold, weaken or partly reverse, as summarised below.

## Findings at a glance

Confidence uses the October 28 scale: our judgment of how likely the pattern is to hold in a larger sample of the same kind of faculty reports, weighing effect size, survival of the dependence and depth checks, the number of entries that carry it, and how consistently the relevant codes were applied.

| \# | October 28 finding | Run 4 evidence | Verdict | Confidence (Oct 28 → Run 4\) |
| :---- | :---- | :---- | :---- | :---- |
| 1 | Episode count does not move entries in ENA space. | 3+ vs 1 episode, controlling for institution, word count and topics: SV1 b \= \-0.13, p \= .40; SV2 b \= \-0.03, p \= .77. | **Holds** | Moderate → **Moderate** |
| 2 | Longer accounts tighten a human-constructive triad (Eng.HD, Prov.HD, Interp.HD). | Triad \+0.35 for 3+ entries (p \= .024); \+0.31 (p \= .056) with institution; \+0.34 (p \= .053) with institution and depth. | **Holds** (no longer eroded by depth, but still borderline) | Low → **Low** |
| 3 | Co-mediation and unstated positioning concentrate in the 3+ cluster. | Positioning NE 45% vs 24%, GEE odds ratio 2.85 after controls (p \= .040), entry permutation p \= .06. Holistic CM 9% vs 2%, Fisher p \= .080. Pos.HD 7% vs 19%, p \= .053 to .12. New: Prov.AS 9% vs 24%, GEE p \= .016 after controls, permutation p \= .07 to .09. | **Holds for NE; weakens for CM, Eng.AS and Pos.HD**; a new, similar-strength difference in AI-structured production | NE: Low → **Low**; CM: Very low → **Very low**; Pos.HD: Low → **Very low**; Prov.AS: **Low** (new) |
| 4 | Sequential designs move responsibility toward the learner from stage to stage. | 8 of 9 sequential entries with a change move toward HD (sign test p \= .039); within-entry order permutation p \= .009. Across all 40 multi-episode entries p \= .15 (Oct 28: .022). | **Holds** for sequential designs; **the wider multi-episode support weakens** | Moderate → **Moderate** |
| 5 | Instructor-only episodes form a distinct, assistant-positioned profile. | 23 episodes in 20 entries: Pos.AS 83%, Steer.HD 87%; but Eng.HD and Prov.HD 57% and holistic HD 13 of 23 (Oct 28: AS 14 of 23). | **Partly reverses**: the assistant positioning holds; AI-structured production does not | High (description) / Low (generalization) → **High / Low** |

Levels: **High**, the pattern is large, survives every check, and rests on many entries; **Moderate**, it survives the checks that bear on it but rests on few entries or design statements only; **Low**, it weakens below conventional thresholds under at least one check or depends on a handful of entries; **Very low**, a handful of cases with no robust test.

## Data and analytic decisions

The analysis uses the v0.8 intended codes (`AIM-AI_v08_ENA_ready_intended.csv`, including the Run 3.1 ruling GT-41-A1 Pos.AS) and the Run 4 ENA model (rENA 0.3.1, 17 codes, SVD): 139 learner episodes in 81 entries (Georgia Tech 45, Stanford 18, Toronto 18). All positions and networks sit in the Run 4 rotation.

- **Clusters count learner episodes.** 41 entries have one learner episode, 27 have two and 13 have three or more (the 3+ cluster: ten Georgia Tech entries, two Toronto, one Stanford). Membership is unchanged from Run 3, because segmentation is frozen. GT-09 has four learner episodes and GT-24 and GT-28 five; they are labelled in the figure.  
- **Trajectory use case stays at the episode level.** Across the 139 learner episodes there are 54 recurrent, 43 single-use, 41 sequential and 1 within-episode code (Run 3: 50, 35, 44 and 10). The adjudication moved 16 learner episodes between use cases, mostly from Within-episode to Single use or Recurrent under C10, and GT-66 from Sequential to Recurrent. 17 entries mix use cases. Sequential episodes still sit almost entirely in multi-episode entries (40 of 41).  
- **Instructor-only episodes** (23 episodes in 20 entries, eight of them instructor-only entries) are outside the ENA model and reported separately.  
- **Reporting depth.** We used the recomputed depth table (`AIM-AI_v08_depth_by_entry.csv`; same method as October 28, with the October 27 re-retrievals of the Stanford and Toronto pages). Entries in the 3+ cluster are longer (median 1,485 words against 785 for single-episode entries; Kruskal-Wallis across the three clusters p \= .016) but not broader in topics (median 6.5 against 5.4; p \= .17).  
- **Dependence.** Episode-level tests are reported as on October 28: Fisher tests that treat episodes as independent, GEE with an exchangeable working correlation clustered by entry (Liang & Zeger, 1986), and permutation of the 3+ label across whole entries within institution or within word-count tertiles (5,000 permutations, seed 20261029). OLS models use HC3 robust errors (Long & Ervin, 2000).  
- **Validation of the scripts.** We first ran the same script on the Run 3 inputs. It reproduced the October 28 figures that do not depend on depth: exactly for the cluster sizes, the triad (+0.39, p \= .015; \+0.36, p \= .033), the Fisher and GEE code-level tests, the sign test, the step table, Interp.HD on first episodes, the SD counts, the instructor panel and the ICC; within .007 for the Monte Carlo permutation p-values and carryover baselines. The depth-controlled results differ slightly, as expected from the recomputed depth table. The October 28 sequence analysis ordered episodes within an entry by `EpisodeOrder`, whereas the v0.8 R30 columns use `EpisodeID` order. The two orders differ only for GT-24. We use the file's order as primary and report the October 28 order as a sensitivity check.

## Finding 1: episode count still does not move entries in ENA space

The clusters overlap on both axes. Mean positions are (-0.01, 0.03) for single-episode entries, (0.06, \-0.05) for two-episode entries and (-0.11, 0.02) for the 3+ cluster (Kruskal-Wallis SV1 p \= .63, SV2 p \= .47). The 3+ cluster still leans toward the human-led pole of SV1, but no longer toward the AI-structured pole of SV2. With institution, word count and topic breadth in an OLS model, the 3+ coefficient is small (SV1 b \= \-0.13, p \= .40; SV2 b \= \-0.03, p \= .77). Neither depth measure is a significant predictor (topic breadth on SV1, p \= .07). Within Georgia Tech alone the clusters do not differ (p \= .92 and .97).

**Confidence: Moderate (unchanged).** The null is consistent across every specification and, because ENA units are entries, it is unaffected by episode dependence. With 13 entries in the 3+ cluster only a large difference would be detectable.

## Finding 2: longer accounts still tighten the human-constructive triad

In the 3+ cluster the strongest mean connections again join human-directed engagement, production and interpretation, and they are stronger than in Run 3: Eng.HD–Prov.HD .333, Eng.HD–Interp.HD .292, Prov.HD–Interp.HD .292 (October 28: .264, .261, .275). Single-episode entries remain anchored on steering (Steer.HD–Prov.HD .254, Steer.HD–Interp.HD .231). Summed per entry, the triad is 0.35 higher in the 3+ cluster than in single-episode entries (p \= .024), 0.31 higher with institution controlled (p \= .056), and 0.34 higher with institution, word count and topic breadth controlled (p \= .053). The steering connections (Eng.HD–Steer.HD, Steer.HD–Prov.HD, Steer.HD–Interp.HD) do not differ in any model (all p \> .90).

Two things changed. The triad is stronger in every cluster (means 0.57, 0.64 and 0.92 against 0.41, 0.52 and 0.80 in Run 3), because C12 recoded engagement and provenance from AS to HD in many single-episode designs. And depth no longer erodes the 3+ difference: on October 28 it fell by about a fifth with depth controls, whereas here it is essentially unchanged. The effect is still at the edge of conventional significance once institution is controlled.

**Confidence: Low (unchanged).** Consistent in direction and size, **but p \= .05** *\[acceptable in educational research\]*  to .06 with controls and resting on 13 entries, ten from Georgia Tech.

## Finding 3: unstated positioning still concentrates in the longest accounts; co-mediation does not

The four October 28 code-level differences, plus one new difference that reaches p \< .05 (Prov.AS), under the four tests (learner episodes: 44 in the 3+ cluster, 95 in other entries):

| Code (learner episodes) | 3+ cluster | Other entries | Fisher p | GEE p | GEE p, depth and institution controlled | Entry permutation p (institution; word count) | October 28 (Fisher; permutation) |
| :---- | :---- | :---- | :---- | :---- | :---- | :---- | :---- |
| Positioning left NE | 45% | 24% | .017 | .027 | .040 (odds ratio 2.85) | .061; .064 | 45% vs 25% (.020; .073) |
| Holistic CM | 9% | 2% | .080 | .098 | .206 (odds ratio 4.36) | .113; .180 | 11% vs 2% (.033; .074) |
| Engagement AS | 14% | 27% | .086 | .114 | .073 (odds ratio 0.31) | .204; .191 | 23% vs 43% (.024; .115) |
| Positioning HD | 7% | 19% | .077 | .055 | .053 (odds ratio 0.27) | .122; .114 | 5% vs 19% (.035; .053) |
| Provenance AS (new) | 9% | 24% | .040 | .024 | .016 (odds ratio 0.22) | .090; .069 | not reported |

- **Unstated positioning holds.** The rate, the GEE results with depth and institution controlled and the borderline entry-level permutation are all close to October 28\. Depth still does not explain it. Our reading stands: multi-episode designs frame the AI once for the whole sequence and leave it unstated in later stages.  
- **Co-mediation weakens.** Holistic CM in the 3+ cluster now rests on four episodes in three entries (GT-09 twice, GT-67, ST-28); GT-66-A2 became HD in the v0.8 recode. No test reaches .05. ST-28-A2 is one of the open CM items (C1 interlocutor clause), so the count could fall further.  
- **AI-structured engagement weakens.** C12 moved AS engagement to HD across the sample, which halved Eng.AS in other entries (43% to 27%) and removed most of the contrast.  
- **Human positioning weakens.** The 3+ cluster gained one Pos.HD episode (2 to 3), and the difference falls to p \= .05 to .12. In October 28 this was the most robust of the four; it no longer is.  
- **AI-structured production is newly lower in the 3+ cluster.** Prov.AS is 9% against 24%, robust to GEE with controls but not to entry-level permutation (p \= .07 to .09). It is the production-side counterpart of the old Eng.AS result. C12 moved provenance to HD more often in short designs than long ones, and the long designs had less AS production to begin with.

**Confidence: Low for unstated positioning (unchanged) and for lower AI-structured production (new); Very low for co-mediation, AI-structured engagement and human positioning.** Positioning remained the least consistent dimension in Run 3, although v0.8 agreement on intended positioning was higher (Krippendorff's alpha .84).

## Finding 4: sequential designs still move responsibility toward the learner

Within multi-episode entries we scored each learner episode on the human-direction scale (HS: AD \= 0, AS \= 1, CM \= 2, HD \= 3, averaged over the coded dimensions) and took the step from one learner episode to the next, as recorded in the file's R30 columns:

| Step (use case of the two episodes) | Steps | Entries | Mean change | Toward HD | Toward AD | Unchanged | October 28 (steps; mean; HD/AD) |
| :---- | :---- | :---- | :---- | :---- | :---- | :---- | :---- |
| Sequential to sequential | 19 | 14 | \+0.32 | 9 | 3 | 7 | 20; \+0.31; 11/4 |
| Mixed use cases | 18 | 17 | \+0.07 | 7 | 7 | 4 | 23; \+0.32; 13/8 |
| Single use to single use | 8 | 7 | \-0.05 | 2 | 3 | 3 | 7; \-0.06; 3/2 |
| Recurrent to recurrent | 13 | 9 | \-0.08 | 5 | 6 | 2 | 8; \-0.28; 1/6 |

The tests that use the entry as the unit point the same way as on October 28:

- **Sign test.** Of the 15 entries with two or more sequential learner episodes (Run 3: 16; GT-66 left the set when its episodes became Recurrent), 8 move toward HD from the first sequential stage to the last, 1 moves toward AD and 6 are unchanged (p \= .039).  
- **Order permutation.** Shuffling the order of sequential episodes within each entry produces a mean step as large as the observed \+0.30 in 0.9% of 5,000 permutations (p \= .009; October 28: \+0.28, p \= .012).  
- **Sequential pairs alone.** The step-by-step Wilcoxon test is p \= .107 (October 28: .093).  
- **Clearest cases.** The cases that open with an AI-structured stage and close with a human-directed one are GT-37 (+1.75), TO-SmithMon (+1.5), TO-BelloWrite (+0.8) and TO-KhazraLR (+0.8). TO-MacKay now changes by \+0.4, because C12 made parts of its first stage human-directed. The one entry moving toward AD is ST-10 (-0.4), and its second episode is one of the eight open trajectory items.

The supporting evidence beyond sequential designs is weaker than on October 28:

- **All multi-episode entries.** Across all 40 multi-episode entries the same permutation gives p \= .15 (October 28: .022). Mixed-use and recurrent steps are now near zero: C12 raised the human-direction score of many first episodes that had been AI-structured, so fewer designs start further from the learner.  
- **First and last episodes.** The first learner episode of a multi-episode entry is still less often human-led in interpretation than a single-episode design (.52 against .71), but the difference is no longer significant (p \= .11; October 28: .52 against .76, p \= .038). The last episode again looks like a single-episode design (mean HS 2.38 against 2.44). One new contrast: **first episodes more often have AI-dominant provenance** (Prov.AD 20% against 2%, p \= .015).  
- **Recurrent drift.** Recurrent arrangements no longer drift toward AI direction (13 steps, \-0.08, 5 against 6).

With the October 28 episode order (sensitivity), the sign test and the sequential permutation are identical (p \= .039 and .009), and the all-entries permutation is p \= .087.

**Sequence-direction counts (R30).** We confirm the `r30.py` counts for the 40 multi-episode entries: 11 toward human direction, 9 toward AI direction and 20 stable at the 0.5 threshold, with 3 oscillating (Run 3: 14, 8, 18 and 3). At other thresholds: 17, 13 and 10 at 0.34; 10, 5 and 25 at 0.75; 8, 5 and 27 at 1.0.

**Confidence: Moderate (unchanged).** The core result holds under the sign test and the order permutation, so it is not an artefact of dependence or of the HD ceiling. It rests on 15 entries and on design statements (T4), and the wider support from all multi-episode entries and from first episodes has weakened.

## Finding 5: instructor-only episodes keep the assistant positioning but now produce under human control

The 23 instructor episodes (in 20 entries; 20 instructors, 2 research teams, 1 other) still differ from learner episodes in positioning: the AI is an assistant (Pos.AS 83%, never HD) and the instructor steers (Steer.HD 87%). But engagement and production are now mostly human-directed (Eng.HD and Prov.HD 57%, Eng.AS 35%, Prov.AS 30%), against 61% AI-structured on October 28\. Interpretation stays largely with the instructor (Interp.HD 52%, 35% left NE). Holistically, 13 of the 23 episodes are HD, 8 AS and 2 AD (October 28: 14 AS, 5 HD, 3 AD, 1 NE).

The change comes almost entirely from the C12 sweep: seven staff episodes (GT-01-B1, GT-02-B1, GT-04-A1, GT-10-A1, GT-11-B1, GT-15-B1, GT-18-B1; GT-11-B1 is a research team) and TO-Wood-A1 moved from AS to HD because the instructor edits, curates or validates the AI's output against their own aims. GT-06-B1 (AD to AS) and TO-BelloConv-B1 (NE to AS) moved the other way in the v0.8 recode.

The description therefore shifts from "AI as a production assistant under human control" to **an assistant-positioned AI whose output the instructor reshapes**. The positioning contrast with learner designs holds; the contrast in who produces the work largely disappears.

**Confidence: High as a description of these 23 episodes; Low as a generalization (unchanged).** Instructor use was coded only where an entry happened to report it.

## Dependence between episodes in one entry

- **Clustering.** The intraclass correlation of the human-direction score within multi-episode entries is .29 (October 28: .27). With 2.45 learner episodes per entry, the design effect is about 1.4, so the 98 episodes in multi-episode entries carry roughly the information of 69 independent ones.  
- **Carryover.** Consecutive episodes share the same holistic configuration 62% of the time, against 49% for random pairs from different entries (p \= .032; October 28: 59% against 44%, p \= .006). **Carryover in engagement is now significant** (55% against 43%, p \= .041; October 28: p \= .057). Steering, provenance, interpretation and positioning show no detectable carryover. The baseline rose because C12 made HD more common everywhere, which makes any two episodes more alike.

The four October 28 rules for handling dependence apply unchanged: entry as the unit of inference, effective sample size alongside episode counts, order effects tested by within-entry permutation, and carryover treated as data.

## Open items and where they could matter

1. **CM codes resting on C1's interlocutor clause** (D1 and D2 in ST-28-A2 and TO-BelloConv-A1; D1 and D5 in ST-10-A2) have not been re-tested against the mutual-adaptation criterion. ST-28-A2 carries one of the four holistic CM episodes in the 3+ cluster, so Finding 3's CM result could weaken further. ST-28 and ST-10 are also in the sign test (both unchanged or toward AD).  
2. **Eight episodes have Start different from End** but a use case other than Within-episode (GT-32-A2, GT-44-A2, GT-67-A1, ST-02-A2, ST-10-A2, ST-21-A1, ST-38-A1, TO-SmithMyth-A1). Their use cases enter the step table as coded. ST-10-A2 (Sequential) gives the only sequential entry that moves toward AD, and TO-SmithMyth-A1 (Sequential) contributes \+0.4. ST-38-A1 (Recurrent) and GT-32-A2, GT-44-A2 and ST-02-A2 (Single use) enter mixed-use or single-use steps. Recoding any of them as Within-episode would remove ST-10 and TO-SmithMyth from the sign test, leaving 7 of 7 nonzero changes toward HD among 13 entries.  
3. **Episode segmentation remains frozen**, as in Run 3 (its limitation 3).  
4. **Coders were sessions of AI models**, so **agreement reflects consistency under shared rules rather than independent human reliability.**

## Limitations

1. All codes describe the intended (design) profile; they show how instructors framed activities, not what learners did.  
2. Topic breadth is a model-based proxy for the complexity of ideas, recomputed for this run on re-retrieved Stanford and Toronto pages; multi-episode entries are concentrated at Georgia Tech, whose articles are about twice as long as the Toronto and Stanford pages.  
3. The ENA results use the Run 4 model (Shaffer et al., 2016), whose rotation differs from Run 3 (unit positions correlate .70 and .67), so positions are compared within this run only.  
4. Permutation p-values are Monte Carlo estimates (5,000 draws); reproduced on the Run 3 inputs they differed from the October 28 values by up to .004 for the sequential permutation.

## Files

`run4_cluster_entries.csv` (entry positions, clusters, depth, triad and steering sums), `run4_cluster_mean_line_weights.csv`, `run4_code_level_tests.csv` (all 25 codes, Fisher, with GEE and permutation tests for the selected codes), `run4_step_table.csv`, `run4_sequence_steps.csv`, `run4_instructor_panel.csv`, `run4_results.json` (every number in this report), `run4_sens_episodeorder_*` (October 28 ordering), and the figures `run4_cluster_positions.png`, `run4_mean_networks_by_cluster.png`, `run4_heatmap_sequence_position.png`, `run4_heatmap_dimension_by_cluster.png`. Script: `cluster4.py`.

## References

Blei, D. M., Ng, A. Y., & Jordan, M. I. (2003). Latent Dirichlet allocation. *Journal of Machine Learning Research, 3*, 993–1022. [https\://www\.jmlr.org/papers/v3/blei03a.html](https://www.jmlr.org/papers/v3/blei03a.html)

Good, P. (2005). *Permutation, parametric, and bootstrap tests of hypotheses* (3rd ed.). Springer. [https\://doi.org/10.1007/b138696](https://doi.org/10.1007/b138696)

Joyner, D. A., & Roy, N. (Eds.). (2026). *Georgia Tech academic AI playbook* (2026 ed.). Georgia Institute of Technology. [https\://hdl.handle.net/1853/81982](https://hdl.handle.net/1853/81982)

Liang, K.-Y., & Zeger, S. L. (1986). Longitudinal data analysis using generalized linear models. *Biometrika, 73*(1), 13–22. [https\://doi.org/10.1093/biomet/73.1.13](https://doi.org/10.1093/biomet/73.1.13)

Long, J. S., & Ervin, L. H. (2000). Using heteroscedasticity consistent standard errors in the linear regression model. *The American Statistician, 54*(3), 217–224. [https\://doi.org/10.1080/00031305.2000.10474549](https://doi.org/10.1080/00031305.2000.10474549)

Shaffer, D. W., Collier, W., & Ruis, A. R. (2016). A tutorial on epistemic network analysis: Analyzing the structure of connections in cognitive, social, and interaction data. *Journal of Learning Analytics, 3*(3), 9–45. [https\://doi.org/10.18608/jla.2016.33.3](https://doi.org/10.18608/jla.2016.33.3)