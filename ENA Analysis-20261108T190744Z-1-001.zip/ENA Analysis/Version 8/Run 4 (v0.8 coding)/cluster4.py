"""Cluster, sequence-direction and dependence analyses in an ENA space (repeat of the October 28 report).

Usage: python cluster4.py <ena_ready.csv> <points.csv> <unit_line_weights.csv> <node_positions.csv>
                          <depth_by_entry.csv> <out_prefix> [--figures] [--episode-order]
Writes <out_prefix>_*.csv, <out_prefix>_results.json and, with --figures, <out_prefix>_*.png.
Episodes are ordered within an entry by EpisodeID (as in the R30 columns of the v0.8 file);
--episode-order sorts by EpisodeOrder then EpisodeID, as in the October 28 analysis.
Seeded (20261029) so permutation p-values are reproducible.
"""
import sys, json, itertools, warnings
import numpy as np, pandas as pd
import scipy.stats as st
import statsmodels.formula.api as smf
import statsmodels.api as sm
from statsmodels.genmod.cov_struct import Exchangeable

warnings.filterwarnings("ignore")
src, pts_f, lw_f, nodes_f, depth_f, pre = sys.argv[1:7]
FIG = "--figures" in sys.argv
ORDER = ["EntryID", "EpisodeOrder", "EpisodeID"] if "--episode-order" in sys.argv else ["EntryID", "EpisodeID"]
NPERM = 5000
rng = np.random.default_rng(20261029)
DIMS = ["Eng", "Steer", "Prov", "Interp", "Pos"]
CFG = ["AD", "AS", "CM", "HD"]
VAL = {"AD": 0, "AS": 1, "CM": 2, "HD": 3}
R = {}

E = pd.read_csv(src)
if "OriginalPass" not in E:  # Run 3 file: CodingPass holds Pilot or Full
    E["OriginalPass"] = E["CodingPass"]
for d in DIMS:
    E[d] = E.apply(lambda r: next((k for k in CFG if r[f"{d}.{k}"] == 1), "NE"), axis=1)
    E[f"{d}.NE"] = (E[d] == "NE").astype(int)
E = E.sort_values(ORDER).reset_index(drop=True)
R["order"] = ORDER
L = E[E.Learner == 1].copy()
L["pos"] = L.groupby("EntryID").cumcount() + 1
L["nep"] = L.groupby("EntryID").EpisodeID.transform("size")
L["cluster"] = np.where(L.nep >= 3, "3+", L.nep.astype(str))
L["in3"] = (L.cluster == "3+").astype(int)
L["HSv"] = L.HS.astype(float)

# ---------- entry table ----------
P = pd.read_csv(pts_f); P["EntryID"] = P.Unit.str.split("::").str[1]
D = pd.read_csv(depth_f)
ent = (L.groupby("EntryID").agg(Institution=("Institution", "first"), n=("EpisodeID", "size"))
       .reset_index().merge(P[["EntryID", "SV1", "SV2"]], on="EntryID").merge(D[["EntryID", "WordCount", "TopicBreadth20"]], on="EntryID", how="left"))
ent["cluster"] = np.where(ent.n >= 3, "3+", ent.n.astype(str))
ent["WC1000"] = ent.WordCount / 1000
assert len(ent) == len(P) and ent.WordCount.notna().all()
R["clusters"] = ent.cluster.value_counts().to_dict()
R["clusters_3plus_by_inst"] = ent[ent.cluster == "3+"].Institution.value_counts().to_dict()
R["use_cases"] = L.TrajectoryUseCase.value_counts().to_dict()
R["sequential_in_multi"] = int(((L.TrajectoryUseCase == "Sequential") & (L.nep > 1)).sum())
R["entries_mixing_use_cases"] = int((L.groupby("EntryID").TrajectoryUseCase.nunique() > 1).sum())

def ols(formula, df, term):
    f = smf.ols(formula, df).fit(cov_type="HC3")
    return float(f.params[term]), float(f.pvalues[term]), f

# ---------- 1. clusters in ENA space ----------
c1 = {}
for k in ("SV1", "SV2"):
    c1[f"KW_{k}_p"] = float(st.kruskal(*[g[k] for _, g in ent.groupby("cluster")]).pvalue)
    b, p, f = ols(f"{k} ~ C(cluster, Treatment('1')) + C(Institution) + WC1000 + TopicBreadth20", ent, "C(cluster, Treatment('1'))[T.3+]")
    c1[f"OLS_{k}_b3"] = b; c1[f"OLS_{k}_p3"] = p
    c1[f"OLS_{k}_p_words"] = float(f.pvalues["WC1000"]); c1[f"OLS_{k}_p_topics"] = float(f.pvalues["TopicBreadth20"])
    gt = ent[ent.Institution == "Georgia Tech"]
    c1[f"GT_KW_{k}_p"] = float(st.kruskal(*[g[k] for _, g in gt.groupby("cluster")]).pvalue)
c1["means"] = ent.groupby("cluster")[["SV1", "SV2"]].mean().round(3).to_dict("index")
c1["median_words"] = ent.groupby("cluster").WordCount.median().to_dict()
c1["median_topics"] = ent.groupby("cluster").TopicBreadth20.median().round(2).to_dict()
c1["KW_words_p"] = float(st.kruskal(*[g.WordCount for _, g in ent.groupby("cluster")]).pvalue)
c1["KW_topics_p"] = float(st.kruskal(*[g.TopicBreadth20 for _, g in ent.groupby("cluster")]).pvalue)
c1["MW_words_3v1_p"] = float(st.mannwhitneyu(ent[ent.cluster == "3+"].WordCount, ent[ent.cluster == "1"].WordCount).pvalue)
c1["MW_topics_3v1_p"] = float(st.mannwhitneyu(ent[ent.cluster == "3+"].TopicBreadth20, ent[ent.cluster == "1"].TopicBreadth20).pvalue)
R["finding1"] = c1

# ---------- 2. human-constructive triad and steering connections ----------
W = pd.read_csv(lw_f)
W["EntryID"] = W.Unit.str.split("::").str[1]
def col(a, b):
    for c in (f"{a} & {b}", f"{b} & {a}"):
        if c in W: return c
    raise KeyError((a, b))
TRIAD = [col("Eng.HD", "Prov.HD"), col("Eng.HD", "Interp.HD"), col("Prov.HD", "Interp.HD")]
STEER = [col("Eng.HD", "Steer.HD"), col("Steer.HD", "Prov.HD"), col("Steer.HD", "Interp.HD")]
W["triad"] = W[TRIAD].sum(axis=1); W["steer"] = W[STEER].sum(axis=1)
ent = ent.merge(W[["EntryID", "triad", "steer"]], on="EntryID")
c2 = {"triad_cols": TRIAD, "steer_cols": STEER}
T3 = "C(cluster, Treatment('1'))[T.3+]"
for y in ("triad", "steer"):
    c2[f"{y}_means"] = ent.groupby("cluster")[y].mean().round(3).to_dict()
    for tag, rhs in (("raw", ""), ("inst", " + C(Institution)"), ("inst_depth", " + C(Institution) + WC1000 + TopicBreadth20")):
        b, p, f = ols(f"{y} ~ C(cluster, Treatment('1')){rhs}", ent, T3)
        c2[f"{y}_{tag}_b3"] = b; c2[f"{y}_{tag}_p3"] = p
        if tag == "inst_depth":
            c2[f"{y}_p_words"] = float(f.pvalues["WC1000"]); c2[f"{y}_p_topics"] = float(f.pvalues["TopicBreadth20"])
lwcols = [c for c in W.columns if " & " in c]
mlw = W.merge(ent[["EntryID", "cluster"]], on="EntryID").groupby("cluster")[lwcols].mean().T
mlw.round(4).to_csv(f"{pre}_cluster_mean_line_weights.csv", index_label="connection")
c2["top_connections"] = {g: mlw[g].sort_values(ascending=False).head(5).round(3).to_dict() for g in mlw.columns}
R["finding2"] = c2

# ---------- 3. code-level differences, 3+ cluster against the rest ----------
for k in CFG + ["Mixed"]:
    L[f"Hol.{k}"] = (L.HolisticIntended == k).astype(int)
L = L.merge(D[["EntryID", "WordCount", "TopicBreadth20"]], on="EntryID", how="left")
L["WC1000"] = L.WordCount / 1000
codes = [f"{d}.{k}" for d in DIMS for k in CFG + ["NE"]] + [f"Hol.{k}" for k in CFG + ["Mixed"]]
ent_inst = ent.set_index("EntryID").Institution
wc_strata = pd.qcut(ent.set_index("EntryID").WordCount, 3, labels=False)
ent_in3 = ent.set_index("EntryID").cluster.eq("3+").astype(int)

def perm_p(y, strata):
    """Permute whole-entry 3+ labels within strata; statistic = difference in episode proportions."""
    eids = L.EntryID.values
    obs = y[L.in3 == 1].mean() - y[L.in3 == 0].mean()
    lab = ent_in3.copy(); groups = [lab.index[strata == s] for s in strata.unique()]
    cnt = 0
    for _ in range(NPERM):
        newlab = lab.copy()
        for g in groups:
            newlab[g] = rng.permutation(lab[g].values)
        m = newlab.reindex(eids).values
        if m.sum() == 0 or m.sum() == len(m): continue
        stat = y[m == 1].mean() - y[m == 0].mean()
        cnt += abs(stat) >= abs(obs) - 1e-12
    return (cnt + 1) / (NPERM + 1)

def gee(code, controls):
    rhs = "in3" + (" + C(Institution) + WC1000 + TopicBreadth20" if controls else "")
    try:
        m = smf.gee(f"Q('{code}') ~ {rhs}", groups="EntryID", data=L, family=sm.families.Binomial(), cov_struct=Exchangeable()).fit()
        return float(np.exp(m.params["in3"])), float(m.pvalues["in3"])
    except Exception:
        return np.nan, np.nan

rows = []
for c in codes:
    y = L[c].values
    a3, n3, a0, n0 = int(y[L.in3 == 1].sum()), int((L.in3 == 1).sum()), int(y[L.in3 == 0].sum()), int((L.in3 == 0).sum())
    fp = st.fisher_exact([[a3, n3 - a3], [a0, n0 - a0]]).pvalue
    rows.append(dict(code=c, n_3plus=a3, prop_3plus=a3 / n3, n_other=a0, prop_other=a0 / n0, fisher_p=fp))
CL = pd.DataFrame(rows)
named = ["Pos.NE", "Hol.CM", "Eng.AS", "Pos.HD"]
sel = named + [c for c in CL[CL.fisher_p < .05].code if c not in named]
out = []
for c in CL.code:
    r = CL[CL.code == c].iloc[0].to_dict()
    if c in sel:
        r["gee_or"], r["gee_p"] = gee(c, False)
        r["gee_ctrl_or"], r["gee_ctrl_p"] = gee(c, True)
        r["perm_inst_p"] = perm_p(L[c].values, ent_inst)
        r["perm_words_p"] = perm_p(L[c].values, wc_strata)
    out.append(r)
CL = pd.DataFrame(out)
CL.round(4).to_csv(f"{pre}_code_level_tests.csv", index=False)
R["finding3"] = {"selected": sel, "table": CL[CL.code.isin(sel)].round(4).to_dict("records"),
                 "episodes_3plus": int((L.in3 == 1).sum()), "episodes_other": int((L.in3 == 0).sum()),
                 "holCM_entries": L[L["Hol.CM"] == 1].groupby("EntryID").size().to_dict()}

# ---------- 4. sequence direction (R30) ----------
M = L[L.nep > 1].copy()
steps = []
for e, g in M.groupby("EntryID"):
    for (_, a), (_, b) in zip(g.iloc[:-1].iterrows(), g.iloc[1:].iterrows()):
        pair = a.TrajectoryUseCase if (a.TrajectoryUseCase == b.TrajectoryUseCase and a.TrajectoryUseCase != "Within-episode") else "Mixed use cases"
        steps.append(dict(EntryID=e, From=a.EpisodeID, To=b.EpisodeID, FromUse=a.TrajectoryUseCase, ToUse=b.TrajectoryUseCase,
                          Pair=pair, Step=round(b.HSv - a.HSv, 3), StepChange_file=b.StepChange,
                          SameHol=int(a.HolisticIntended == b.HolisticIntended), **{f"Same{d}": int(a[d] == b[d]) for d in DIMS}))
S = pd.DataFrame(steps)
_bad = S[(S.Step - S.StepChange_file.astype(float)).abs() > 1e-3]
R["stepchange_file_mismatches"] = _bad[["From", "To", "Step", "StepChange_file"]].to_dict("records")
if len(_bad): print("WARNING: StepChange in file disagrees with HS differences for", list(_bad.To), file=sys.stderr)
S.to_csv(f"{pre}_sequence_steps.csv", index=False)
tab = (S.groupby("Pair").agg(Steps=("Step", "size"), Entries=("EntryID", "nunique"), MeanChange=("Step", "mean"),
                            TowardHD=("Step", lambda x: int((x > 0).sum())), TowardAD=("Step", lambda x: int((x < 0).sum())),
                            Unchanged=("Step", lambda x: int((x == 0).sum()))).round(3))
tab.to_csv(f"{pre}_step_table.csv")
c4 = {"step_table": tab.reset_index().to_dict("records")}
ss = S[S.Pair == "Sequential"].Step
c4["seq_pairs_wilcoxon_p"] = float(st.wilcoxon(ss[ss != 0]).pvalue) if (ss != 0).sum() > 0 else np.nan
# sign test: first to last sequential learner episode
SQ = L[L.TrajectoryUseCase == "Sequential"]
sq_ent = SQ.groupby("EntryID").filter(lambda g: len(g) >= 2)
fl = sq_ent.groupby("EntryID").HSv.agg(lambda x: round(x.iloc[-1] - x.iloc[0], 3))
up, dn, zr = int((fl > 0).sum()), int((fl < 0).sum()), int((fl == 0).sum())
c4["sign_test"] = dict(entries=len(fl), toward_HD=up, toward_AD=dn, unchanged=zr,
                       p=float(st.binomtest(up, up + dn, 0.5).pvalue) if up + dn else np.nan,
                       by_entry=fl.to_dict())
# within-entry order permutation
def mean_step(groups):
    d = [np.diff(v) for v in groups if len(v) > 1]
    return float(np.concatenate(d).mean())
def order_perm(groups):
    obs = mean_step(groups)
    cnt = sum(mean_step([rng.permutation(v) for v in groups]) >= obs - 1e-12 for _ in range(NPERM))
    return obs, (cnt + 1) / (NPERM + 1)
seq_groups = [g.HSv.values for _, g in sq_ent.groupby("EntryID")]
all_groups = [g.HSv.values for _, g in M.groupby("EntryID", sort=False)]
c4["perm_sequential"] = dict(zip(("mean_step", "p"), order_perm(seq_groups)))
c4["perm_all_multi"] = dict(zip(("mean_step", "p"), order_perm(all_groups)))
c4["n_multi_entries"] = int(M.EntryID.nunique())
# first and last episodes against single-episode designs
first = M.groupby("EntryID").head(1); last = M.groupby("EntryID").tail(1); single = L[L.nep == 1]
c4["first_last_single"] = {
    "InterpHD_first": float(first["Interp.HD"].mean()), "InterpHD_single": float(single["Interp.HD"].mean()),
    "InterpHD_fisher_p": float(st.fisher_exact([[first["Interp.HD"].sum(), len(first) - first["Interp.HD"].sum()],
                                                 [single["Interp.HD"].sum(), len(single) - single["Interp.HD"].sum()]]).pvalue),
    "HS_first": float(first.HSv.mean()), "HS_last": float(last.HSv.mean()), "HS_single": float(single.HSv.mean()),
    "HS_first_vs_single_MW_p": float(st.mannwhitneyu(first.HSv, single.HSv).pvalue),
    "HS_last_vs_single_MW_p": float(st.mannwhitneyu(last.HSv, single.HSv).pvalue)}
fs = {}
for c in [f"{d}.{k}" for d in DIMS for k in CFG + ["NE"]]:
    a, b = first[c].sum(), single[c].sum()
    fs[c] = dict(first=round(first[c].mean(), 3), single=round(single[c].mean(), 3),
                 p=round(st.fisher_exact([[a, len(first) - a], [b, len(single) - b]]).pvalue, 4))
c4["first_vs_single_all_codes"] = {k: v for k, v in fs.items() if v["p"] < .10}
# SD counts
sd = M.groupby("EntryID").agg(sd=("HSv", lambda x: round(x.iloc[-1] - x.iloc[0], 3)), sd_file=("EntrySequenceChange", "first"), osc=("SequenceOscillation", "first"))
R["SD_file_mismatches"] = sd[(sd.sd - sd.sd_file.astype(float)).abs() > 1e-3].index.tolist()
c4["SD_counts"] = {str(t): dict(human=int((sd.sd >= t).sum()), ai=int((sd.sd <= -t).sum()), stable=int(((sd.sd > -t) & (sd.sd < t)).sum()))
                   for t in (0.34, 0.5, 0.75, 1.0)}
c4["SD_oscillating"] = int(sd.osc.notna().sum())
c4["SD_label_counts_file"] = M.groupby("EntryID").SD.first().value_counts().to_dict()
R["finding4"] = c4

# ---------- 5. instructor-only episodes ----------
I = E[E.Learner == 0]
inst_only = set(I.EntryID) - set(L.EntryID)
c5 = {"episodes": len(I), "entries": int(I.EntryID.nunique()), "instructor_only_entries": len(inst_only),
      "participants": I.Participant.value_counts().to_dict(), "holistic": I.HolisticIntended.value_counts().to_dict()}
c5["dims"] = {d: (I[d].value_counts() / len(I)).round(3).to_dict() for d in DIMS}
c5["dims_learner"] = {d: (L[d].value_counts() / len(L)).round(3).to_dict() for d in DIMS}
pd.DataFrame({f"{who}_{d}": (X[d].value_counts() / len(X)).reindex(CFG + ["NE"]).fillna(0).round(3)
              for who, X in (("Instructor", I), ("Learner", L)) for d in DIMS}).T.to_csv(f"{pre}_instructor_panel.csv")
R["finding5"] = c5

# ---------- 6. dependence ----------
g = M.groupby("EntryID").HSv
k = g.ngroups; N = len(M); ni = g.size().values
grand = M.HSv.mean()
msb = (ni * (g.mean().values - grand) ** 2).sum() / (k - 1)
msw = ((M.HSv - g.transform("mean")) ** 2).sum() / (N - k)
n0 = (N - (ni ** 2).sum() / N) / (k - 1)
icc = (msb - msw) / (msb + (n0 - 1) * msw)
mbar = N / k; deff = 1 + (mbar - 1) * icc
c6 = {"ICC_HS": float(icc), "mean_episodes_per_multi_entry": float(mbar), "design_effect": float(deff),
      "episodes_in_multi": int(N), "effective_n": float(N / deff), "carryover": {}}
LL = L.reset_index(drop=True)
eid = LL.EntryID.values
for f, colname in [("HolisticIntended", "SameHol")] + [(d, f"Same{d}") for d in DIMS]:
    obs = S[colname].mean()
    vals = LL[f].values; n = len(S); share = []
    for _ in range(NPERM):
        i = rng.integers(0, len(LL), 4 * n); j = rng.integers(0, len(LL), 4 * n)
        ok = eid[i] != eid[j]; i, j = i[ok][:n], j[ok][:n]
        share.append((vals[i] == vals[j]).mean())
    share = np.array(share)
    c6["carryover"][f] = dict(consecutive=float(obs), random=float(share.mean()), p=float(((share >= obs - 1e-12).sum() + 1) / (NPERM + 1)))
R["dependence"] = c6

ent.round(4).to_csv(f"{pre}_cluster_entries.csv", index=False)
json.dump(R, open(f"{pre}_results.json", "w"), indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o))

# ---------- 7. figures ----------
if FIG:
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    COL = {"1": "#9AA5B1", "2": "#2C7FB8", "3+": "#D55E00"}
    nodes = pd.read_csv(nodes_f).set_index("code")
    sc = np.abs(ent[["SV1", "SV2"]].values).max() / np.abs(nodes[["SV1", "SV2"]].values).max()
    fig, ax = plt.subplots(figsize=(8.5, 8))
    ax.axhline(0, color="#e5e5e5", lw=1); ax.axvline(0, color="#e5e5e5", lw=1)
    ax.scatter(nodes.SV1 * sc, nodes.SV2 * sc, marker="x", color="#9a9a9a", s=25)
    for c, r in nodes.iterrows(): ax.annotate(c, (r.SV1 * sc, r.SV2 * sc), fontsize=7, color="#555", xytext=(3, 3), textcoords="offset points")
    for cl in ("1", "2", "3+"):
        s = ent[ent.cluster == cl]
        ax.scatter(s.SV1, s.SV2, color=COL[cl], alpha=.8, s=45, label=f"{cl} learner episode{'s' if cl != '1' else ''} ({len(s)} entries)")
        ax.scatter(s.SV1.mean(), s.SV2.mean(), color=COL[cl], marker="s", s=180, edgecolor="black")
    for _, r in ent[ent.n >= 4].iterrows():
        ax.annotate(f"{r.EntryID} ({r.n})", (r.SV1, r.SV2), fontsize=8, fontweight="bold", xytext=(5, -10), textcoords="offset points")
    ax.set_xlabel("SV1"); ax.set_ylabel("SV2"); ax.set_aspect("equal"); ax.legend(loc="lower left", fontsize=8, frameon=False)
    ax.set_title("Entries by number of learner episodes (squares = cluster means; labels = 4+ episodes)", fontsize=10)
    fig.tight_layout(); fig.savefig(f"{pre}_cluster_positions.png", dpi=150); plt.close(fig)

    fig, axs = plt.subplots(1, 3, figsize=(16, 5.6))
    for ax, cl in zip(axs, ("1", "2", "3+")):
        w = mlw[cl]
        for conn, v in w.sort_values().items():
            a, b = conn.split(" & ")
            if v > .02 and a in nodes.index and b in nodes.index:
                ax.plot([nodes.SV1[a], nodes.SV1[b]], [nodes.SV2[a], nodes.SV2[b]], color=COL[cl], lw=v * 25, alpha=min(1, .25 + v * 3), solid_capstyle="round")
        ax.scatter(nodes.SV1, nodes.SV2, color="black", s=12, zorder=3)
        for c, r in nodes.iterrows(): ax.annotate(c, (r.SV1, r.SV2), fontsize=7, xytext=(3, 3), textcoords="offset points")
        ax.set_title(f"Mean network: {cl} learner episode{'s' if cl != '1' else ''} ({(ent.cluster == cl).sum()} entries)", fontsize=10)
        ax.set_aspect("equal"); ax.axhline(0, color="#eee"); ax.axvline(0, color="#eee")
    fig.tight_layout(); fig.savefig(f"{pre}_mean_networks_by_cluster.png", dpi=150); plt.close(fig)

    M["posg"] = M.pos.clip(upper=4).map({1: "1st", 2: "2nd", 3: "3rd", 4: "4th+"})
    H = pd.DataFrame({d: M.groupby("posg")[d].apply(lambda x: np.mean([VAL[v] for v in x if v != "NE"]) if (x != "NE").any() else np.nan) for d in DIMS})
    H["HS"] = M.groupby("posg").HSv.mean()
    nn = M.groupby("posg").size()
    fig, ax = plt.subplots(figsize=(7, 4.2))
    im = ax.imshow(H.T.values, cmap="RdYlBu", vmin=0, vmax=3, aspect="auto")
    ax.set_xticks(range(len(H.index)), [f"{p}\n(n={nn[p]})" for p in H.index]); ax.set_yticks(range(H.shape[1]), H.columns)
    for i in range(H.shape[1]):
        for j in range(H.shape[0]): ax.text(j, i, f"{H.T.values[i, j]:.2f}", ha="center", va="center", fontsize=8)
    fig.colorbar(im, label="Mean human direction (AD 0 to HD 3)"); ax.set_title("Multi-episode entries: human direction by position in sequence", fontsize=10)
    fig.tight_layout(); fig.savefig(f"{pre}_heatmap_sequence_position.png", dpi=150); plt.close(fig)

    fig, axs = plt.subplots(1, 3, figsize=(15, 4.2))
    for ax, cl in zip(axs, ("1", "2", "3+")):
        X = L[L.cluster == cl]
        Mx = np.array([[(X[d] == k).mean() for k in CFG + ["NE"]] for d in DIMS])
        ax.imshow(Mx, cmap="Greens", vmin=0, vmax=1)
        ax.set_xticks(range(5), CFG + ["NE"]); ax.set_yticks(range(5), DIMS)
        for i in range(5):
            for j in range(5): ax.text(j, i, f"{Mx[i, j]:.2f}", ha="center", va="center", fontsize=8, color="white" if Mx[i, j] > .6 else "black")
        ax.set_title(f"{cl} learner episode{'s' if cl != '1' else ''}: {len(X)} episodes, {X.EntryID.nunique()} entries", fontsize=10)
    fig.tight_layout(); fig.savefig(f"{pre}_heatmap_dimension_by_cluster.png", dpi=150); plt.close(fig)
print(json.dumps(R, indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o)))
