suppressMessages(library(rENA))
setwd(commandArgs(TRUE)[1])  # folder holding the ENA-ready CSV; outputs are written here
set <- readRDS("run2_set.rds")
pts <- as.data.frame(set$points); inst <- pts$Institution; sv <- as.matrix(set$points)[,1:2]
nodes <- as.data.frame(set$rotation$nodes); nm <- nodes$code
k <- max(abs(sv)) / max(abs(as.matrix(nodes[,2:3])))
nx <- nodes[,2]*k; ny <- nodes[,3]*k; names(nx) <- names(ny) <- nm
lw <- as.matrix(set$line.weights); cn <- colnames(lw)
mlw <- sapply(split(as.data.frame(lw), inst), colMeans)
cols <- c("Georgia Tech"="#B3A369","Stanford"="#8C1515","Toronto"="#1E3765")
lim <- c(-1,1)*max(abs(c(nx,ny,sv)))*1.2
lab <- function(){ off <- ifelse(duplicated(round(cbind(nx,ny),2)) | duplicated(round(cbind(nx,ny),2),fromLast=TRUE), c(3,1), 3)
  text(nx,ny,nm,pos=off,cex=0.7,col="grey25") }
ax <- function(main){ plot(NA,xlim=lim,ylim=lim,asp=1,main=main,cex.main=1,
  xlab=sprintf("SV1 (%.0f%% of variance)",100*set$model$variance[1]), ylab=sprintf("SV2 (%.0f%%)",100*set$model$variance[2])); abline(h=0,v=0,col="grey88") }
png("run2_points_by_institution.png",1100,1000,res=130)
ax("ENA unit positions: 81 entries, all three collections (Run 2)")
points(nx,ny,pch=4,col="grey60"); lab()
points(sv,col=adjustcolor(cols[inst],0.75),pch=19,cex=1.2)
m <- aggregate(sv,list(inst),mean); se <- aggregate(sv,list(inst),function(z) 1.96*sd(z)/sqrt(length(z)))
for(i in 1:3){ rect(m[i,2]-se[i,2],m[i,3]-se[i,3],m[i,2]+se[i,2],m[i,3]+se[i,3],border=cols[m[i,1]],lty=2); points(m[i,2],m[i,3],pch=22,cex=2.4,bg=cols[m[i,1]]) }
legend("bottomleft",c(names(cols),"square = mean, dashed box = 95% CI"),col=c(cols,"black"),pch=c(19,19,19,NA),bty="n",cex=0.85); dev.off()
for(g in colnames(mlw)){ png(sprintf("run2_mean_network_%s.png",gsub(" ","_",g)),1000,1000,res=130)
  ax(paste0("Mean network: ",g," (line width = mean connection weight)"))
  w <- mlw[,g]; for(i in order(w)){ pr <- strsplit(cn[i]," & ")[[1]]; if(w[i]>0.02) segments(nx[pr[1]],ny[pr[1]],nx[pr[2]],ny[pr[2]],lwd=w[i]*25,col=adjustcolor(cols[g],min(1,0.25+w[i]*3))) }
  points(nx,ny,pch=19,cex=1); lab(); dev.off() }
