import sys,os,pandas as pd
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from parse import load
S=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
E,P,err=load(); assert not err, err
new=pd.DataFrame(P); ent=pd.DataFrame(E)
inst=dict(zip(ent["Entry ID"],ent["Institution"])); new["Institution"]=new["Entry ID"].map(inst)
for c in ["Author(s)","Short Title","Source Category"]: new[c]=new["Entry ID"].map(dict(zip(ent["Entry ID"],ent[c])))
new["Coding pass"]="Full v0.7 (Oct 26, 2026)"
cf=pd.read_excel(f"{S}/data/coded_v07.xlsx",sheet_name="Coding Form",header=2); cf=cf[cf["Episode ID"].notna()].copy()
cf["Coding pass"]="Pilot v0.7 (Oct 24, 2026)"
cols=list(cf.columns)
full=pd.concat([cf,new.reindex(columns=cols)],ignore_index=True).astype(object)
# computed indices for new rows (intended and reported)
order={"AD":1,"AS":2,"CM":3,"HD":4}
def idx(row,pre):
    names=[c for c in cols if c.startswith(pre+"-D") and "Tier" not in c]
    v=[row[c] for c in names if row[c] in order]
    n={k:sum(1 for x in v if x==k) for k in order}
    out={f"{pre} n {k}":n[k] for k in order}; out[f"{pre} Dims Coded"]=len(v)
    if v:
        mx=max(n.values()); modes=[k for k in order if n[k]==mx]
        out[f"{pre} Modal Config"]=modes[0] if len(modes)==1 else "Tie"
    else: out[f"{pre} Modal Config"]=""
    if len(v)>=4:
        import statistics
        nums=sorted(order[x] for x in v); med=statistics.median(nums)
        D=sum(abs(x-med) for x in nums)/len(nums); out[f"{pre} Adjacency Coherence"]=round(1-D/1.5,2)
    else: out[f"{pre} Adjacency Coherence"]=""
    return out
for i in full.index[full["Coding pass"].str.startswith("Full")]:
    for pre in ["I","R"]:
        for k,v in idx(full.loc[i],pre).items():
            if k in full.columns: full.at[i,k]=v
    ic=full.at[i,"I Adjacency Coherence"]; ndim=full.at[i,"I Dims Coded"]
    flag=[]
    if ndim<3: flag.append("<3 dims")
    if ic!="" and ic<2/3: flag.append("low coherence")
    if full.at[i,"I Modal Config"]=="Tie": flag.append("modal tie")
    full.at[i,"I Review Flag"]="; ".join(flag)
    s,e=full.at[i,"Start Config"],full.at[i,"End Config"]
    if s in order and e in order: full.at[i,"Trajectory (TR)"]="Stable" if s==e else ("Toward human direction" if order[e]>order[s] else "Toward AI direction")
full.to_pickle(f"{S}/code/full.pkl"); ent.to_pickle(f"{S}/code/entries_new.pkl")
print(full.groupby(["Institution","Coding pass"]).size()); print(len(full))
print(full["Human Participant"].value_counts().to_dict())
