import sys,glob,os
D=os.path.dirname(os.path.abspath(__file__))
EF=["Entry ID","Institution","Author(s)","Short Title","Source Category","Genre","Screening","Claim Stance (CS)","AI-use Stance (US)","Limitations Acknowledged (LA)","Traces Collected (TC)","Entry Note"]
PF=["Episode ID","Entry ID","Learning Activity (label)","Episode # (within activity)","Episode Objective","Human Participant","AI System / Tool","Context","Sociotechnical Frame","Laurillard Activity Type (context)","Excerpt or Paraphrase","I","R","RT","Dialogue Type (DT)","Epistemic Object (EB)","EO intended","EO reported","EO reported tier","ML intended","ML reported","ML reported tier","Uptake intended","Uptake reported","Uptake reported tier","Start Config","End Config","Trajectory Basis","Stated Purpose (DP)","Learner Variability Noted (LV)","Holistic: intended (judgment)","Holistic: reported (judgment)","Confidence","Trajectory Use Case","Memo"]
L={"cfg":{"AD","AS","CM","HD","NE"},"tier":{"T1","T2","T3","-"},"part":{"Student","Instructor","TA","Intern/Trainee","Research team","Group","Other"},
"ctx":{"Teaching","Internship/Experiential","Research training","Course preparation","Other"},
"frame":{"High-stakes assessment","Low-stakes or formative","Self-directed or optional","Professional or workplace","Instructor preparation","Unclear"},
"laur":{"Acquisition","Practice","Inquiry, discussion, collaboration","Inquiry, production","Reflection","Multiple","NE"},
"dt":{"Instructional","Feedback-oriented","Collaborative","Reflective","Mixed","NE"},
"eo":{"EO-IN","EO-RE","EO-EV","EO-CH","EO-RD","NE"},"eb":{"Evidence and relevance","Explanation and causality","Authority and credibility","Reasoning norms","Perspective and bias","Multiple","NE"},
"ml":{"ML-FR","ML-EP","ML-CW","ML-DD","ML-RA","ML-MX","ML-NA","NE"},"up":{"UP-AD","UP-AP","UP-CT","UP-RJ","UP-IG","UP-MX","NE"},
"dp":{"Introduce or model (AD)","Guided practice (AS)","Inquiry and refinement (CM)","Independent production (HD)","Critical evaluation of AI (HD)","Multiple","Not stated"},
"lv":{"Prior knowledge","Motivation","Self-regulation","Cultural context","AI literacy","Orientation toward AI","Multiple","None noted"},
"hol":{"AD","AS","CM","HD","Mixed","NE"},"conf":{"High","Medium","Low"},"tb":{"Intended","Reported"},"tuse":{"Single use","Sequential","Within-episode","Recurrent"},
"scr":{"Include","Exclude: AI removed","Exclude: non-interactional commentary","Exclude: static AI artifact only","Exclude: other"},
"cs":{"Descriptive","Benefit claimed","Mixed results","Critical"},"us":{"Assigned","Optional","Limited","Prohibited","Mixed","Instructor use"},
"la":{"None stated","Design limits","Evidence limits","Both"},"tc":{"Not described","Collected, not reproduced","Partly reproduced","Reproduced"}}
def load(pattern="*.txt"):
    E,P,err=[],[],[]
    for f in sorted(glob.glob(os.path.join(D,"batches",pattern))):
        for n,line in enumerate(open(f,encoding="utf-8"),1):
            line=line.rstrip("\n")
            if not line.strip(): continue
            t,*v=line.split("|")
            where=f"{os.path.basename(f)}:{n}"
            if t=="E":
                if len(v)!=len(EF): err.append(f"{where} E has {len(v)} fields"); continue
                e=dict(zip(EF,v)); E.append(e)
                for k,s in [("Screening","scr"),("Claim Stance (CS)","cs"),("AI-use Stance (US)","us"),("Limitations Acknowledged (LA)","la"),("Traces Collected (TC)","tc")]:
                    if e[k] not in L[s]: err.append(f"{where} {k}={e[k]}")
            elif t=="P":
                if len(v)!=len(PF): err.append(f"{where} P has {len(v)} fields"); continue
                p=dict(zip(PF,v)); I,R,RT=p.pop("I").split(),p.pop("R").split(),p.pop("RT").split()
                if len(I)!=5 or len(R)!=5 or len(RT)!=5: err.append(f"{where} profile length"); continue
                names=["Engagement Type","Interaction Structure (steering)","Provenance of Production","Interpretive Influence"]
                In=["I-D1 Engagement Type","I-D2 Interaction Structure (steering)","I-D3 Provenance of Production","I-D4 Interpretive Influence","I-D5 Positioning (design framing)"]
                Rn=["R-D1 Engagement Type","R-D2 Interaction Structure (steering)","R-D3 Provenance of Production","R-D4 Interpretive Influence","R-D5 Positioning (learner orientation)"]
                for i in range(5):
                    p[In[i]]=I[i]; p[Rn[i]]=R[i]; p[f"R-D{i+1} Tier"]="" if RT[i]=="-" else RT[i]
                    if I[i] not in L["cfg"] or R[i] not in L["cfg"] or RT[i] not in L["tier"]: err.append(f"{where} bad cfg/tier")
                    if (R[i]=="NE")!=(RT[i]=="-"): err.append(f"{where} R/RT mismatch dim {i+1}")
                for k in ["EO reported tier","ML reported tier","Uptake reported tier"]:
                    if p[k]=="-": p[k]=""
                chk=[("Human Participant","part"),("Context","ctx"),("Sociotechnical Frame","frame"),("Laurillard Activity Type (context)","laur"),("Dialogue Type (DT)","dt"),("Epistemic Object (EB)","eb"),("EO intended","eo"),("EO reported","eo"),("ML intended","ml"),("ML reported","ml"),("Uptake intended","up"),("Uptake reported","up"),("Start Config","cfg"),("End Config","cfg"),("Trajectory Basis","tb"),("Stated Purpose (DP)","dp"),("Learner Variability Noted (LV)","lv"),("Holistic: intended (judgment)","hol"),("Holistic: reported (judgment)","hol"),("Confidence","conf"),("Trajectory Use Case","tuse")]
                for k,s in chk:
                    if p[k] not in L[s]: err.append(f"{where} {p['Episode ID']} {k}={p[k]!r}")
                for k,tk in [("EO reported","EO reported tier"),("ML reported","ML reported tier"),("Uptake reported","Uptake reported tier")]:
                    if (p[k]=="NE")!=(p[tk]==""): err.append(f"{where} {p['Episode ID']} {k} tier mismatch")
                P.append(p)
            else: err.append(f"{where} unknown line type {t}")
    ids=[p["Episode ID"] for p in P]
    for x in set(ids):
        if ids.count(x)>1: err.append(f"duplicate {x}")
    ent={e["Entry ID"] for e in E}
    for p in P:
        if p["Entry ID"] not in ent: err.append(f"{p['Episode ID']} entry missing")
    return E,P,err
if __name__=="__main__":
    E,P,err=load(sys.argv[1] if len(sys.argv)>1 else "*.txt")
    print(f"entries {len(E)} episodes {len(P)} errors {len(err)}"); print("\n".join(err))
