suppressMessages(library(rENA)); setwd(commandArgs(TRUE)[1])  # folder holding the ENA-ready CSV; outputs are written here
p<-read.csv("run2_points.csv"); cols<-c(Pilot="#7A7A7A",Full="#D55E00")
png("run2_points_by_coding_pass.png",1000,950,res=130)
lim<-c(-1,1)*max(abs(c(p$SV1,p$SV2)))*1.2
plot(p$SV1,p$SV2,col=adjustcolor(cols[p$CodingPass],0.8),pch=19,xlim=lim,ylim=lim,asp=1,xlab="SV1 (29%)",ylab="SV2 (13%)",main="Run 2 entries by coding pass (pilot vs new pass)",cex.main=1)
abline(h=0,v=0,col="grey88"); m<-aggregate(cbind(SV1,SV2)~CodingPass,p,mean); points(m$SV1,m$SV2,pch=22,cex=2.4,bg=cols[m$CodingPass])
n<-table(p$CodingPass); legend("bottomleft",c(sprintf("Pilot (%d entries, Oct 24)",n[["Pilot"]]),sprintf("New pass (%d entries, Oct 26)",n[["Full"]])),col=cols[c("Pilot","Full")],pch=19,bty="n"); dev.off()
