#!/usr/bin/env bash
# One-time setup of R + rENA in a fresh Claude Code cloud session (Ubuntu).
# Needs cloud.r-project.org in the environment's allowed network domains.
set -e
apt-get update -qq
apt-get install -y -qq r-base libcurl4-openssl-dev libssl-dev libxml2-dev libuv1-dev cmake \
  libfontconfig1-dev libfreetype6-dev libharfbuzz-dev libfribidi-dev libpng-dev libtiff5-dev libjpeg-dev pandoc
Rscript -e 'install.packages("rENA", repos="https://cloud.r-project.org")'
pip install -q pandas openpyxl
Rscript -e 'library(rENA); cat("rENA", as.character(packageVersion("rENA")), "ready\n")'
