suppressMessages(library(rENA))
setwd(commandArgs(TRUE)[1])
d0 <- read.csv("AIM-AI_v071_moderated_ENA_ready_intended.csv", check.names=FALSE); d0 <- d0[d0$Learner==1,]
all20 <- grep("^(Eng|Steer|Prov|Interp|Pos)\\.(AD|AS|CM|HD)$", names(d0), value=TRUE)
fixed16 <- c("Eng.AS","Eng.CM","Eng.HD","Eng.AD","Steer.AS","Steer.CM","Steer.HD","Prov.AD","Prov.AS","Prov.CM","Prov.HD","Interp.AS","Interp.HD","Pos.AS","Pos.CM","Pos.HD")
freq <- colSums(d0[,all20]); thr3 <- all20[freq >= 3]
cat("Learner episodes:", nrow(d0), " units:", length(unique(paste(d0$Institution,d0$EntryID))), "\n")
cat("Code frequencies:\n"); print(freq)
cat("Codes kept at threshold 3 (", length(thr3), "):", paste(thr3, collapse=", "), "\n")
fit <- function(d, codes, w){ acc <- ena.accumulate.data(units=d[,c("Institution","EntryID")], conversation=d[,c("Institution","ActivityID")], metadata=d[,"Institution",drop=FALSE], codes=d[,codes], window.size.back=w); ena.make.set(acc) }
report <- function(tag, d, codes, save=FALSE){
  set <- fit(d, codes, 1); set2 <- fit(d, codes, 2)
  pass <- tapply(d$CodingPass, d$EntryID, function(x) x[1])
  pts <- as.data.frame(set$points); inst <- pts$Institution; sv <- as.matrix(set$points)[,1:2]
  eid <- sub(".*::","",pts$ENA_UNIT); pp <- pass[eid]
  cat("\n==========", tag, "==========\n"); cat("Units:", nrow(pts), "\n"); print(table(inst)); print(table(pp))
  cat("Variance SV1, SV2:", round(set$model$variance[1:2],3), "\n"); print(ena.correlations(set))
  for(k in 1:2){kt<-kruskal.test(sv[,k]~factor(inst)); cat(sprintf("Institution SV%d Kruskal-Wallis chi2=%.2f p=%.3f\n",k,kt$statistic,kt$p.value))}
  for(k in 1:2){wt<-wilcox.test(sv[pp=="Pilot",k],sv[pp=="Full",k]); cat(sprintf("Original pass SV%d Mann-Whitney W=%.0f p=%.3f\n",k,wt$statistic,wt$p.value))}
  print(aggregate(sv,list(Institution=inst),mean)); print(aggregate(sv,list(Pass=pp),mean))
  p2<-as.matrix(set2$points)[,1:2]; cat("Window 1 vs 2 |r| SV1:",round(abs(cor(sv[,1],p2[,1])),3)," SV2:",round(abs(cor(sv[,2],p2[,2])),3),"\n")
  nodes<-as.data.frame(set$rotation$nodes); cat("Node positions:\n"); print(nodes[order(nodes[,2]),1:3],row.names=FALSE)
  lw<-as.matrix(set$line.weights); cn<-colnames(lw); mlw<-sapply(split(as.data.frame(lw),inst),colMeans)
  for(g in colnames(mlw)){v<-setNames(mlw[,g],cn);o<-order(-v)[1:6];cat("Top connections",g,"\n");print(round(v[o],3))}
  if(save){
    write.csv(data.frame(Unit=pts$ENA_UNIT,Institution=inst,CodingPass=pp,SV1=round(sv[,1],4),SV2=round(sv[,2],4)),"run3_points.csv",row.names=FALSE)
    write.csv(data.frame(connection=cn,round(mlw,4)),"run3_mean_line_weights.csv",row.names=FALSE)
    write.csv(data.frame(code=nodes$code,SV1=round(nodes[,2],4),SV2=round(nodes[,3],4)),"run3_node_positions.csv",row.names=FALSE)
    saveRDS(set,"run3_set.rds")
  }
  invisible(set)
}
report("Model 1A (primary): threshold 3, all learner episodes", d0, thr3, save=TRUE)
report("Comparison: fixed 16-code list from Runs 1 and 2", d0, fixed16)
d1 <- d0[d0$NonGenerativeTool==0,]; thr3b <- all20[colSums(d1[,all20])>=3]
report("Model 1B: without TO-BelloWrite-A2 (NonGenerativeTool)", d1, thr3b)
