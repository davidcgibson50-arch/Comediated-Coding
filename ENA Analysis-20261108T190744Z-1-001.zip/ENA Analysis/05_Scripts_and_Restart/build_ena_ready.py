"""Build the ENA-ready (intended profile) CSV from the combined coding workbook.

Usage:
    python3 build_ena_ready.py AIM-AI_Coded_Full_v07.xlsx AIM-AI_v07_full_ENA_ready_intended.csv

Input: the 'Coding Form' sheet (one row per episode, pilot + new pass, with a 'Coding pass' column).
Output: one row per episode with metadata plus 20 binary codes (5 dimensions x AD/AS/CM/HD).
"""
import re, sys
import pandas as pd

src, out = sys.argv[1], sys.argv[2]
cf = pd.read_excel(src, sheet_name="Coding Form", dtype=str).fillna("")
cf = cf[cf["Episode ID"].str.strip() != ""]

DIMS = [("Eng", "I-D1 Engagement Type"),
        ("Steer", "I-D2 Interaction Structure (steering)"),
        ("Prov", "I-D3 Provenance of Production"),
        ("Interp", "I-D4 Interpretive Influence"),
        ("Pos", "I-D5 Positioning (design framing)")]
CONFIGS = ["AD", "AS", "CM", "HD"]

rows = []
for _, r in cf.iterrows():
    eid = r["Episode ID"].strip()
    row = {
        "EpisodeID": eid,
        "Institution": r["Institution"],
        "EntryID": r["Entry ID"],
        "ActivityID": re.sub(r"\d+$", "", eid),          # GT-01-A1 -> GT-01-A
        "EpisodeOrder": int(float(r["Episode # (within activity)"] or 1)),
        "Participant": r["Human Participant"],
        "Learner": int(r["Human Participant"] in ("Student", "Group")),
        "TrajectoryUseCase": r["Trajectory Use Case"],
        "HolisticIntended": r["Holistic: intended (judgment)"],
        "CodingPass": "Pilot" if r["Coding pass"].startswith("Pilot") else "Full",
        "EO_designed": int(r["EO intended"] not in ("", "NE")),
        "ML_designed": int(r["ML intended"] not in ("", "NE", "ML-NA")),
    }
    for short, col in DIMS:
        for c in CONFIGS:
            row[f"{short}.{c}"] = int(r[col].strip() == c)
    rows.append(row)

# Row order affects the sign of the SVD axes, so keep a fixed order (by Episode ID).
pd.DataFrame(rows).sort_values("EpisodeID").to_csv(out, index=False)
print(f"Wrote {len(rows)} episodes to {out}")
