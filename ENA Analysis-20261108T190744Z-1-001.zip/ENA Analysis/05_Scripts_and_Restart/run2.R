suppressMessages(library(rENA))
setwd(commandArgs(TRUE)[1])  # folder holding the ENA-ready CSV; outputs are written here
d <- read.csv("AIM-AI_v07_full_ENA_ready_intended.csv", check.names=FALSE); d <- d[d$Learner==1,]
codes <- c("Eng.AS","Eng.CM","Eng.HD","Eng.AD","Steer.AS","Steer.CM","Steer.HD","Prov.AD","Prov.AS","Prov.CM","Prov.HD","Interp.AS","Interp.HD","Pos.AS","Pos.CM","Pos.HD")
pass <- tapply(d$CodingPass, d$EntryID, function(x) x[1])
fit <- function(w){ acc <- ena.accumulate.data(units=d[,c("Institution","EntryID")], conversation=d[,c("Institution","ActivityID")], metadata=d[,"Institution",drop=FALSE], codes=d[,codes], window.size.back=w); ena.make.set(acc) }
set <- fit(1); set2 <- fit(2)
pts <- as.data.frame(set$points); inst <- pts$Institution; sv <- as.matrix(set$points)[,1:2]
eid <- sub(".*::","",pts$ENA_UNIT); pp <- pass[eid]
cat("Units:",nrow(pts),"\n"); print(table(inst)); print(table(pp))
cat("Variance SV1, SV2:", round(set$model$variance[1:2],3),"\n"); print(ena.correlations(set))
for(k in 1:2){kt<-kruskal.test(sv[,k]~factor(inst)); cat(sprintf("Institution SV%d KW chi2=%.2f p=%.3f\n",k,kt$statistic,kt$p.value))}
for(k in 1:2){wt<-wilcox.test(sv[pp=="Pilot",k],sv[pp=="Full",k]); cat(sprintf("Coding pass SV%d Mann-Whitney W=%.0f p=%.3f\n",k,wt$statistic,wt$p.value))}
print(aggregate(sv,list(Institution=inst),mean)); print(aggregate(sv,list(Pass=pp),mean))
p2<-as.matrix(set2$points)[,1:2]; cat("Window 1 vs 2 |r| SV1:",round(abs(cor(sv[,1],p2[,1])),3)," SV2:",round(abs(cor(sv[,2],p2[,2])),3),"\n")
nodes<-as.data.frame(set$rotation$nodes); cat("\nNode positions:\n"); print(nodes[order(nodes[,2]),1:3],row.names=FALSE)
lw<-as.matrix(set$line.weights); cn<-colnames(lw); rot<-as.matrix(set$rotation$rotation.matrix)
for(k in 1:2){v<-setNames(rot[,k+1],cn); o<-order(v); cat(sprintf("\nSV%d loadings negative:\n",k)); print(round(v[head(o,6)],3)); cat("positive:\n"); print(round(v[rev(tail(o,6))],3))}
mlw<-sapply(split(as.data.frame(lw),inst),colMeans)
for(g in colnames(mlw)){v<-setNames(mlw[,g],cn);o<-order(-v)[1:8];cat("\nTop connections",g,"\n");print(round(v[o],3))}
o<-order(sv[,1]); cat("\nSV1 extremes low:\n"); print(round(setNames(sv[head(o,6),1],pts$ENA_UNIT[head(o,6)]),3)); cat("high:\n"); print(round(setNames(sv[rev(tail(o,6)),1],pts$ENA_UNIT[rev(tail(o,6))]),3))
o<-order(sv[,2]); cat("\nSV2 extremes low:\n"); print(round(setNames(sv[head(o,6),2],pts$ENA_UNIT[head(o,6)]),3)); cat("high:\n"); print(round(setNames(sv[rev(tail(o,6)),2],pts$ENA_UNIT[rev(tail(o,6))]),3))
write.csv(data.frame(Unit=pts$ENA_UNIT,Institution=inst,CodingPass=pp,SV1=round(sv[,1],4),SV2=round(sv[,2],4)),"run2_points.csv",row.names=FALSE)
write.csv(data.frame(connection=cn,round(mlw,4)),"run2_mean_line_weights.csv",row.names=FALSE)
saveRDS(set,"run2_set.rds")
