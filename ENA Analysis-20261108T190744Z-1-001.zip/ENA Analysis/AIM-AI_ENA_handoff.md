# AIM-AI: Epistemic Network Analysis Handoff (Codebook v0.7)

Prepared October 24, 2026, for a Claude Code session working with David Gibson. This version supersedes all earlier briefs. Under Codebook v0.7 the three-collection analysis is an **exploratory design-layer study of instructor intentions and public reporting stances** (codebook rule R29). It travels with three files:

- `aimai_ena_episodes_v07.csv`: ENA-ready table, one row per mediation episode (68 rows, 177 columns), coded under Codebook v0.7. It replaces `aimai_ena_episodes.csv`.
- `AIM-AI_Coded_Sample_v07.xlsx`: the same coding in the v0.7 Coding Form layout, with formula-computed indices, the Entry Profile (stance codes), and summary tables (for human review, not ENA input).
- `AIM-AI_Codebook_v0_7.xlsx`: the codebook (definitions, rules R1 to R29, Move Coding Form template, v0.7 Changes sheet).

## 1. Working agreements

David asks to be consulted at critical junctures of reasoning, analysis design, and narrative. Every setting in Sections 3 and 5 has been decided by him; check with him before departing from any of them, and raise the open items in Section 7 before writing results up. Write in his voice or an academic tone, first-person plural, APA 7 references, no em dashes, and include DOIs with citations.

## 2. What changed in v0.7, and why it matters for ENA

Each episode is now coded twice:

- **Intended profile** (`I_` columns): the configuration the design statements ask for or communicate. This is evidence of instructor intention (tier T4).
- **Reported profile** (`R_` columns): the configuration evidenced by enactment, each dimension tagged with an evidence tier: T1 trace (raw record of the exchange), T2 participant account (the coded participant's own report; an instructor's account of their own AI use counts as T2), T3 instructor or developer observation. NE where no enactment evidence bears on a dimension.

Three dimensions were re-specified:

- **D2 Interaction Structure (steering):** who initiates, redirects, and closes the exchange.
- **D3 Provenance of Production:** whose contributions make up the work (AI-produced and received; AI-produced and adapted; co-produced; learner-produced with AI consulted). Laurillard's activity type is now a context column (`LaurillardType`), not a dimension.
- **D5 Social Positioning:** in the intended profile, the positioning the design communicates; in the reported profile, learner orientation from learner behavior or accounts.

New codes: uptake of AI contributions (`UP`), intended and reported versions of epistemic opportunity (`EO`) and mediational literacy (`ML`), and entry-level reporting-stance codes.

**Consequence for modeling.** Faculty-authored entries rarely reproduce the learner-AI exchange. The intended profile is complete enough to model; the reported profile is thin (Section 4.3). The primary model is therefore the dimensional alignment of intended profiles, read as a map of how instructors design and describe AI mediation, not as evidence of how learners were mediated.

## 3. Author decisions (cumulative, October 23 and 24, 2026)

1. **Static AI artifacts are outside the model** (R21); five v0.5 episodes removed. Article 63's demonstration components were not coded.
2. **Sample:** Joo (GT-64) and Talkington and Molzahn (GT-51) removed and replaced by the 11th and 12th draws of the same seeded sequence (articles 63, Wang, and 28, Danahy). 10 entries per institution.
3. **Codes added in v0.6:** Stated Purpose `Critical evaluation of AI (HD)`; mediational literacy `ML-RA`.
4. **Model 1 (dimensional alignment) is primary**; configuration-and-epistemic-work and trajectory models are secondary.
5. **Genre:** reported through the comparison of design-intent evidence with reported enactment. In v0.7 this is the comparison of intended and reported profiles (Model 1-IR, Section 5.3), which supersedes the v0.6 `EvidenceClass` grouping.
6. **Evidence weighting by tier:** T1 2.0, T2 1.5, T3 1.0, applied to reported codes; T4 design statements enter only the intended profile and are unweighted. This replaces the v0.6 rule weighting direct evidence 1.5 times indirect.
7. **Connections use the product rule** of the two code weights (e.g., T2 with T2 gives 2.25).
8. **Grammar checker:** run Model 1 with and without `TO-BelloWrite-A2` (`NonGenerativeTool == 1`).
9. **R12:** coherence reported only for four or more coded dimensions and flagged only when strictly below 2/3.
10. **Coding diagnostics are reported alongside Model 1** (Section 5.6).
11. **Theory revision adopted at full scope:** two profiles, evidence tiers, D2 to D3 split, D5 respecified, move coding, and uptake. Trace data will be sought, but work does not wait for it.

Do not reintroduce excluded episodes, recode, or reweight on your own initiative.

## 4. Data

### 4.1 Counts

| | Georgia Tech | Stanford | Toronto | Total |
|---|---|---|---|---|
| Entries | 10 | 10 | 10 | 30 |
| Learner episodes | 28 | 14 | 19 | 61 |
| Instructor episodes | 5 | 0 | 2 | 7 |
| ENA units (entries with a learner episode) | 9 | 10 | 9 | 28 |
| Learner episodes with two or more reported dimensions | 7 | 0 | 8 | 15 |
| Entries with such episodes | 4 | 0 | 5 | 9 |

Reported dimension codes on learner episodes: 35 at T2, 15 at T3, 1 at T1 (a single reproduced student prompt, `ST-02-A1`). Stanford entries are prescriptive artifacts, so all their evidence is design intent; Stanford therefore has no reported profiles to model.

### 4.2 Data dictionary (`aimai_ena_episodes_v07.csv`)

UTF-8, comma-separated, header row.

**Identifiers, context, and entry-level codes**

| Column | Meaning |
|---|---|
| EpisodeID, EntryID, ActivityID, EpisodeNum, SeqInEntry | Stable IDs from earlier passes (gaps where episodes were excluded); `SeqInEntry` is document order after exclusions |
| Institution, InstCode, Genre | Genre: Narrative (GT), Prescriptive (ST), Hybrid (TO); coincides with institution in this sample |
| Author, Title, SourceCategory, Activity, Objective, Tool | Descriptive fields |
| Participant, LearnerOrInstructor | Instructor episodes stay out of ENA (R2) |
| Context, SociotechnicalFrame, LaurillardType, StatedPurpose, LearnerVariability, DialogueType | Context fields |
| TrajectoryUseCase | Within-episode, Sequential, Recurrent, Single use (October 6 screen) |
| NonGenerativeTool | 1 for `TO-BelloWrite-A2` |
| EvidenceClass | `Reported` if the episode has any reported dimension, else `Design` |
| HighestTier | Highest tier among the episode's reported codes, or T4 |
| EvidenceStance, ClaimStance, AIUseStance, LimitationsAcknowledged, TracesCollected | Entry-level reporting-stance codes (R26), repeated on each of the entry's rows |

**Profiles and indices**

| Column | Meaning |
|---|---|
| I_D1 ... I_D5 | Intended profile codes (AD, AS, CM, HD, NE) |
| R_D1 ... R_D5, R_T1 ... R_T5 | Reported profile codes and their tiers (T1, T2, T3, or `-`) |
| Hol_I, Hol_R | Holistic configuration per profile. Assigned with a rule-assisted default (modal configuration; ties broken by steering, then provenance) pending David's review; `Hol_R` is NE unless two or more reported dimensions are coded |
| I_DimsCoded, I_Coherence, I_ReviewFlag | Intended indices (R12; coherence blank below four coded dimensions) |
| R_DimsCoded, R_Coherence, R_WeightedEvidence | Reported indices; `R_WeightedEvidence` is the sum of tier weights across reported dimensions |
| PurposeDesignAlign, IntendedReportedAlign | Stated purpose vs intended holistic; intended vs reported holistic (blank where either is NE) |
| StartConfig, EndConfig, WithinEpTrajectory, TrajectoryBasis | Within-episode trajectory and whether it rests on intended or reported evidence |
| EO_I, EO_R, EO_R_Tier, EpistemicObject, ML_I, ML_R, ML_R_Tier, UP_I, UP_R, UP_R_Tier | Extension codes in both versions |
| Memo_v06, Memo_v07 | Coder rationale; read before interpreting any surprising connection |

**Code columns for ENA**

| Group | Columns | Values |
|---|---|---|
| Intended intersection codes (20) | `I_AD_1` ... `I_HD_5` | 0/1 |
| Reported intersection codes, binary (20) | `R_AD_1` ... `R_HD_5` | 0/1 |
| Reported intersection codes, tier-weighted (20) | `RW_AD_1` ... `RW_HD_5` | 0, 1.0 (T3), 1.5 (T2), 2.0 (T1) |
| Holistic (8) | `HolI_AD` ... `HolI_HD`, `HolR_AD` ... `HolR_HD` | 0/1 |
| Epistemic opportunity (10) | `EOI_IN` ... `EOI_RD` (0/1); `EOR_IN` ... `EOR_RD` (tier-weighted) | |
| Mediational literacy (10) | `MLI_FR` ... `MLI_RA` (0/1); `MLR_FR` ... `MLR_RA` (tier-weighted); ML-MX expanded into components | |
| Uptake (12) | `UPI_AD` ... `UPI_MX` (0/1); `UPR_AD` ... `UPR_MX` (tier-weighted) | |
| Dialogue type (4) | `DT_Instructional`, `DT_Feedbackoriented`, `DT_Collaborative`, `DT_Reflective` | 0/1 |

### 4.3 What the data can and cannot support

The intended profile is coded for nearly every dimension (49 of 61 learner episodes have four or five coded dimensions). The reported profile exists for 22 learner episodes and has two or more coded dimensions in only 15, from 9 entries in Georgia Tech and Toronto. Reported codes concentrate on interpretive influence (`HD_4`, 9 occurrences in those 15 episodes), learner-steered exchanges (`HD_2`, 6), and assistant positioning (`AS_5`, 6). Treat every reported-profile result as descriptive.

## 5. Models

All models use learner episodes only. Instructor episodes (7) are described separately (R2).

### 5.1 Model 1 (primary): dimensional alignment of intended profiles

| Setting | Value |
|---|---|
| Units | Institution > EntryID (28 units: GT 9, ST 10, TO 9) |
| Conversation | EpisodeID |
| Codes | The 16 intended intersection codes present in at least 3 learner episodes (drops `I_AD_2`, `I_AD_4`, `I_AD_5`, `I_CM_4`) |
| Weighting | None: design statements are T4 and unweighted |
| Window | Within-line co-occurrence (window size back = 1) |
| Question | How do instructors' designs align engagement, steering, provenance, interpretive influence, and positioning, and does this differ across institutions? |

Required runs: **1A** all 61 learner episodes; **1B** without `NonGenerativeTool == 1` (60 episodes). Report 1A in full and 1B as a comparison.

Reporting for each run: group centroids with 95% confidence intervals on the first two dimensions; pairwise Mann-Whitney U tests on centroid positions (9 or 10 units per group, so tests are exploratory and effect sizes matter more than p values); mean and subtracted networks; goodness of fit (Pearson and Spearman correlations between plotted points and centroids); dimension loadings.

Sensitivity analyses for 1A: (a) episodes with at least four coded intended dimensions (49); (b) without D5; (c) frequency threshold at 2.

**Interpretive anchor.** The v0.7 split of steering from provenance makes one pattern visible: 15 learner episodes are learner-steered (HD-2) while their content is AI-produced (AS-3 or AD-3), typically on-demand explainers and draft-then-revise designs. Expect the `I_HD_2` to `I_AS_3` and `I_HD_2` to `I_AD_3` connections to be prominent, and interpret them as a design pattern ("the learner directs, the AI produces"), not as incoherence.

### 5.2 Model 1-R (secondary, descriptive): reported profiles

Learner episodes with two or more reported dimensions (15 episodes, 9 entries: GT-06, GT-24, GT-30, GT-66, TO-BelloConv, TO-BelloWrite, TO-Goldfarb, TO-MacKay, TO-Yip). Units Institution > EntryID; conversation EpisodeID; codes the `RW_` versions of whichever reported codes occur at least twice in that subset; window 1. Report the mean network and loadings only; do not test group differences with this few units.

### 5.3 Model 1-IR (genre analysis): intended versus reported profiles

This is the genre comparison David requested: design intention against reported enactment.

1. Take the 15 learner episodes with two or more reported dimensions.
2. Reshape to long format: one row per episode per profile, with `Profile` = Intended or Reported. Use one shared set of 20 code columns named `AD_1` ... `HD_5`: for the Intended row copy `I_` values; for the Reported row copy `RW_` values.
3. Units `Profile > EntryID` (9 entries in each profile); conversation `EpisodeID` (with window 1, connections stay within each profile's row); codes those occurring at least twice across both profiles.
4. Compare the Intended and Reported means and the subtracted network. Test centroid differences with a Wilcoxon signed-rank test on the 9 paired entries, and report the effect size.

Report alongside it the descriptive alignment of holistic configurations: of the 15 learner episodes with both, 10 align and 5 diverge (`GT-24-A3` HD to CM, `GT-30-A2` HD to AS, `GT-66-A1` HD to AS, `GT-66-A2` CM to HD, `TO-Yip-A1` AD to HD).

Also mention, without modeling it, that the entry-level `Genre` grouping coincides exactly with institution in this sample.

### 5.4 Reporting stance (descriptive, with one exploratory grouping)

Tabulate `EvidenceStance`, `ClaimStance`, `AIUseStance`, `LimitationsAcknowledged`, and `TracesCollected` by institution, one row per entry. Reference values (entries):

| | Georgia Tech | Stanford | Toronto |
|---|---|---|---|
| Evidence stance | 1 design only, 4 observation (T3), 5 participant account (T2) | 9 design only, 1 trace fragment (T1) | 1 design only, 2 observation, 7 participant account |
| Claim stance | 7 benefit, 2 mixed, 1 critical | 10 descriptive | 6 benefit, 3 mixed, 1 critical |
| Limitations acknowledged | 1 none, 3 design, 2 evidence, 4 both | 10 none | 9 none, 1 design |
| Traces collected | 8 collected, not reproduced; 2 not described | 3 collected; 1 partly reproduced; 6 not described | 6 collected; 1 partly reproduced; 3 not described |

Exploratory grouping: refit Model 1A with units grouped by evidence stance, `Design only (T4)` (11 units, 9 of them Stanford) against any reported enactment (17 units). Because Stanford dominates the design-only group, present this as a description of reporting practice, not as a separate effect from institution.

### 5.5 Models 2 and 3 (secondary)

**Model 2, configuration and epistemic work (intended):** units Institution > EntryID; conversation ActivityID; codes `HolI_AD` ... `HolI_HD`, `EOI_RE`, `EOI_EV`, `EOI_CH`, `EOI_RD`, `MLI_FR`, `MLI_EP`, `MLI_CW`, `MLI_DD`, `MLI_RA`, `UPI_AP`, `UPI_MX` (drop any below 3); window 1. Report reported EO, ML, and uptake codes as counts only (EO 11, ML 12, uptake 5 learner episodes).

**Model 3, trajectory (intended):** entries with TrajectoryUseCase Sequential or Recurrent (14 entries: GT 6, ST 2, TO 6); rows ordered by `EntryID`, `SeqInEntry`; conversation ActivityID; codes `HolI_AD` ... `HolI_HD`; moving stanza window of 2. Descriptive only.

### 5.6 Coding diagnostics (required, reported before the ENA results)

Compute for learner episodes, for the intended profile, and for the reported profile where coded. Reference values for the intended profile:

1. **Review-flag triggers** (R12): 12 learner episodes flagged; triggers: coherence below 2/3 in 10, modal tie in 2, fewer than three coded dimensions in 2 (episodes can carry more than one).
2. **Coherence by number of coded dimensions:** four dimensions, 25 episodes, mean .800, minimum .333; five dimensions, 24 episodes, mean .828, minimum .467. Distribution of coded dimensions: 2 (2 episodes), 3 (10), 4 (25), 5 (24).
3. **Dimension-pair agreement** (proportion coded at the same configuration where both are coded): D1-D3 .86, D1-D4 .85, D2-D4 .84, D3-D4 .80, D1-D2 .77, D2-D3 .67, D3-D5 .61, D1-D5 .59, D2-D5 .54, D4-D5 .52. Present as a 5 x 5 matrix.
4. **Steering by provenance cross-tabulation** (I_D2 by I_D3, 4 x 4), highlighting the 15 learner-steered, AI-produced episodes.
5. **Intended versus reported agreement by dimension**, where both are coded: D1 8 of 9, D2 6 of 9, D3 9 of 10, D4 13 of 13, D5 7 of 9.

Interpretation note: lower coherence in v0.7 than in v0.6 is expected, because separating steering from provenance exposes divergence the combined D2 had absorbed. Positioning (D5) remains the least aligned dimension. Report both without adjudicating them.

## 6. Suggested workflow in R

We suggest rENA (Marquart et al., n.d.). Argument names follow the package as we understand it; check them against the installed version before running, and verify on one unit that weighted codes are carried into connections by the product rule.

```r
library(rENA)

d <- read.csv("aimai_ena_episodes_v07.csv", stringsAsFactors = FALSE)
d <- subset(d, LearnerOrInstructor == "Learner")                     # 61 episodes, 28 units

icodes <- grep("^I_(AD|AS|CM|HD)_[1-5]$", names(d), value = TRUE)
keepI  <- icodes[colSums(d[, icodes]) >= 3]                             # 16 codes

run_ena <- function(dat, codes, units, conv = "EpisodeID", binary = TRUE) {
  acc <- ena.accumulate.data(
    units        = dat[, units],
    conversation = dat[, conv, drop = FALSE],
    metadata     = dat[, intersect(c("InstCode", "EvidenceStance", "Profile"), names(dat)), drop = FALSE],
    codes        = dat[, codes],
    window.size.back = 1,
    binary       = binary                                               # confirm argument name and behavior
  )
  ena.make.set(acc)
}

m1A <- run_ena(d, keepI, c("Institution", "EntryID"))
m1B <- run_ena(subset(d, NonGenerativeTool == 0), keepI, c("Institution", "EntryID"))

# Model 1-IR: long format, shared code names, tier-weighted reported rows
both <- subset(d, R_DimsCoded >= 2)                                     # 15 episodes, 9 entries
base <- sub("^I_", "", icodes)
mk <- function(prefix, profile) {
  x <- both[, c("Institution", "EntryID", "EpisodeID")]
  x$Profile <- profile
  x[, base] <- both[, paste0(prefix, base)]
  x
}
long <- rbind(mk("I_", "Intended"), mk("RW_", "Reported"))
keepIR <- base[colSums(long[, base] > 0) >= 2]
m1IR <- run_ena(long, keepIR, c("Profile", "EntryID"), conv = "EpisodeID", binary = FALSE)
```

Save plots (PNG and SVG), centroid tables, fit statistics, diagnostics tables, and a log of every parameter choice, including how the weighting was applied.

## 7. Open items to raise with David

1. **Holistic configurations** (`Hol_I`, `Hol_R`) were assigned by a rule-assisted default and await his review by judgment (R28). Model 1 does not use them; Models 1-IR (descriptive alignment), 2, and 3 do.
2. **Codebook companion document:** `AIM_AI Codebook v1_3.docx` has not been updated to v0.7.
3. **Trace corpus:** 19 sampled entries collect traces by design (column `TracesCollected`). Requests to instructors are planned but not yet made; a trace-based analysis would use the Move Coding Form (R24) and is out of scope here.

## 8. Known limitations to carry into any write-up

This is a single-coder, exploratory study of 30 entries. Its object is instructor intention and public reporting, not learner mediation. Reported evidence is thin and unevenly distributed (none for Stanford), and almost entirely at T2 and T3. Genre and institution coincide at the entry level. Intended-profile codes interpret design language, which varies in specificity across genres. The v0.7 dimensions were introduced after the pilot and have not been tested for reliability.

## References

Bowman, D., Swiecki, Z., Cai, Z., Wang, Y., Eagan, B., Linderoth, J., & Shaffer, D. W. (2021). The mathematical foundations of epistemic network analysis. In A. R. Ruis & S. B. Lee (Eds.), *Advances in quantitative ethnography* (pp. 91–105). Springer. https://doi.org/10.1007/978-3-030-67788-6_7

Centre for Teaching Support & Innovation. (n.d.). *U of T teaching examples*. University of Toronto. Retrieved October 23, 2026, from https://teaching.utoronto.ca/teaching-uoft-genai/at-u-of-t/

Joyner, D. A., & Roy, N. (Eds.). (2026). *Georgia Tech academic AI playbook* (2026 ed.). Georgia Institute of Technology. https://hdl.handle.net/1853/81982

Marquart, C. L., Swiecki, Z., Collier, W., Eagan, B., Woodward, R., & Shaffer, D. W. (n.d.). *rENA: Epistemic network analysis* [R package]. Comprehensive R Archive Network. https://CRAN.R-project.org/package=rENA

Shaffer, D. W., Collier, W., & Ruis, A. R. (2016). A tutorial on epistemic network analysis: Analyzing the structure of connections in cognitive, social, and interaction data. *Journal of Learning Analytics, 3*(3), 9–45. https://doi.org/10.18608/jla.2016.33.3

Siebert-Evenstone, A. L., Irgens, G. A., Collier, W., Swiecki, Z., Ruis, A. R., & Shaffer, D. W. (2017). In search of conversational grain size: Modelling semantic structure using moving stanza windows. *Journal of Learning Analytics, 4*(3), 123–139. https://doi.org/10.18608/jla.2017.43.7

Stanford Center for Teaching and Learning. (n.d.). *AIMES library of examples*. Stanford University. Retrieved October 23, 2026, from https://ctl.stanford.edu/aimes/aimes-library-examples

Winne, P. H. (2010). Improving measurements of self-regulated learning. *Educational Psychologist, 45*(4), 267–276. https://doi.org/10.1080/00461520.2010.517150
